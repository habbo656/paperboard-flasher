#include "frame_format.h"

#include <string.h>

namespace core {

uint8_t framePlanes(const char* hdr, const char* ownFmt) {
  if (!hdr) return 1;  // missing header = bw (IF-021)
  if (strcmp(hdr, "bw") == 0) return 1;
  if (ownFmt && strcmp(hdr, ownFmt) == 0) return strcmp(hdr, "bwr") == 0 ? 2 : 0;
  return 0;
}

bool frameLengthValid(long contentLength, uint8_t planes, size_t bufBytes, size_t plane) {
  if (planes == 0 || contentLength < 0) return false;
  const size_t want = (size_t)planes * plane;
  return (size_t)contentLength == want && want <= bufBytes;
}

void resolveRed(uint8_t* black, const uint8_t* red, size_t n) {
  for (size_t i = 0; i < n; i++) black[i] |= (uint8_t)~red[i];
}

}  // namespace core

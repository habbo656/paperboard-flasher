#include "status_icon.h"

#include <string.h>

namespace core {

Window alignedWindow(const Rect& area) {
  Window win;
  if (!area.valid()) return win;
  int16_t x0 = area.x - area.x % 8;
  int16_t x1 = area.x + area.w;  // exclusive
  if (x1 % 8) x1 += 8 - x1 % 8;
  win.x = x0;
  win.y = area.y;
  win.w = x1 - x0;
  win.h = area.h;
  if (win.size() > MAX_WINDOW_BYTES) return Window();
  return win;
}

void copyWindow(const uint8_t* frame, const Window& win, uint8_t* out, int16_t panelW) {
  const size_t bpr = win.bytesPerRow();
  for (int16_t row = 0; row < win.h; row++) {
    memcpy(out + row * bpr, frame + ((size_t)(win.y + row) * panelW + win.x) / 8, bpr);
  }
}

static void setPixel(uint8_t* window, const Window& win, int16_t x, int16_t y, bool white) {
  if (x < 0 || y < 0 || x >= win.w || y >= win.h) return;
  uint8_t& b = window[(size_t)y * win.bytesPerRow() + x / 8];
  uint8_t mask = 0x80 >> (x % 8);
  if (white) b |= mask;
  else b &= ~mask;
}

void drawOfflineIcon(uint8_t* window, const Window& win, const Rect& area) {
  // icon origin in window coordinates, centred in the status area
  const int16_t ox = area.x - win.x + (area.w - ICON_SIZE) / 2;
  const int16_t oy = area.y - win.y + (area.h - ICON_SIZE) / 2;
  const float c = (ICON_SIZE - 1) / 2.0f;
  for (int16_t y = 0; y < ICON_SIZE; y++) {
    for (int16_t x = 0; x < ICON_SIZE; x++) {
      const float dx = x - c, dy = y - c;
      const float d2 = dx * dx + dy * dy;
      if (d2 > c * c + c) continue;  // outside the disc: keep frame content
      const bool ring = d2 >= (c - 2.5f) * (c - 2.5f);
      const float diag1 = dx - dy, diag2 = dx + dy;
      const bool onDiag = (diag1 > -1.6f && diag1 < 1.6f) || (diag2 > -1.6f && diag2 < 1.6f);
      const bool cross = d2 <= (c - 5.0f) * (c - 5.0f) && onDiag;
      setPixel(window, win, ox + x, oy + y, !(ring || cross));
    }
  }
}

}  // namespace core

#pragma once
// Board layer (ADR-19, ADR-25, FW-100): the only place where the three supported boards differ. Per env one
// constants header (board_<name>.h) and its implementation files are compiled (build_src_filter in platformio.ini;
// the two ESP32-S3 boards share board_esp32s3.cpp); there are no virtual classes and no heap use.
// `#if PB_BOARD_*` appears only in board*.{h,cpp} and display.cpp.
// Hardware facts: docs/hardware.md.

#include <stddef.h>
#include <stdint.h>

#include "sleep_logic.h"

// The constants (geometry, capability flags) and inline stubs of one board; namespace board.
#if defined(PB_BOARD_D1_MINI)
#include "board_d1_mini.h"
#elif defined(PB_BOARD_NM_EPD_420)
#include "board_nm_epd_420.h"
#elif defined(PB_BOARD_TRMNL_75)
#include "board_trmnl_75.h"
#else
#error "Define PB_BOARD_D1_MINI, PB_BOARD_NM_EPD_420 or PB_BOARD_TRMNL_75 (see platformio.ini)"
#endif

namespace board {

// Per-board constants (board_<name>.h): PANEL_W/PANEL_H (IF-022), ORIGIN_X/ORIGIN_Y, FRAME_BUF_BYTES, PARTIAL_REFRESH,
// API_VERSION, MIN_REFRESH_MS, OTA_MAX_BYTES, IMAGE_ESP32S3, DEEP_SLEEP, HAS_* and their functions or stubs.

extern const char* const ID;             // "d1_mini" | "nm_epd_420" | "trmnl_75"   (IF-020 board)
extern const char* const FRAME_FORMAT;   // "bw" | "bwr"                    (IF-020 fmt, ADR-20)
extern const char* const PANEL;          // "GxEPD2_420" | "GDEY042Z98" | "GDEY075T7" (IF-010 panel)
extern const char* const RESET_HINT;     // how to factory reset, for on-screen texts (FW-008, FW-102)


// True if p points into memory-mapped flash (a PSTR on the ESP8266, #63). The ESP32 has no separate flash
// address space for literals (PSTR is a plain literal), so it is always false there.
#if defined(PB_BOARD_D1_MINI) || defined(ESP8266)
inline bool inFlash(const void* p) { return (uintptr_t)p >= 0x40000000u; }
#else
inline bool inFlash(const void*) { return false; }
#endif

// Call once in setup() after Serial.begin(). S3: Serial.setTxTimeoutMs(0) so logging never blocks without a host.
void begin();

uint32_t chipId();            // 24 bit, printed as %06x (D1: ESP chip ID, S3: last three bytes of the eFuse MAC)
const char* resetReason();    // hardware reset reason as an X-Reset-Reason string (FW-062)
uint32_t freeHeap();          // internal RAM (FW-062)
uint32_t maxBlock();
[[noreturn]] void restart();      // clean software restart
[[noreturn]] void hardReset();    // for the watchdog: restarts even when the system is stuck
uint32_t hwRandom();

// OTA (FW-072, NFR-012): confirms the running image after its first answered poll. S3: ends the bootloader
// rollback window (ADR-18); D1: no-op (eboot has no rollback).
void otaConfirm();

// Small persistent areas surviving software/watchdog resets, not power loss (ESP8266 RTC user memory; S3:
// RTC_NOINIT_ATTR struct). Sizes must be multiples of 4 and within the slot (Health 8, Ota 40, DoubleReset 8, Sleep 48, Battery 12 bytes).
// Sleep (48 B, FW-038): the deep-sleep record (core::SleepRecord); D1: blocks 112–123.
// Battery (12 B, #104): core::BatteryRecord, S3 only.
enum class Rtc : uint8_t { Health, Ota, DoubleReset, Sleep, Battery };
void rtcRead(Rtc slot, void* data, size_t bytes);
void rtcWrite(Rtc slot, const void* data, size_t bytes);

// Deep sleep (FW-038, FW-107, ADR-23). Only meaningful when DEEP_SLEEP is true.
core::WakeKind wakeReason();             // how this boot started: timer / button (S3 BOOT) wake or a real reset (D1: a
                                         // RESET during sleep reads as a timer wake, harmless)
uint32_t sleptMs(uint32_t plannedMs);    // how long the last sleep really lasted (D1: planned, S3: RTC timer delta)
void prepareSleep();                     // switches off what draws current in sleep; D1: clears the double-reset flag
[[noreturn]] void deepSleep(uint32_t seconds);   // timer wake (+ S3: BOOT); the caller saved the RTC record

// FW-037: connect with BSSID and channel from the record. persistent(false): no flash write per wake. The caller
// re-enables persistence after the connect. wifiNormalBegin() is the fallback (same credentials, no BSSID).
// BSSID and channel of the current connection (false if not connected). Not WiFi.BSSID(): on the ESP8266 it pulls in a
// 112 B static station_config (D1 RAM budget).
bool wifiApInfo(uint8_t bssid[6], uint8_t* channel);
void wifiFastBegin(const uint8_t* bssid, uint8_t channel);
void wifiNormalBegin();

void wifiDrop();         // drops the connection but keeps the stored credentials (never WiFi.disconnect())
// FW-001: true if station credentials are stored in flash. Must not depend on the Wi-Fi driver state (#88: on the
// ESP32-S3 WiFiManager::getWiFiIsSaved() reads uninitialised memory before the driver is up).
bool wifiCredentialsSaved();
void wifiModemSleep();   // FW-041: modem sleep while connected

bool fsBegin();          // mounts LittleFS (S3: formats on first use)

bool mdnsBegin(const char* host);
void mdnsAddService(const char* service, uint16_t port);  // "_service._tcp"
void mdnsTxt(const char* key, const char* value);          // call after mdnsAddService
void mdnsTxtReplace(const char* key, const char* value);   // replaces an existing key
void mdnsAnnounce();
void mdnsUpdate();       // call from loop()
void mdnsEnd();

bool factoryResetAtBoot();      // D1: double reset (FW-008); S3: false
void loop();                    // D1: disarms the double-reset window after 3 s; S3: samples USER
bool factoryResetRequested();   // S3: USER held >= 5 s (FW-102), once per press; D1: false

}  // namespace board

#pragma once
// Constants and inline stubs of the TRMNL 7.5" OG DIY kit (XIAO ESP32-S3 PLUS, 800x480 b/w); included by board.h
// (ADR-19, ADR-25, FW-114). Every value marked [open] is a vendor fact or a safe placeholder until the owner has run
// the spike checks T-1 ... T-7 (docs/hardware.md section 8); do not treat them as verified.

#include <stddef.h>
#include <stdint.h>

namespace board {

constexpr int PANEL_W = 800, PANEL_H = 480;            // IF-022 frame geometry: 48 000 B per plane, 100-byte rows
// ADR-25: the 400x300 frame/local screens sit centred on the panel (200 = 25 bytes per row, 90 rows down)
constexpr int ORIGIN_X = 200, ORIGIN_Y = 90;
constexpr size_t FRAME_BUF_BYTES = PANEL_W * PANEL_H / 8;  // 48 000 B, black plane only (bw)
// [open] T-2: the panel supports partial refresh (GxEPD2_750_GDEY075T7: hasFastPartialUpdate), but ghosting after
// 10 partials is unmeasured. Placeholder = full refresh only; set true after T-2.
constexpr bool PARTIAL_REFRESH = false;
constexpr uint8_t API_VERSION = 3;                     // IF-021: X-Board / X-Frame-Format on every poll
constexpr uint32_t MIN_REFRESH_MS = 0;                 // [open] T-2: b/w panel, no firmware floor expected (FW-103)
constexpr uint32_t OTA_MAX_BYTES = 2UL * 1024 * 1024;  // NFR-031
constexpr bool IMAGE_ESP32S3 = true;
// No sensor, speaker or battery support in #112 (battery sensing: #114). Inline stubs, no I2C/I2S/ADC code.
constexpr bool HAS_CLIMATE = false;
inline void climateLoop() {}
inline bool climate(int16_t*, uint8_t*) { return false; }
inline const char* climateState() { return ""; }
inline void debugClimateFail() {}
constexpr bool HAS_AUDIO = false;
inline void audioBegin() {}
inline const char* audioState() { return ""; }
inline bool playChime(uint8_t, uint8_t) { return false; }
// [open] T-4: KEY3 (GPIO5) is used for the FW-102 factory reset only; no IF-004 button events in #112 (app: buttons []).
constexpr bool HAS_BUTTONS = false;
inline bool popButtonEvent(uint8_t*, uint8_t*) { return false; }
bool userHeld();                                       // KEY3 pressed right now (FW-038 stay-awake rule 5)
// [open] T-5: deep sleep (timer + KEY3 wake, RTC record, panel keeps its image) is unverified. Placeholder = awake
// (USB powered like the D1 mini); the wake code in board_trmnl_75.cpp is in place for when T-5 passes.
constexpr bool DEEP_SLEEP = false;
constexpr bool HAS_BATTERY = false;
inline uint16_t batteryReadMv() { return 0; }
inline bool batteryMode() { return false; }
inline void setBatteryMode(bool) {}

}  // namespace board

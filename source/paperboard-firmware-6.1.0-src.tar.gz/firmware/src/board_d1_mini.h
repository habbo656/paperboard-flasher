#pragma once
// Constants and inline stubs of the WeMos D1 mini (ESP8266); included by board.h (ADR-19, ADR-25). Hardware: docs/hardware.md.

#include <stddef.h>
#include <stdint.h>

namespace board {

constexpr int PANEL_W = 400, PANEL_H = 300;            // IF-022 frame geometry
constexpr int ORIGIN_X = 0, ORIGIN_Y = 0;              // top-left of the 400x300 window for local screens (ADR-25)
constexpr size_t FRAME_BUF_BYTES = PANEL_W * PANEL_H / 8;  // FW-033: black plane only
constexpr bool PARTIAL_REFRESH = true;
constexpr uint8_t API_VERSION = 2;                     // stays on protocol 2: requests byte-identical (NFR-041/047)
constexpr uint32_t MIN_REFRESH_MS = 0;                 // FW-103: no firmware floor for the b/w panel
constexpr uint32_t OTA_MAX_BYTES = 1024UL * 1024;      // NFR-031
constexpr bool IMAGE_ESP32S3 = false;                  // OTA header check (core::otaImageMatches)
// FW-081: the D1 mini has no sensor. Inline no-op stubs: no I2C code and no Wire in this build (NFR-047).
constexpr bool HAS_CLIMATE = false;
inline void climateLoop() {}
inline bool climate(int16_t*, uint8_t*) { return false; }
inline const char* climateState() { return ""; }
inline void debugClimateFail() {}
// FW-106 (#83): no speaker on the D1 mini. No I2S/codec code in this build, requests stay byte-identical (NFR-047).
constexpr bool HAS_AUDIO = false;
inline void audioBegin() {}
inline const char* audioState() { return ""; }
inline bool playChime(uint8_t, uint8_t) { return false; }
constexpr bool HAS_BUTTONS = false;                    // D-26: the D1 mini has no buttons (FW-080 is NM-EPD-420 only)
inline bool popButtonEvent(uint8_t*, uint8_t*) { return false; }
inline bool userHeld() { return false; }
constexpr bool DEEP_SLEEP = true;                      // FW-038: verified by spike S1 (hardware.md H-3)
// FW-112, FW-113 (#104): the D1 mini stays USB-powered. Inline stubs: no ADC code, no NVS (NFR-047).
constexpr bool HAS_BATTERY = false;
inline uint16_t batteryReadMv() { return 0; }
inline bool batteryMode() { return false; }
inline void setBatteryMode(bool) {}

}  // namespace board

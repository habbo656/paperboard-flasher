#pragma once
// E-paper output: received frames, the offline icon overlay and local screens (FW-033, FW-035, FW-036,
// FW-051, FW-052). Panels per board: docs/hardware.md.

#include <stddef.h>
#include <stdint.h>

#include "board.h"
#include "poll_logic.h"

namespace display {

constexpr size_t FRAME_BYTES = board::PANEL_W * board::PANEL_H / 8;  // one plane (IF-022)

void begin();

// Shows a complete 1-bpp frame (MSB first, 1 = white). full = full refresh, else partial (no flashing).
// On a bwr board (NM-EPD-420) the red plane follows the black plane in the same buffer (FRAME_BYTES later);
// those boards always do a full refresh.
// Returns whether a full refresh was done: the first refresh after boot is always full (GxEPD2).
bool showFrame(const uint8_t* frame, bool full);

// Draws (offline = true) or removes (false) the offline icon in the status area of the shown frame.
// frame is restored before returning (bwr boards temporarily draw the icon into it for a full refresh).
void showStatusIcon(uint8_t* frame, const core::Rect& area, bool offline);

// Full-screen local message with ASCII text (built-in fonts). lines may contain nullptr entries.
// screenId identifies the message for lastScreen() (0 = generic).
void showMessage(const char* title, const char* const* lines, size_t count, int screenId = 0);

// FW-103: millis() of the last panel refresh (frame, icon or local screen). False if none yet or the board has no
// refresh floor (board::MIN_REFRESH_MS == 0).
bool lastRefresh(uint32_t* ms);

// FW-038, FW-036: puts the panel into its lowest-power mode before a deep sleep. The D1 controller loses its "previous"
// image RAM, so the first changed frame after a wake is a full refresh (first refresh after boot, already the case).
void hibernate();

// FW-103 across a deep sleep: seconds since the last panel refresh (core::REFRESH_AGE_NONE if none or the board has no
// floor), and the reverse after the wake.
uint32_t refreshAgeS();
void restoreRefresh(uint32_t sinceRefreshAtSleepS, uint32_t sleptS);

// Id of the last full-screen content: -1 = frame, -2 = setup, else the showMessage screenId.
int lastScreen();

// Setup instructions with AP name, password and a QR code to join the AP (FW-002).
void showSetup(const char* apName, const char* password, const char* qrPayload, bool wifiLost);

}  // namespace display

#include "device_api.h"

#include <ArduinoJson.h>

#include "board.h"
#include "board_net.h"
#include "connectivity.h"
#include "health.h"
#include "pairing.h"
#include "pairing_logic.h"
#include "poller.h"
#include "power.h"
#include "screens.h"
#include "version.h"

namespace device_api {

static HttpServer server(80);
static bool running = false;
static char chipId[8];
static bool pairedScreenPending = false;

static void sendJson(int code, JsonDocument& doc) {
  String body;
  serializeJson(doc, body);
  server.send(code, "application/json", body);
}

static void sendError(int code, const char* message) {
  JsonDocument doc;
  doc["error"] = message;
  sendJson(code, doc);
}

static bool authorized() { return core::bearerMatches(server.header(F("Authorization")).c_str(), pairing::token()); }

// IF-010: no secrets
static void handleInfo() {
  JsonDocument doc;
  doc["id"] = chipId;
  doc["mac"] = WiFi.macAddress();
  doc["fw"] = FW_VERSION;
  doc["api"] = board::API_VERSION;
  doc["paired"] = pairing::isPaired();
  doc["name"] = pairing::name();
  doc["board"] = board::ID;  // IF-010, IF-020
  doc["fmt"] = board::FRAME_FORMAT;
  doc["panel"] = board::PANEL;
  doc["width"] = board::PANEL_W;  // IF-022
  doc["height"] = board::PANEL_H;
  doc["uptime_s"] = power::uptimeS();  // FW-092
  doc["heap"] = health::heapReport();
  doc["rssi"] = WiFi.RSSI();
  // #63: free/largest block per boot stage (start, display, pairing, wifi, mdns, api, poll1, steady); [0,0] = not reached
  JsonArray boot = doc["bootHeap"].to<JsonArray>();
  for (size_t i = 0; i < core::HeapStages::COUNT; i++) {
    const auto st = (core::HeapStage)i;
    JsonArray e = boot.add<JsonArray>();
    e.add(health::bootHeap().free(st));
    e.add(health::bootHeap().maxBlock(st));
  }
  if (board::HAS_CLIMATE) doc["sensor"] = board::climateState();  // IF-010 (#80): state word only, no values
  if (board::HAS_AUDIO) doc["audio"] = board::audioState();  // IF-010 (#83): state word only
  sendJson(200, doc);
}

// IF-011: only while unpaired (NFR-027)
static void handlePair() {
  if (pairing::isPaired()) {
    char msg[72];
    snprintf_P(msg, sizeof(msg), PSTR("already paired - factory reset the display (%s)"), board::RESET_HINT);
    return sendError(409, msg);
  }
  JsonDocument doc;
  if (deserializeJson(doc, server.arg("plain"))) return sendError(400, "invalid JSON");
  const char* token = doc["token"] | "";
  const char* url = doc["homey_url"] | "";
  const char* name = doc["name"] | "";
  if (!core::validToken(token)) return sendError(400, "invalid token");
  if (!core::validHomeyUrl(url)) return sendError(400, "invalid homey_url");
  if (!pairing::pair(token, url, name)) return sendError(500, "storing the pairing failed");
  Serial.printf_P(PSTR("[api] paired by %s, name '%s'\n"), server.client().remoteIP().toString().c_str(), name);
  JsonDocument ok;
  ok["id"] = chipId;
  ok["paired"] = true;
  sendJson(200, ok);
  announcePaired(true);
  pairedScreenPending = true;  // drawn after the response went out (the refresh blocks ~2 s)
}

// IF-012
static void handleConfig() {
  if (!pairing::isPaired() || !authorized()) return sendError(401, "unauthorized");
  JsonDocument doc;
  if (deserializeJson(doc, server.arg("plain"))) return sendError(400, "invalid JSON");
  const char* url = doc["homey_url"] | "";
  if (*url) {
    if (!core::validHomeyUrl(url)) return sendError(400, "invalid homey_url");
    if (strcmp(url, pairing::homeyUrl()) != 0) {
      pairing::setHomeyUrl(url);
      Serial.printf_P(PSTR("[api] Homey URL changed to %s\n"), url);
      poller::kick();
    }
  }
  server.send(204);
}

// IF-013
static void handleKick() {
  if (!pairing::isPaired() || !authorized()) return sendError(401, "unauthorized");
  poller::kick();
  server.send(202);
}

static void start() {
  snprintf_P(chipId, sizeof(chipId), PSTR("%06x"), (unsigned)board::chipId());
  // #59: on() allocates a handler that stop() never frees, so register only once, not on every reconnect.
  static bool routesRegistered = false;
  if (!routesRegistered) {
    routesRegistered = true;
    static const char* headerKeys[] = {"Authorization"};
    server.collectHeaders(headerKeys, (size_t)1);
    server.on(F("/api/info"), HTTP_GET, handleInfo);
    server.on(F("/api/pair"), HTTP_POST, handlePair);
    server.on(F("/api/config"), HTTP_POST, handleConfig);
    server.on(F("/api/kick"), HTTP_POST, handleKick);
    server.onNotFound([] { sendError(404, "not found"); });
  }
  server.begin();
  health::heapMark(core::HeapStage::Api);  // HTTP server up, before mDNS

  char host[24];
  snprintf_P(host, sizeof(host), PSTR("paperboard-%04x"), (unsigned)(board::chipId() & 0xFFFF));
  if (board::mdnsBegin(host)) {
    char api[8];
    snprintf_P(api, sizeof(api), PSTR("%d"), board::API_VERSION);
    board::mdnsAddService("paperboard", 80);
    board::mdnsTxt("id", chipId);
    board::mdnsTxt("fw", FW_VERSION);
    board::mdnsTxt("api", api);
    board::mdnsTxt("board", board::ID);  // IF-020 (additive, from firmware 5.0 on API 2 and 3)
    board::mdnsTxt("fmt", board::FRAME_FORMAT);
    board::mdnsTxt("paired", pairing::isPaired() ? "1" : "0");
    health::heapMark(core::HeapStage::Mdns);
  }
  running = true;
  Serial.printf_P(PSTR("[api] HTTP server and mDNS %s.local started\n"), host);
}

static void stop() {
  server.stop();
  board::mdnsEnd();
  running = false;
  Serial.println(F("[api] stopped"));
}

void announcePaired(bool paired) {
  if (!running) return;
  board::mdnsTxtReplace("paired", paired ? "1" : "0");
  board::mdnsAnnounce();
}

void loop(bool allowed) {
  const bool shouldRun = allowed && connectivity::online() && !connectivity::portalActive();
  if (shouldRun && !running) start();
  if (!shouldRun && running) stop();
  if (!running) return;
  server.handleClient();
  board::mdnsUpdate();
  if (pairedScreenPending) {
    pairedScreenPending = false;
    screens::showPaired();
  }
}

}  // namespace device_api

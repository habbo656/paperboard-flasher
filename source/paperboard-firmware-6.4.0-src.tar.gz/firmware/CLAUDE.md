# CLAUDE.md – firmware/

Firmware for three boards (PlatformIO, Arduino): D1 mini (ESP8266), NM-EPD-420 and TRMNL 7.5" (`trmnl_75`, both ESP32-S3). Requirements: `../requirements/02-firmware-requirements.md`,
protocol: `../requirements/07-interface-specification.md`, hardware: `../docs/hardware.md`.

## Commands (run from `firmware/`)

| Purpose | Command |
|---|---|
| Build (release) | `../bin/pio run` (env `d1_mini`) |
| Build NM-EPD-420 (ESP32-S3) | `../bin/pio run -e nm_epd_420` (`nm_epd_420_debug` adds the debug commands; OTA as on the D1 mini, #50) |
| Build NM-EPD-420-4C (same PCB, 4-colour panel GDEY0420F51, `bwry`, #111) | `../bin/pio run -e nm_epd_420_4c` (`nm_epd_420_4c_debug`; `p` = black/yellow/red/white test pattern) |
| Build TRMNL 7.5" (ESP32-S3, 800x480 b/w; pins, panel class, partitions are **[open]** until spike T-1…T-7, `docs/hardware.md` §8) | `../bin/pio run -e trmnl_75` (`trmnl_75_debug`) |
| Build with debug commands | `../bin/pio run -e d1_mini_debug` (add `-t upload --upload-port …` to flash) |
| Unit tests (host) | `../bin/pio test -e native` |
| All gates (tests + build, short output) | `../tools/check.sh fw` |
| Flash (**ask the user first**) | `../bin/pio run -t upload --upload-port /dev/cu.usbserial-XXXX` (`ls /dev/cu.usbserial-*`) |
| Flash NM-EPD-420 (**ask the user first**) | ROM download mode (hold BOOT, press RESET), `../bin/pio run -e nm_epd_420 -t upload --upload-port /dev/cu.usbmodemXXXX` (`ls /dev/cu.usbmodem*`); esptool: `docs/development.md` §2 |
| Serial log | `../bin/pio device monitor --port /dev/cu.usbserial-XXXX` (interactive). Non-interactive: `../tools/serial-log.py d1_mini\|nm_epd_420 <log> <cmdfile>` (alias for `/dev/cu.usbserial-*` / `/dev/cu.usbmodem*`; reconnects after S3 re-enumeration); note that opening the port resets the board (RTS) |
| Device API | `curl http://<device-ip>/api/info` (pairing state, heap, RSSI) |
| Pairing for tests | via the Homey app (my.homey.app → Devices → +); factory reset: RESET twice |
| Debug commands (`d1_mini_debug` only) | send over serial (`../tools/serial-log.py` cmd file): `h` hang loop, `m` eat heap, `o` offline icon, `u` age last success 30 min, `w` simulate Wi-Fi loss (30 s/60 s), `d` drop Wi-Fi for 6 min, `r` heap + reset reason (`nm_epd_420_debug`: also sensor state/last reading), `t` suppress AHT20 reads for 5 min (`nm_epd_420_debug`, FW-104: no `X-Temp`/`X-Hum` after 180 s, no restart), `p` black/red/both test pattern (`nm_epd_420_debug`, FW-101), `x` corrupt the MD5 of the next OTA (wrong-MD5 test, FW-072), `l` eat heap until free < 14 000 B (between FW-055 and OTA guard, #59), `c` play the `ding` chime at volume 50 (`nm_epd_420_debug`, FW-106) |

## Structure

- `src/` – Arduino-dependent modules (Wi-Fi, HTTP, display, storage) and `main.cpp`.
- `lib/core/` – platform-independent logic (no `Arduino.h`), unit-tested in `test/` with the `native` env.
  Put everything that can be tested without hardware here (parsing, CRC, backoff, state machines).
- `include/version.h` – firmware and protocol version.

## Rules

- Board differences live only in `src/board.h` + `board_<name>.h` (constants, geometry `PANEL_W/H`, `ORIGIN_X/Y`, stubs) +
  `board_<name>.cpp` (compiled per env via `build_src_filter`, ADR-19; the two S3 boards share `board_esp32s3.cpp` and
  provide `s3::boardBegin()/armWake()`, ADR-25), `board_net.h` (library aliases) and the panel class in `display.cpp`. `#if PB_BOARD_*` appears nowhere
  else; shared modules call `board::` functions. No virtual classes, no heap. Factory reset: D1 mini RESET twice,
  NM-EPD-420 USER held 5 s (`core::ButtonPress`, FW-102). The same classifier gives short/long USER events
  (FW-080), sent by `events.cpp` as `POST /event` (IF-004, `core::EventQueue`); the busy callback in `display.cpp` keeps
  sampling the button during a refresh.
- TRMNL 7.5" (#112, FW-114, ADR-25): API 3, `bw`, 48 000 B frame (IF-022); the 400x300 content and local screens sit at
  `ORIGIN_X/Y` = 200/90; `X-Status-Area` is in panel coordinates. Placeholders until the owner runs T-1…T-7:
  `PARTIAL_REFRESH=false`, `DEEP_SLEEP=false`, `default_8MB.csv` (frozen after the first release flash), KEY3 (GPIO5) = factory reset,
  `HAS_BUTTONS=false`.
- NM-EPD-420 in R5/#48: protocol 2, black plane only (red plane stays 0xFF in the 30 000 B frame buffer), full
  refresh only, no PSRAM. Flashing it needs ROM download mode (hold BOOT, press RESET) and the owner's OK.
- NM-EPD-420-4C (#111, FW-116, ADR-27): env `nm_epd_420_4c` = `nm_epd_420` + `-DPB_PANEL_GDEY0420F51` (`#if PB_PANEL_*` only in
  `board_nm_epd_420.*` and `display.cpp`). Format `bwry` = packed 2 bpp in the same 30 000 B buffer (a `bw` body is expanded in place,
  `core::expandBwTo2bpp`; `bwr` rejected), one `writeNative` + full refresh (~27 s). The busy callback also serves HTTP/mDNS
  (`device_api::serviceDuringRefresh`, `board::SERVE_DURING_REFRESH`) and feeds the loop watchdog; handlers must never touch the display,
  the frame buffer, OTA or audio (`display::refreshing()`). `init(..., 20 ms reset)`: after `hibernate()` the 2 ms default pulse does
  not wake the panel. `board::SERIAL_TX_TIMEOUT_MS` is 10 on the 4C (HWCDC hangs with 0 when a host does not read); 0 on the other S3 boards.
- Display driver `GxEPD2_420` (panel V1). Received frames live in the single static buffer in `poller.cpp`
  (FW-033); never allocate another 15 KB buffer. After every refresh call `writeImageAgain` (partial updates
  need the controller's "previous" RAM in sync). The first refresh after boot is always full.
- Avoid `String` concatenation in loops and long-lived heap allocations (heap fragmentation, FW-055);
  prefer static buffers.
- Library versions are pinned in `platformio.ini` (NFR-044); update deliberately.
- Wi-Fi credentials are stored by the SDK/WiFiManager (they survive flashing; `erase_flash` or double reset
  clears them). Never call `WiFi.disconnect()` to drop a connection – it clears the station config;
  use `wifi_station_disconnect()`.
- WiFiManager (non-blocking): after `process()` returned true the portal is already shut down; calling
  `stopConfigPortal()` again crashes (freed web server). Use the guarded `stopPortal()` in connectivity.cpp.
- RTC memory (blocks of 4 B, user area from 64): **64–95 are reserved for the eboot command** (128 B; the core
  writes it on `ESP.restart()` after an OTA – using it makes eboot skip the new image, the device boots the old
  firmware again). Ours: 96–97 health (reset reason), 98–106 OTA boot state (`ota.cpp`), 110–111 double-reset detection, 112–123 deep-sleep record
  (`board::Rtc::Sleep`, 48 B, `core::SleepRecord`; S3: member of `RtcArea`). S3 only: `board::Rtc::Battery` (12 B, `core::BatteryRecord`).
- OTA (#50): one `ota.cpp` for both boards. D1 limit 1 MB, S3 2 MB (`board::OTA_MAX_BYTES`). The hint path must carry the
  device's own board segment on API 3 (`core::parseOtaHint(..., board)`); the first 24 image bytes are checked for the
  chip (`core::otaImageMatches`) before any flash write. S3 only: bootloader rollback, the image is confirmed by
  `ota::confirmBoot()` on the first answered poll (`verifyRollbackLater()` in `board_nm_epd_420.cpp`). Test builds
  with `-DPB_OTA_NO_CONFIRM` never confirm and restart after 30 s (rollback test). `default_16MB.csv` is frozen.
- Deep sleep (#84, ADR-23): `power.cpp` reads/writes the RTC record; the decision is `core::SleepPolicy` (called in
  `main.cpp`). Never write flash per wake: no LittleFS, `WiFi.persistent(false)` only inside `board::wifiFastBegin()`
  (the S3 driver must be up with persistence on first, or it does not load the stored credentials). S3: never arm
  ext0 (BOOT) while BOOT reads low. D1 static RAM: no member initialisers in structs that are default-constructed
  (they become a RAM constant image), no `WiFi.BSSID()` (112 B static; use `board::wifiApInfo()`).
- Speaker (#83, FW-106): `core::parseSound` / `volumeToDac` / `ChimeSynth` (`lib/core/src/sound.*`, chimes synthesized, no
  samples); `board::audioBegin()` (setup, probes 0x18 on the `Wire` shared with the AHT20, then everything off),
  `board::playChime()` (blocking <= 1.5 s, installs/uninstalls I2S + LEDC MCLK per chime, so no DMA heap in between). The poller
  sends `X-Audio` on every poll and plays `X-Sound` after the CRC check and before `showFrame` (on a 304 at once, on a
  rejected 200 body too); nothing is persisted. D1 build: inline stubs, byte-identical image (check the RAM/flash line of
  `tools/check.sh fw` against main when touching `poller.cpp`: a lambda that is not guarded by `board::HAS_AUDIO` leaks code).
- Battery (#104/#114, ADR-24, NM-EPD-420 and TRMNL 7.5"): `battery.cpp` (not compiled for the D1 mini; callers guard with
  `board::HAS_BATTERY`), logic in `core/battery_logic`. `X-Battery` goes out on every poll with a plausible reading
  (2800..4400 mV); the logic (critical shutdown at 3.50 V measured, failure backoff in `SleepPolicy`) runs only while armed by
  `X-Battery-Mode: 1` (NVS key `pb/batt`, written on change only; a 200/304 without the header disarms). Test build for the
  critical path: `-DBATTERY_VCRIT_MV=4300` (never in a release; also moves the recovery level, +150 mV). ADC_EN (GPIO43) is
  high only while measuring and held low in sleep. The ADC sequence and the NVS flag are shared in `board_esp32s3.cpp`
  (`s3::readBatteryMv(adc, en, settleMs, mulNum, mulDen)`); TRMNL (FW-117): GPIO1 ADC, load switch GPIO6 (held LOW in sleep),
  settle 10 ms, x2 - all [open] until spike B-1...B-3.
- Pairing (token, Homey URL, name) lives in LittleFS `/pairing.json` (`pairing.cpp`); Wi-Fi in the SDK config.
- The device API (port 80) and mDNS only run while connected and no setup portal is open (port conflict).
- Every requirement implemented → reference its ID in the commit message; non-obvious code → ID in a comment.

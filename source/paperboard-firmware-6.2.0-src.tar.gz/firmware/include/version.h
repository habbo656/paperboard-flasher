#pragma once

#ifndef FW_VERSION  // tools/ota-test.sh builds a test image with -DFW_VERSION=\"X.Y.Z\"
#define FW_VERSION "6.2.0"
#endif
// The device <-> Homey protocol version is per board: board::API_VERSION (NFR-041, IF-020, IF-021).

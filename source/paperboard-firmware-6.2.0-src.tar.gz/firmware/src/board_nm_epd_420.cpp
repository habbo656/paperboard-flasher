// Board layer for the NM-EPD-420 (ESP32-S3, tri-colour 4.2" panel), see board.h and docs/hardware.md section 7.
// Chip, Wi-Fi, RTC, mDNS, OTA confirm and deep sleep are shared with the TRMNL in board_esp32s3.cpp (ADR-25).
#include "board.h"
#include "board_esp32s3.h"

#include <Arduino.h>
#include <Preferences.h>
#include <Wire.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <driver/i2s.h>
#include <esp_sleep.h>

#include "aht20.h"
#include "button_press.h"
#include "event_queue.h"
#include "sleep_logic.h"
#include "sound.h"

namespace board {

#if defined(PB_PANEL_GDEY0420F51)
const char* const ID = "nm_epd_420_4c";  // IF-023
const char* const FRAME_FORMAT = "bwry";
const char* const PANEL = "GDEY0420F51";
#else
const char* const ID = "nm_epd_420";
const char* const FRAME_FORMAT = "bwr";
const char* const PANEL = "GDEY042Z98";
#endif
const char* const RESET_HINT = "hold USER for 5 s";

// USER button (hardware.md section 7): GPIO45 is a strapping pin (VDD_SPI), never hold it while resetting.
// Pin and active level are vendor values, [open] until check N-7 (#47).
static constexpr int PIN_USER = 45;
static constexpr int USER_ACTIVE_LEVEL = LOW;
// BOOT (GPIO0, strapping pin) as a second event button (FW-080): off until check N-7 confirms it at runtime [open].
static constexpr bool BOOT_BUTTON = false;
static constexpr int PIN_BOOT = 0;
static constexpr int BOOT_ACTIVE_LEVEL = LOW;
static constexpr int PIN_TEMP_CTL = 40;  // AHT20 power gate, HIGH = on (#80)
static constexpr int PIN_CODEC_EN = 44;  // ES8311 power enable, HIGH = on (N-14, #83)
static constexpr int PIN_PA = 41;        // NS4150B amplifier enable, HIGH = on (N-14); no pull-up fitted, must be driven
static constexpr int PIN_BATT_ADC = 3;   // ADC1_CH2 behind a 2:1 divider (hardware.md N-16)
static constexpr int PIN_ADC_EN = 43;    // HIGH = divider on; U0TXD is unused (USB-CDC console), so it is free (N-18 rule)

namespace s3 {
void boardBegin() {
  gpio_hold_dis((gpio_num_t)PIN_TEMP_CTL);
  gpio_hold_dis((gpio_num_t)PIN_CODEC_EN);  // FW-106: held low through deep sleep, released here
  gpio_hold_dis((gpio_num_t)PIN_PA);
  gpio_hold_dis((gpio_num_t)PIN_ADC_EN);
  pinMode(PIN_USER, INPUT_PULLUP);
  if (BOOT_BUTTON) pinMode(PIN_BOOT, INPUT_PULLUP);
}

// ext0 is level triggered: while BOOT is held the chip would wake again at once, in a loop (hardware.md N-15).
// So it is only armed while BOOT is released; a held BOOT just means this sleep has the timer only.
void armWake() {
  pinMode(PIN_BOOT, INPUT_PULLUP);
  delay(2);
  if (digitalRead(PIN_BOOT) != BOOT_ACTIVE_LEVEL) {
    rtc_gpio_pullup_en(GPIO_NUM_0);
    rtc_gpio_pulldown_dis(GPIO_NUM_0);
    esp_sleep_enable_ext0_wakeup(GPIO_NUM_0, 0);
  }
}
}  // namespace s3

// FW-112: ADC_EN is only high while measuring (the divider would draw current in sleep). With the settle time of 5 ms
// (N-16: stable from 1 ms) and the eFuse calibration of analogReadMilliVolts; no further offset (no meter, ADR-24).
uint16_t batteryReadMv() {
  analogSetPinAttenuation(PIN_BATT_ADC, ADC_11db);
  pinMode(PIN_ADC_EN, OUTPUT);
  digitalWrite(PIN_ADC_EN, HIGH);
  delay(5);
  uint32_t sum = 0;
  for (int i = 0; i < 16; i++) sum += analogReadMilliVolts(PIN_BATT_ADC);
  digitalWrite(PIN_ADC_EN, LOW);
  return (uint16_t)(sum / 16 * 2);  // pin mV x 2 for the divider; at most ~3 V x 2, fits
}

// FW-113, IF-006: the armed flag lives in NVS (namespace "pb", key "batt"), read once, written on change only.
static int8_t batteryModeCache = -1;
bool batteryMode() {
  if (batteryModeCache < 0) {
    Preferences p;
    batteryModeCache = p.begin("pb", true) ? p.getUChar("batt", 0) == 1 : 0;
    p.end();
  }
  return batteryModeCache == 1;
}
void setBatteryMode(bool on) {
  if (batteryMode() == on) return;
  Preferences p;
  if (p.begin("pb", false)) {
    p.putUChar("batt", on ? 1 : 0);
    p.end();
    batteryModeCache = on ? 1 : 0;
  }
}

// FW-102/FW-080: USER classified as short/long (on release) or reset (>= 5 s, while held). The state machines
// ignore a button that is already held at boot. BOOT never resets.
static core::ButtonPress userPress;
static core::ButtonPress bootPress(50, 1000, 3000, 5000, false);
static bool resetRequested = false;

// Pending presses for popButtonEvent (2 slots; further presses before the next events::loop() are dropped).
struct Pending { uint8_t button, press; };
static Pending pending[2];
static uint8_t pendingCount = 0;

static void latch(core::ButtonId id, core::Press p) {
  if (pendingCount < 2) pending[pendingCount++] = Pending{(uint8_t)id, (uint8_t)p};
}

// Also called from the GxEPD2 busy callback (display.cpp): only digitalRead, no network, no allocation.
void loop() {
  static uint32_t last = 0;
  const uint32_t now = millis();
  if (now - last < 10) return;
  last = now;
  const core::Press u = userPress.update(digitalRead(PIN_USER) == USER_ACTIVE_LEVEL, now);
  if (u == core::Press::Reset) resetRequested = true;
  else if (u != core::Press::None) latch(core::ButtonId::User, u);
  if (BOOT_BUTTON) {
    const core::Press b = bootPress.update(digitalRead(PIN_BOOT) == BOOT_ACTIVE_LEVEL, now);
    if (b != core::Press::None) latch(core::ButtonId::Boot, b);
  }
}

bool factoryResetRequested() {
  const bool r = resetRequested;
  resetRequested = false;
  return r;
}

// FW-081, FW-104 (#80): AHT20 on I2C address 0x38. Pins and power gate per docs/hardware.md section 7 (verified, N-11):
// SDA 39, SCL 38 (shared with the ES8311 codec at 0x18, unused), TEMP_CTL 40 powers the sensor (HIGH = on).
// -1 = not configured, the sensor then reads "missing" and no I2C code runs.
static constexpr int PIN_SDA = 39;
static constexpr int PIN_SCL = 38;
static constexpr uint32_t POWER_UP_MS = 100;  // AHT20 datasheet: >= 100 ms after power-on before the first command
static constexpr uint32_t POWER_OFF_MS = 100;  // gate held low for a power cycle (recovery after repeated failures)
static constexpr uint8_t AHT20_ADDR = 0x38;

static core::ClimateSchedule climateSched;
static bool i2cStarted = false;
static bool sensorInited = false;      // calibrated bit confirmed (or init command sent)
static bool sensorAnswered = false;    // the chip ever acked on the bus
static int16_t lastDeciC = 0;
static uint8_t lastRh = 0;
static uint32_t debugFailUntil = 0;
static bool debugFailActive = false;
static bool gatePowered = false;       // TEMP_CTL driven HIGH at least once
static bool gateOn = false;
static uint32_t gateChangeAt = 0;      // millis() of the last gate change

// The bus is shared by the AHT20 (0x38) and the ES8311 (0x18); both are used from loop()/poll context, never concurrently.
static void ensureI2c() {
  if (i2cStarted) return;
  Wire.begin(PIN_SDA, PIN_SCL, 100000);
  Wire.setTimeOut(20);  // ms: a stuck bus must never block the loop (FW-104)
  i2cStarted = true;
}

static bool i2cWrite(const uint8_t* d, size_t n) {
  Wire.beginTransmission(AHT20_ADDR);
  Wire.write(d, n);
  return Wire.endTransmission() == 0;
}

// Status byte 0x71; sends the init command if the calibrated bit (3) is not set. False if the chip does not answer.
static bool sensorInit() {
  const uint8_t st = 0x71;
  if (!i2cWrite(&st, 1) || Wire.requestFrom((int)AHT20_ADDR, 1) != 1) return false;
  sensorAnswered = true;
  const uint8_t status = (uint8_t)Wire.read();
  if (!(status & 0x08)) {
    const uint8_t init[3] = {0xBE, 0x08, 0x00};
    i2cWrite(init, 3);
    return false;  // calibrates in ~10 ms; the next cycle sees the bit set
  }
  return true;
}

void climateLoop() {
  if (PIN_SDA < 0 || PIN_SCL < 0) return;
  const uint32_t now = millis();
  if (debugFailActive && (int32_t)(now - debugFailUntil) >= 0) debugFailActive = false;
  // Power gate, non-blocking: HIGH on first call, then no I2C until POWER_UP_MS after every switch-on; a power cycle
  // keeps it low for POWER_OFF_MS.
  if (!gatePowered) {
    gatePowered = gateOn = true;
    pinMode(PIN_TEMP_CTL, OUTPUT);
    digitalWrite(PIN_TEMP_CTL, HIGH);
    gateChangeAt = now;
  }
  if (!gateOn) {
    if (now - gateChangeAt < POWER_OFF_MS) return;
    digitalWrite(PIN_TEMP_CTL, HIGH);
    gateOn = true;
    gateChangeAt = now;
  }
  if (now - gateChangeAt < POWER_UP_MS) return;
  const auto action = climateSched.next(now);
  if (action == core::ClimateSchedule::Action::Idle) return;
  ensureI2c();
  if (action == core::ClimateSchedule::Action::Trigger) {
    if (climateSched.takeSoftReset()) {
      // Recovery after repeated failures: power-cycle the sensor via TEMP_CTL (also clears a wedged chip that ignores
      // the soft-reset command). The next cycle starts after POWER_OFF_MS + POWER_UP_MS.
      digitalWrite(PIN_TEMP_CTL, LOW);
      gateOn = false;
      gateChangeAt = now;
      sensorInited = false;
      return;
    }
    if (debugFailActive) return climateSched.failed(now);
    if (!sensorInited) sensorInited = sensorInit();
    const uint8_t trig[3] = {0xAC, 0x33, 0x00};
    if (sensorInited && i2cWrite(trig, 3)) climateSched.triggered(now);
    else climateSched.failed(now);
    return;
  }
  uint8_t f[7];
  int16_t t;
  uint8_t h;
  if (!debugFailActive && Wire.requestFrom((int)AHT20_ADDR, 7) == 7) {
    for (auto& b : f) b = (uint8_t)Wire.read();
    if (core::aht20Parse(f, &t, &h)) {
      lastDeciC = t;
      lastRh = h;
      sensorAnswered = true;
      return climateSched.readOk(now);
    }
  }
  climateSched.failed(now);
}

bool climate(int16_t* deciC, uint8_t* rhPct) {
  if (!climateSched.fresh(millis())) return false;
  *deciC = lastDeciC;
  *rhPct = lastRh;
  return true;
}

const char* climateState() {
  if (climateSched.fresh(millis())) return "ok";
  return sensorAnswered ? "error" : "missing";
}

void debugClimateFail() {
  debugFailActive = true;
  debugFailUntil = millis() + 300000UL;
}

// FW-106 (#83): ES8311 codec + NS4150B amplifier. Pins and the listening test: docs/hardware.md section 7 (N-14, passed
// 2026-10-24 with hardware-tests/nm-epd-420-audio-test, variant 1). Everything is off except during a chime: codec
// EN low, PA low, no I2S driver (no DMA heap between chimes), MCLK (LEDC 4.096 MHz on GPIO21) detached.
static constexpr uint8_t ES8311_ADDR = 0x18;
static constexpr int PIN_MCLK = 21, PIN_BCLK = 15, PIN_LRCK = 17, PIN_DOUT = 18;
static constexpr i2s_port_t I2S_PORT = I2S_NUM_0;
static constexpr uint8_t MCLK_LEDC_CHANNEL = 0;
static constexpr size_t BLOCK = 128;  // frames per i2s_write (512 B of stereo samples on the stack)

enum class AudioState : uint8_t { Unprobed, Ok, Missing, Error };
static AudioState audioSt = AudioState::Unprobed;

static bool codecWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(ES8311_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission() == 0;
}

static bool codecAcks() {
  Wire.beginTransmission(ES8311_ADDR);
  return Wire.endTransmission() == 0;
}

static void audioOff() {
  digitalWrite(PIN_PA, LOW);
  digitalWrite(PIN_CODEC_EN, LOW);
}

void audioBegin() {
  pinMode(PIN_PA, OUTPUT);
  digitalWrite(PIN_PA, LOW);
  pinMode(PIN_CODEC_EN, OUTPUT);
  digitalWrite(PIN_CODEC_EN, HIGH);
  delay(50);
  ensureI2c();
  audioSt = codecAcks() ? AudioState::Ok : AudioState::Missing;
  audioOff();
  Serial.printf("[audio] ES8311 %s\n", audioSt == AudioState::Ok ? "answered at 0x18" : "NOT FOUND at 0x18");
}

const char* audioState() {
  switch (audioSt) {
    case AudioState::Ok: return "ok";
    case AudioState::Error: return "error";
    default: return "missing";
  }
}

// Reference sequence for MCLK 4.096 MHz / 16 kHz (ratio 256), 16-bit I2S, slave mode (as in the N-14 sketch).
static bool codecInit(uint8_t dacVol) {
  static const uint8_t seq[][2] = {
      {0x00, 0x1F}, {0x00, 0x00}, {0x00, 0x80},  // reset, then power on as slave
      {0x01, 0x3F}, {0x02, 0x00}, {0x03, 0x10}, {0x04, 0x20}, {0x05, 0x00}, {0x06, 0x03}, {0x07, 0x00}, {0x08, 0xFF},
      {0x09, 0x0C}, {0x0A, 0x0C}, {0x0D, 0x01}, {0x0E, 0x02}, {0x12, 0x00}, {0x13, 0x10}, {0x1C, 0x6A}, {0x37, 0x08},
  };
  bool ok = true;
  for (size_t i = 0; i < sizeof seq / sizeof seq[0]; i++) {
    ok = codecWrite(seq[i][0], seq[i][1]) && ok;
    if (i == 0) delay(20);  // reset settle
  }
  return codecWrite(0x32, dacVol) && ok;
}

static bool i2sWrite(const int16_t* mono, size_t n) {  // duplicates the mono samples to both channels
  int16_t st[BLOCK * 2];
  for (size_t i = 0; i < n; i++) st[2 * i] = st[2 * i + 1] = mono[i];
  size_t w = 0;
  return i2s_write(I2S_PORT, st, n * 4, &w, 1000 / portTICK_PERIOD_MS) == ESP_OK && w == n * 4;
}

static void i2sSilence(uint32_t ms) {
  int16_t z[BLOCK] = {};
  for (uint32_t left = core::SOUND_RATE_HZ * ms / 1000; left;) {
    const size_t n = left < BLOCK ? left : BLOCK;
    i2sWrite(z, n);
    left -= n;
  }
}

bool playChime(uint8_t chime, uint8_t volume) {
  if (audioSt != AudioState::Ok) return false;
  core::ChimeSynth synth;
  if (!synth.start(chime)) return false;
  digitalWrite(PIN_CODEC_EN, HIGH);
  delay(50);
  ledcSetup(MCLK_LEDC_CHANNEL, 4096000, 1);  // 4.096 MHz, 1-bit = 50 % square wave (IDF 4.4 cannot route I2S MCLK to GPIO21)
  ledcAttachPin(PIN_MCLK, MCLK_LEDC_CHANNEL);
  ledcWrite(MCLK_LEDC_CHANNEL, 1);
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  cfg.sample_rate = core::SOUND_RATE_HZ;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 4;
  cfg.dma_buf_len = 256;
  cfg.use_apll = false;
  cfg.tx_desc_auto_clear = true;
  bool ok = i2s_driver_install(I2S_PORT, &cfg, 0, nullptr) == ESP_OK;
  if (ok) {
    i2s_pin_config_t pins = {};
    pins.mck_io_num = I2S_PIN_NO_CHANGE;
    pins.bck_io_num = PIN_BCLK;
    pins.ws_io_num = PIN_LRCK;
    pins.data_out_num = PIN_DOUT;
    pins.data_in_num = I2S_PIN_NO_CHANGE;
    ok = i2s_set_pin(I2S_PORT, &pins) == ESP_OK;
    if (ok) {
      i2sSilence(50);  // BCLK/LRCK settle before the codec locks
      ok = codecInit(0x00);  // muted until the amplifier is on
      i2sSilence(100);
      digitalWrite(PIN_PA, HIGH);
      delay(30);
      codecWrite(0x32, core::volumeToDac(volume));
      int16_t buf[BLOCK];
      for (size_t n; ok && (n = synth.render(buf, BLOCK)) > 0;) {
        ok = i2sWrite(buf, n);
      }
      i2sSilence(50);  // the chime ends at 0; let the DMA queue drain before the amplifier goes off
      codecWrite(0x32, core::DAC_VOL_MUTE);
      i2sSilence(30);
    }
    i2s_driver_uninstall(I2S_PORT);
  }
  ledcDetachPin(PIN_MCLK);
  audioOff();
  if (!ok) audioSt = AudioState::Error;
  return ok;
}

bool userHeld() { return digitalRead(PIN_USER) == USER_ACTIVE_LEVEL; }

bool popButtonEvent(uint8_t* button, uint8_t* press) {
  if (!pendingCount) return false;
  *button = pending[0].button;
  *press = pending[0].press;
  pending[0] = pending[1];
  pendingCount--;
  return true;
}

// AHT20 off (#80): TEMP_CTL low and held through deep sleep; the next climateLoop() drives it HIGH again.
void prepareSleep() {
  if (i2cStarted) Wire.end();
  pinMode(PIN_TEMP_CTL, OUTPUT);
  digitalWrite(PIN_TEMP_CTL, LOW);
  gpio_hold_en((gpio_num_t)PIN_TEMP_CTL);
  // FW-106: amplifier and codec off, held low through deep sleep (the amp enable has no pull-down).
  pinMode(PIN_PA, OUTPUT);
  digitalWrite(PIN_PA, LOW);
  pinMode(PIN_CODEC_EN, OUTPUT);
  digitalWrite(PIN_CODEC_EN, LOW);
  gpio_hold_en((gpio_num_t)PIN_PA);
  gpio_hold_en((gpio_num_t)PIN_CODEC_EN);
  pinMode(PIN_ADC_EN, OUTPUT);   // FW-112: divider off through the sleep
  digitalWrite(PIN_ADC_EN, LOW);
  gpio_hold_en((gpio_num_t)PIN_ADC_EN);
  gpio_deep_sleep_hold_en();
}

}  // namespace board

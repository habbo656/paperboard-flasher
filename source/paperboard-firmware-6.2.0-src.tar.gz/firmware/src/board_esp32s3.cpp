// Board layer shared by the two ESP32-S3 boards (NM-EPD-420, TRMNL 7.5"), see board.h, ADR-19 and ADR-25: chip, reset,
// RTC memory, Wi-Fi, LittleFS, mDNS, OTA confirm, deep sleep. Board-specific parts (pins, buttons, sensors, begin(),
// prepareSleep(), the wake button) live in board_<name>.cpp and are reached through board_esp32s3.h.
#include "board.h"
#include "board_esp32s3.h"

#include <Arduino.h>
#include <ESPmDNS.h>
#include <LittleFS.h>
#include <WiFi.h>
#include <esp_heap_caps.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <esp_ota_ops.h>
#include <esp_sleep.h>
#include <esp_random.h>
#include <esp_system.h>
#include <esp_wifi.h>

#include "sleep_logic.h"

// RTC counter in microseconds (soc/esp32s3/rtc.h, not reachable through a public header); it keeps counting in deep sleep.
extern "C" uint64_t esp_rtc_get_time_us(void);

// ADR-18, NFR-012: keep the new image "pending verify" until ota::confirmBoot() (first answered poll). By default
// Arduino confirms it in initArduino(), before Wi-Fi is up. Any reset before confirmation makes the bootloader
// start the previous slot.
extern "C" bool verifyRollbackLater() { return true; }

namespace board {

void begin() {
  gpio_deep_sleep_hold_dis();  // FW-038: release the pad holds of the last deep sleep
  Serial.setTxTimeoutMs(SERIAL_TX_TIMEOUT_MS);  // HWCDC: do not block on logging when no host reads the port (runs on a charger)
  s3::boardBegin();
}

uint32_t chipId() {
  // The eFuse MAC holds byte 0 in the lowest byte; bytes 0..2 are the vendor OUI, the last three differ per chip.
  return (uint32_t)(ESP.getEfuseMac() >> 24) & 0xFFFFFF;
}

const char* resetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "power-on";
    case ESP_RST_SW: return "restart";
    case ESP_RST_PANIC: return "exception";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT: return "hw-watchdog";
    case ESP_RST_DEEPSLEEP: return "deep-sleep";
    default: return "unknown";  // brown-out, external reset, ...
  }
}

uint32_t freeHeap() { return heap_caps_get_free_size(MALLOC_CAP_INTERNAL); }
uint32_t maxBlock() { return heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL); }
void restart() {
  esp_restart();
  for (;;) {}
}
void hardReset() { restart(); }
uint32_t hwRandom() { return esp_random(); }
void otaConfirm() { esp_ota_mark_app_valid_cancel_rollback(); }  // ADR-18; harmless if already valid

// Survives software/watchdog resets but not power loss, like the ESP8266 RTC user memory. Garbage after power-on
// is rejected by the magic values of the users.
struct RtcArea {
  uint8_t health[8];
  uint8_t ota[40];
  uint8_t doubleReset[8];
  uint8_t sleep[48];     // core::SleepRecord (FW-038)
  uint8_t battery[12];   // core::BatteryRecord (FW-113)
  uint64_t sleepAtUs;    // esp_rtc_get_time_us() when going to sleep: slept time after a BOOT wake
};
static RTC_NOINIT_ATTR RtcArea rtcArea;

static uint8_t* rtcSlot(Rtc slot, size_t* cap) {
  switch (slot) {
    case Rtc::Health: *cap = sizeof(rtcArea.health); return rtcArea.health;
    case Rtc::Ota: *cap = sizeof(rtcArea.ota); return rtcArea.ota;
    case Rtc::Sleep: *cap = sizeof(rtcArea.sleep); return rtcArea.sleep;
    case Rtc::Battery: *cap = sizeof(rtcArea.battery); return rtcArea.battery;
    default: *cap = sizeof(rtcArea.doubleReset); return rtcArea.doubleReset;
  }
}
void rtcRead(Rtc slot, void* data, size_t bytes) {
  size_t cap;
  uint8_t* p = rtcSlot(slot, &cap);
  memcpy(data, p, bytes < cap ? bytes : cap);
}
void rtcWrite(Rtc slot, const void* data, size_t bytes) {
  size_t cap;
  uint8_t* p = rtcSlot(slot, &cap);
  memcpy(p, data, bytes < cap ? bytes : cap);
}

// The stored credentials are read first: with persistent(false) before the Wi-Fi driver is up, the S3 driver would not
// load them from NVS. persistent(false) then keeps the SDK/NVS from rewriting the station config on every wake.
bool wifiApInfo(uint8_t bssid[6], uint8_t* channel) {
  wifi_ap_record_t ap;
  if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) return false;
  memcpy(bssid, ap.bssid, 6);
  *channel = ap.primary;
  return true;
}
// Station config stored in NVS. WiFi.SSID() is no use here: on Arduino-ESP32 it returns the SSID of the *connected* AP,
// i.e. an empty string right after a wake (#84).
static bool storedStaConfig(String* ssid, String* psk) {
  WiFi.mode(WIFI_STA);  // esp_wifi_get_config fails before the driver is up
  wifi_config_t conf;
  memset(&conf, 0, sizeof(conf));
  if (esp_wifi_get_config(WIFI_IF_STA, &conf) != ESP_OK || !conf.sta.ssid[0]) return false;
  char s[33], p[65];
  memcpy(s, conf.sta.ssid, 32); s[32] = 0;
  memcpy(p, conf.sta.password, 64); p[64] = 0;
  *ssid = s;
  *psk = p;
  return true;
}
void wifiFastBegin(const uint8_t* bssid, uint8_t channel) {
  String ssid, psk;
  storedStaConfig(&ssid, &psk);
  if (core::chooseBeginPath(ssid.c_str()) == core::BeginPath::Stored) {
    WiFi.begin();  // stored credentials, no BSSID
    return;
  }
  WiFi.persistent(false);
  WiFi.begin(ssid.c_str(), psk.c_str(), channel, bssid);
}
void wifiNormalBegin() {
  String ssid, psk;
  storedStaConfig(&ssid, &psk);
  if (core::chooseBeginPath(ssid.c_str()) == core::BeginPath::Stored) {
    WiFi.begin();
    return;
  }
  WiFi.persistent(false);
  WiFi.begin(ssid.c_str(), psk.c_str());
}

void wifiDrop() { esp_wifi_disconnect(); }
bool wifiCredentialsSaved() {
  WiFi.mode(WIFI_STA);  // brings the driver up; esp_wifi_get_config fails (and leaves conf untouched) before that
  wifi_config_t conf;
  memset(&conf, 0, sizeof(conf));
  if (esp_wifi_get_config(WIFI_IF_STA, &conf) != ESP_OK) return false;
  return conf.sta.ssid[0] != 0;
}
void wifiModemSleep() { WiFi.setSleep(true); }

bool fsBegin() { return LittleFS.begin(true); }  // formats on first use

bool mdnsBegin(const char* host) { return MDNS.begin(host); }
static const char* svcName = "paperboard";
void mdnsAddService(const char* name, uint16_t port) {
  svcName = name;
  MDNS.addService(name, "tcp", port);
}
void mdnsTxt(const char* key, const char* value) { MDNS.addServiceTxt(svcName, "tcp", key, value); }
void mdnsTxtReplace(const char* key, const char* value) { MDNS.addServiceTxt(svcName, "tcp", key, value); }  // sets
void mdnsAnnounce() {}  // the mDNS responder re-announces changed TXT records itself
void mdnsUpdate() {}
void mdnsEnd() { MDNS.end(); }

bool factoryResetAtBoot() { return false; }

// Deep sleep (FW-038, FW-107). Timer wake plus the board's button (s3::armWake(), e.g. ext0 on NM-EPD-420 BOOT, hardware.md N-15).
core::WakeKind wakeReason() {
  if (esp_reset_reason() != ESP_RST_DEEPSLEEP) return core::WakeKind::Boot;
  switch (esp_sleep_get_wakeup_cause()) {
    case ESP_SLEEP_WAKEUP_TIMER: return core::WakeKind::Timer;
    case ESP_SLEEP_WAKEUP_EXT0: return core::WakeKind::Button;
    default: return core::WakeKind::Boot;
  }
}

// The RTC timer keeps counting in deep sleep, so the delta is exact also after a BOOT wake. Plausibility check against
// the planned time (a wrong value would only skew X-Uptime-S).
uint32_t sleptMs(uint32_t plannedMs) {
  const uint64_t now = esp_rtc_get_time_us();
  if (now < rtcArea.sleepAtUs) return plannedMs;
  const uint64_t ms = (now - rtcArea.sleepAtUs) / 1000;
  return ms > (uint64_t)plannedMs + 10000 ? plannedMs : (uint32_t)ms;
}

void deepSleep(uint32_t seconds) {
  esp_sleep_enable_timer_wakeup((uint64_t)seconds * 1000000ULL);
  s3::armWake();  // the board's wake button (ext0 is level triggered: see the board file)
  rtcArea.sleepAtUs = esp_rtc_get_time_us();
  Serial.flush();
#ifdef PB_DEBUG
  delay(300);  // USB-CDC: the host reads the last log lines (they are otherwise lost, hardware.md N-15)
#endif
  esp_deep_sleep_start();
  for (;;) {}
}

}  // namespace board

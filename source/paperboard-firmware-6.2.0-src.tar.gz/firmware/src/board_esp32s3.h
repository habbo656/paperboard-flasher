#pragma once
// Hooks of the board-specific files for the shared ESP32-S3 code in board_esp32s3.cpp (ADR-25). Not for other modules.

namespace board {
namespace s3 {

void boardBegin();   // from board::begin(): release pad holds, configure the board's pins
void armWake();      // before the deep sleep: arm the board's wake button (timer wake is armed by the caller)

}  // namespace s3
}  // namespace board

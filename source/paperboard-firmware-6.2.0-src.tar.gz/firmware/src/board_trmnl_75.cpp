// Board layer for the TRMNL 7.5" OG DIY kit (XIAO ESP32-S3 PLUS on the Seeed XIAO ePaper driver board, 800x480 b/w),
// see board.h, board_trmnl_75.h and docs/hardware.md section 8. Chip, Wi-Fi, RTC, mDNS, OTA confirm and deep sleep are
// shared with the NM-EPD-420 in board_esp32s3.cpp (ADR-25). FW-114.
//
// Every pin and level below is a VENDOR fact (Seeed firmware) and [open] until the owner has run spike S3 (T-2, T-4).
#include "board.h"
#include "board_esp32s3.h"

#include <Arduino.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <esp_sleep.h>

#include "button_press.h"

namespace board {

const char* const ID = "trmnl_75";
const char* const FRAME_FORMAT = "bw";
const char* const PANEL = "GDEY075T7";  // [open] T-2: candidate class GxEPD2_750_GDEY075T7, fallback GxEPD2_750_T7
const char* const RESET_HINT = "hold KEY3 for 5 s";  // [open] T-4: which key is the reset key

// [open] T-4: KEY3 on GPIO5 (Seeed include/config.h). Level and pull unverified: placeholder = pull-up, pressed = LOW.
// GPIO5 is an RTC pad of the S3, so it can wake the chip from deep sleep (ext0).
static constexpr int PIN_KEY3 = 5;
static constexpr int KEY3_ACTIVE_LEVEL = LOW;

namespace s3 {
void boardBegin() { pinMode(PIN_KEY3, INPUT_PULLUP); }

// [open] T-5. ext0 is level triggered (as on the NM-EPD-420, hardware.md N-15): armed only while KEY3 is released, else
// the chip would wake again at once.
void armWake() {
  pinMode(PIN_KEY3, INPUT_PULLUP);
  delay(2);
  if (digitalRead(PIN_KEY3) != KEY3_ACTIVE_LEVEL) {
    rtc_gpio_pullup_en((gpio_num_t)PIN_KEY3);
    rtc_gpio_pulldown_dis((gpio_num_t)PIN_KEY3);
    esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_KEY3, KEY3_ACTIVE_LEVEL);
  }
}
}  // namespace s3

// FW-102: KEY3 held >= 5 s = factory reset (core::ButtonPress ignores a key that is already held at boot; short and long
// presses are classified but not reported, HAS_BUTTONS is false). Also called from the GxEPD2 busy callback (display.cpp):
// only digitalRead, no network, no allocation.
static core::ButtonPress key3Press;
static bool resetRequested = false;

void loop() {
  static uint32_t last = 0;
  const uint32_t now = millis();
  if (now - last < 10) return;
  last = now;
  if (key3Press.update(digitalRead(PIN_KEY3) == KEY3_ACTIVE_LEVEL, now) == core::Press::Reset) resetRequested = true;
}

bool factoryResetRequested() {
  const bool r = resetRequested;
  resetRequested = false;
  return r;
}

bool userHeld() { return digitalRead(PIN_KEY3) == KEY3_ACTIVE_LEVEL; }

// Nothing to switch off yet: no sensor, codec or divider on this board in #112 ([open] T-5: pad holds for the panel pins).
void prepareSleep() {}

}  // namespace board

#include "display.h"

#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <qrcode.h>

#include "board.h"
#include "status_icon.h"

#if defined(PB_BOARD_D1_MINI)
#include <GxEPD2_BW.h>
#else
#include <GxEPD2_3C.h>
#endif

namespace display {

// Small page buffer (400 x 30 px = 1 500 B) for local screens drawn with GFX; received frames are
// written straight from the caller's frame buffer, so no second 15 KB buffer is needed.
static constexpr uint16_t PAGE_HEIGHT = 30;
#if defined(PB_BOARD_D1_MINI)
static GxEPD2_BW<GxEPD2_420, PAGE_HEIGHT> epd(GxEPD2_420(/*CS=D8*/ 15, /*DC=D1*/ 5, /*RST=D2*/ 4, /*BUSY=D6*/ 12));

void begin() {
  // initial = true: the first refresh is a full one; the panel keeps its old image until then
  epd.init(0, true, 2, false);
}
#else
// NM-EPD-420 pins (docs/hardware.md section 7): vendor values, [open] until check N-3 (#47).
static constexpr int8_t PIN_SCK = 2, PIN_MOSI = 1, PIN_CS = 46, PIN_DC = 4, PIN_RST = 5, PIN_BUSY = 6;
static GxEPD2_3C<GxEPD2_420c_GDEY042Z98, PAGE_HEIGHT> epd(GxEPD2_420c_GDEY042Z98(PIN_CS, PIN_DC, PIN_RST, PIN_BUSY));

void begin() {
  SPI.begin(PIN_SCK, -1, PIN_MOSI, PIN_CS);
  epd.init(0, true, 2, false, SPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
}
#endif

static bool firstRefreshDone = false;
static int lastScreenId = 0;
static uint32_t lastRefreshAt = 0;
static bool refreshedOnce = false;

// FW-103: remember when the panel was last refreshed (any content); compiled out for boards without a floor.
static void markRefresh() {
  if (board::MIN_REFRESH_MS > 0) {
    lastRefreshAt = millis();
    refreshedOnce = true;
  }
}

bool lastRefresh(uint32_t* ms) {
  if (board::MIN_REFRESH_MS > 0) {
    *ms = lastRefreshAt;
    return refreshedOnce;
  } else {
    return false;
  }
}

int lastScreen() { return lastScreenId; }

#if defined(PB_BOARD_D1_MINI)
bool showFrame(const uint8_t* frame, bool full) {
  auto& e = epd.epd2;
  full = full || !firstRefreshDone;
  if (full) {
    e.writeImageForFullRefresh(frame, 0, 0, 400, 300);
    e.refresh(false);
  } else {
    e.writeImage(frame, 0, 0, 400, 300);
    e.refresh(true);
  }
  // Controller keeps "previous" image RAM for differential partial updates → sync it to the new frame
  e.writeImageAgain(frame, 0, 0, 400, 300);
  e.powerOff();  // FW-036
  firstRefreshDone = true;
  lastScreenId = -1;
  return full;
}

#else
// FW-100: bwr panel – the black plane is `frame`, the red plane follows it in the buffer. Full refresh only.
bool showFrame(const uint8_t* frame, bool) {
  auto& e = epd.epd2;
  e.writeImage(frame, frame + FRAME_BYTES, 0, 0, 400, 300);
  e.refresh(false);
  e.powerOff();  // FW-036
  markRefresh();
  lastScreenId = -1;
  return true;
}
#endif

#if defined(PB_BOARD_D1_MINI)
void showStatusIcon(uint8_t* frame, const core::Rect& area, bool offline) {
  const core::Window win = core::alignedWindow(area);
  if (!win.size()) return;
  static uint8_t buf[core::MAX_WINDOW_BYTES];
  core::copyWindow(frame, win, buf);
  if (offline) core::drawOfflineIcon(buf, win, area);
  auto& e = epd.epd2;
  e.writeImage(buf, win.x, win.y, win.w, win.h);
  e.refresh(win.x, win.y, win.w, win.h);
  e.writeImageAgain(buf, win.x, win.y, win.w, win.h);
  e.powerOff();
}
#else
// The window refresh of the 3C panel is a full refresh anyway (ADR-19): the icon is drawn into the frame, the panel
// refreshed, and the frame restored so that the icon can be removed again.
// FW-051: red ink under the icon would hide it, so the red window is cleared (0xFF) while the icon is shown.
void showStatusIcon(uint8_t* frame, const core::Rect& area, bool offline) {
  const core::Window win = core::alignedWindow(area);
  if (!win.size()) return;
  static uint8_t orig[core::MAX_WINDOW_BYTES], icon[core::MAX_WINDOW_BYTES], origRed[core::MAX_WINDOW_BYTES];
  uint8_t* red = frame + FRAME_BYTES;
  const size_t bpr = win.bytesPerRow();
  auto rowOf = [&](uint8_t* plane, int16_t r) { return plane + (size_t)(win.y + r) * (400 / 8) + win.x / 8; };
  core::copyWindow(frame, win, orig);
  core::copyWindow(red, win, origRed);
  if (offline) {
    memcpy(icon, orig, win.size());
    core::drawOfflineIcon(icon, win, area);
    for (int16_t r = 0; r < win.h; r++) {
      memcpy(rowOf(frame, r), icon + (size_t)r * bpr, bpr);
      memset(rowOf(red, r), 0xFF, bpr);
    }
  }
  showFrame(frame, true);
  for (int16_t r = 0; r < win.h; r++) {
    memcpy(rowOf(frame, r), orig + (size_t)r * bpr, bpr);
    memcpy(rowOf(red, r), origRed + (size_t)r * bpr, bpr);
  }
}
#endif

// Screen texts are PSTRs on the ESP8266 (#63, static RAM), formatted lines are RAM strings: print either.
static void printAny(const char* s) {
  if (board::inFlash(s)) epd.print(reinterpret_cast<const __FlashStringHelper*>(s));
  else epd.print(s);
}

static void drawTitle(const char* title) {
  epd.fillScreen(GxEPD_WHITE);
  epd.fillRect(0, 0, 400, 40, GxEPD_BLACK);
  epd.setTextColor(GxEPD_WHITE);
  epd.setFont(&FreeSansBold12pt7b);
  epd.setCursor(12, 28);
  printAny(title);
  epd.setTextColor(GxEPD_BLACK);
  epd.setFont(&FreeSans9pt7b);
}

static void drawLines(const char* const* lines, size_t count, int16_t x, int16_t y, int16_t step) {
  for (size_t i = 0; i < count; i++, y += step) {
    if (!lines[i]) continue;
    epd.setCursor(x, y);
    printAny(lines[i]);
  }
}

void showMessage(const char* title, const char* const* lines, size_t count, int screenId) {
  epd.setRotation(0);
  epd.setFullWindow();
  epd.firstPage();
  do {
    drawTitle(title);
    drawLines(lines, count, 12, 70, 24);
  } while (epd.nextPage());
  epd.powerOff();
  firstRefreshDone = true;
  markRefresh();
  lastScreenId = screenId;
}

void showSetup(const char* apName, const char* password, const char* qrPayload, bool wifiLost) {
  // QR version 4 (33x33 modules) holds up to 78 bytes at ECC_LOW – enough for the escaped payload
  static uint8_t qrData[(33 * 33 + 7) / 8];  // qrcode_getBufferSize(4), not constexpr
  QRCode qr;
  const bool qrOk = qrcode_initText(&qr, qrData, 4, ECC_LOW, qrPayload) == 0;
  const int16_t scale = 4;
  const int16_t qrPx = qrOk ? qr.size * scale : 0;
  const int16_t qrX = 400 - 12 - qrPx;
  const int16_t qrY = 56;

  char line[40];
  snprintf_P(line, sizeof(line), PSTR("Password: %s"), password);
  const char* lines[] = {
      wifiLost ? PSTR("Wi-Fi lost. To change it:") : PSTR("1. Scan the QR code or"),
      wifiLost ? PSTR("1. Scan the QR code or") : PSTR("   join this Wi-Fi:"),
      nullptr,  // AP name (bold, below)
      line,
      PSTR("2. Choose your home Wi-Fi"),
      PSTR("   and enter its password."),
      PSTR("3. No page opens? Go to"),
      PSTR("   http://192.168.4.1"),
  };
  epd.setRotation(0);
  epd.setFullWindow();
  epd.firstPage();
  do {
    drawTitle(wifiLost ? PSTR("Paperboard: Wi-Fi setup") : PSTR("Paperboard setup"));
    drawLines(lines, 8, 12, 70, 26);
    epd.setFont(&FreeSansBold12pt7b);
    epd.setCursor(24, 70 + 2 * 26 + 2);
    epd.print(apName);
    epd.setFont(&FreeSans9pt7b);
    epd.setCursor(12, 292);
    epd.print(F("Factory reset: "));
    epd.print(board::RESET_HINT);
    if (qrOk) {
      for (uint8_t y = 0; y < qr.size; y++)
        for (uint8_t x = 0; x < qr.size; x++)
          if (qrcode_getModule(&qr, x, y)) epd.fillRect(qrX + x * scale, qrY + y * scale, scale, scale, GxEPD_BLACK);
    }
  } while (epd.nextPage());
  epd.powerOff();
  firstRefreshDone = true;
  markRefresh();
  lastScreenId = -2;
}

}  // namespace display

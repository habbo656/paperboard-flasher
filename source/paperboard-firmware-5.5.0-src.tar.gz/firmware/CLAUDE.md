# CLAUDE.md – firmware/

Firmware for both boards (PlatformIO, Arduino): D1 mini (ESP8266) and NM-EPD-420 (ESP32-S3). Requirements: `../requirements/02-firmware-requirements.md`,
protocol: `../requirements/07-interface-specification.md`, hardware: `../docs/hardware.md`.

## Commands (run from `firmware/`)

| Purpose | Command |
|---|---|
| Build (release) | `../bin/pio run` (env `d1_mini`) |
| Build NM-EPD-420 (ESP32-S3) | `../bin/pio run -e nm_epd_420` (`nm_epd_420_debug` adds the debug commands; OTA as on the D1 mini, #50) |
| Build with debug commands | `../bin/pio run -e d1_mini_debug` (add `-t upload --upload-port …` to flash) |
| Unit tests (host) | `../bin/pio test -e native` |
| All gates (tests + build, short output) | `../tools/check.sh fw` |
| Flash (**ask the user first**) | `../bin/pio run -t upload --upload-port /dev/cu.usbserial-XXXX` (`ls /dev/cu.usbserial-*`) |
| Flash NM-EPD-420 (**ask the user first**) | ROM download mode (hold BOOT, press RESET), `../bin/pio run -e nm_epd_420 -t upload --upload-port /dev/cu.usbmodemXXXX` (`ls /dev/cu.usbmodem*`); esptool: `docs/development.md` §2 |
| Serial log | `../bin/pio device monitor --port /dev/cu.usbserial-XXXX` (interactive). Non-interactive: `../tools/serial-log.py d1_mini\|nm_epd_420 <log> <cmdfile>` (alias for `/dev/cu.usbserial-*` / `/dev/cu.usbmodem*`; reconnects after S3 re-enumeration); note that opening the port resets the board (RTS) |
| Device API | `curl http://<device-ip>/api/info` (pairing state, heap, RSSI) |
| Pairing for tests | via the Homey app (my.homey.app → Devices → +); factory reset: RESET twice |
| Debug commands (`d1_mini_debug` only) | send over serial (`../tools/serial-log.py` cmd file): `h` hang loop, `m` eat heap, `o` offline icon, `u` age last success 30 min, `w` simulate Wi-Fi loss (30 s/60 s), `d` drop Wi-Fi for 6 min, `r` heap + reset reason, `p` black/red/both test pattern (`nm_epd_420_debug`, FW-101), `x` corrupt the MD5 of the next OTA (wrong-MD5 test, FW-072), `l` eat heap until free < 14 000 B (between FW-055 and OTA guard, #59) |

## Structure

- `src/` – Arduino-dependent modules (Wi-Fi, HTTP, display, storage) and `main.cpp`.
- `lib/core/` – platform-independent logic (no `Arduino.h`), unit-tested in `test/` with the `native` env.
  Put everything that can be tested without hardware here (parsing, CRC, backoff, state machines).
- `include/version.h` – firmware and protocol version.

## Rules

- Board differences live only in `src/board.h` + `board_<name>.cpp` (one compiled per env via `build_src_filter`,
  ADR-19), `board_net.h` (library aliases) and the panel class in `display.cpp`. `#if PB_BOARD_*` appears nowhere
  else; shared modules call `board::` functions. No virtual classes, no heap. Factory reset: D1 mini RESET twice,
  NM-EPD-420 USER held 5 s (`core::LongPress`, FW-102).
- NM-EPD-420 in R5/#48: protocol 2, black plane only (red plane stays 0xFF in the 30 000 B frame buffer), full
  refresh only, no PSRAM. Flashing it needs ROM download mode (hold BOOT, press RESET) and the owner's OK.
- Display driver `GxEPD2_420` (panel V1). Received frames live in the single static buffer in `poller.cpp`
  (FW-033); never allocate another 15 KB buffer. After every refresh call `writeImageAgain` (partial updates
  need the controller's "previous" RAM in sync). The first refresh after boot is always full.
- Avoid `String` concatenation in loops and long-lived heap allocations (heap fragmentation, FW-055);
  prefer static buffers.
- Library versions are pinned in `platformio.ini` (NFR-044); update deliberately.
- Wi-Fi credentials are stored by the SDK/WiFiManager (they survive flashing; `erase_flash` or double reset
  clears them). Never call `WiFi.disconnect()` to drop a connection – it clears the station config;
  use `wifi_station_disconnect()`.
- WiFiManager (non-blocking): after `process()` returned true the portal is already shut down; calling
  `stopConfigPortal()` again crashes (freed web server). Use the guarded `stopPortal()` in connectivity.cpp.
- RTC memory (blocks of 4 B, user area from 64): **64–95 are reserved for the eboot command** (128 B; the core
  writes it on `ESP.restart()` after an OTA – using it makes eboot skip the new image, the device boots the old
  firmware again). Ours: 96–97 health (reset reason), 98–106 OTA boot state (`ota.cpp`), 110–111 double-reset detection.
- OTA (#50): one `ota.cpp` for both boards. D1 limit 1 MB, S3 2 MB (`board::OTA_MAX_BYTES`). The hint path must carry the
  device's own board segment on API 3 (`core::parseOtaHint(..., board)`); the first 24 image bytes are checked for the
  chip (`core::otaImageMatches`) before any flash write. S3 only: bootloader rollback, the image is confirmed by
  `ota::confirmBoot()` on the first answered poll (`verifyRollbackLater()` in `board_nm_epd_420.cpp`). Test builds
  with `-DPB_OTA_NO_CONFIRM` never confirm and restart after 30 s (rollback test). `default_16MB.csv` is frozen.
- Pairing (token, Homey URL, name) lives in LittleFS `/pairing.json` (`pairing.cpp`); Wi-Fi in the SDK config.
- The device API (port 80) and mDNS only run while connected and no setup portal is open (port conflict).
- Every requirement implemented → reference its ID in the commit message; non-obvious code → ID in a comment.

#include <unity.h>

#include "long_press.h"

void setUp() {}
void tearDown() {}

// Feeds `pressed` every 10 ms from `from` to `to` (ms); returns how many times it fired.
static int feed(core::LongPress& lp, bool pressed, uint32_t from, uint32_t to) {
  int fired = 0;
  for (uint32_t t = from; t <= to; t += 10) fired += lp.update(pressed, t) ? 1 : 0;
  return fired;
}

void test_fires_once_after_threshold() {
  core::LongPress lp;
  TEST_ASSERT_EQUAL(0, feed(lp, false, 0, 1000));
  TEST_ASSERT_EQUAL(1, feed(lp, true, 1010, 15000));  // held long: still only once
}

void test_short_of_threshold_does_not_fire() {
  core::LongPress lp;
  feed(lp, false, 0, 1000);
  TEST_ASSERT_EQUAL(0, feed(lp, true, 1010, 1010 + 4900));
  TEST_ASSERT_EQUAL(0, feed(lp, false, 6000, 7000));
}

void test_fires_at_threshold_not_before() {
  core::LongPress lp;
  feed(lp, false, 0, 1000);
  TEST_ASSERT_FALSE(lp.update(true, 1010));  // edge seen at 1010
  TEST_ASSERT_FALSE(lp.update(true, 1060));  // debounced
  TEST_ASSERT_FALSE(lp.update(true, 6000));  // 4.99 s after the edge
  TEST_ASSERT_TRUE(lp.update(true, 6010));   // 5.0 s
  TEST_ASSERT_FALSE(lp.update(true, 6020));
}

void test_held_at_start_never_fires() {
  core::LongPress lp;
  TEST_ASSERT_EQUAL(0, feed(lp, true, 0, 20000));
  TEST_ASSERT_EQUAL(0, feed(lp, false, 20010, 21000));
}

void test_press_after_boot_hold_fires() {
  core::LongPress lp;
  feed(lp, true, 0, 3000);
  feed(lp, false, 3010, 4000);
  TEST_ASSERT_EQUAL(1, feed(lp, true, 4010, 10000));
}

void test_bounce_is_ignored() {
  core::LongPress lp;
  feed(lp, false, 0, 1000);
  // 20 ms blips never become a press, and do not restart a real one
  TEST_ASSERT_FALSE(lp.update(true, 1000));
  TEST_ASSERT_FALSE(lp.update(true, 1020));
  TEST_ASSERT_FALSE(lp.update(false, 1030));
  TEST_ASSERT_EQUAL(0, feed(lp, false, 1040, 7000));
}

void test_release_bounce_inside_press_ignored() {
  core::LongPress lp;
  feed(lp, false, 0, 1000);
  feed(lp, true, 1010, 3000);
  lp.update(false, 3010);  // 10 ms glitch
  TEST_ASSERT_EQUAL(1, feed(lp, true, 3020, 7000));
}

void test_second_press_fires_again() {
  core::LongPress lp;
  feed(lp, false, 0, 1000);
  TEST_ASSERT_EQUAL(1, feed(lp, true, 1010, 7000));
  feed(lp, false, 7010, 8000);
  TEST_ASSERT_EQUAL(1, feed(lp, true, 8010, 14000));
}

void test_time_wraparound() {
  core::LongPress lp;
  const uint32_t base = 0xFFFFFFFFu - 2000;
  feed(lp, false, base, base + 500);
  int fired = 0;
  for (uint32_t i = 0; i <= 700; i++) fired += lp.update(true, base + 600 + i * 10) ? 1 : 0;
  TEST_ASSERT_EQUAL(1, fired);
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_fires_once_after_threshold);
  RUN_TEST(test_short_of_threshold_does_not_fire);
  RUN_TEST(test_fires_at_threshold_not_before);
  RUN_TEST(test_held_at_start_never_fires);
  RUN_TEST(test_press_after_boot_hold_fires);
  RUN_TEST(test_bounce_is_ignored);
  RUN_TEST(test_release_bounce_inside_press_ignored);
  RUN_TEST(test_second_press_fires_again);
  RUN_TEST(test_time_wraparound);
  return UNITY_END();
}

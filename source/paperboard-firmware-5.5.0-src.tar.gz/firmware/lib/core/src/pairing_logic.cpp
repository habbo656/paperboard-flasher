#include "pairing_logic.h"

#include <stdio.h>
#include <string.h>

namespace core {

bool validToken(const char* token) {
  if (!token) return false;
  const size_t n = strlen(token);
  if (n < 16 || n > PAIR_TOKEN_MAX) return false;
  for (const char* p = token; *p; p++) {
    const char c = *p;
    const bool ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || strchr("_-+/=", c);
    if (!ok) return false;
  }
  return true;
}

bool validHomeyUrl(const char* url) {
  if (!url) return false;
  const size_t n = strlen(url);
  return n > 8 && n <= PAIR_URL_MAX && strncmp(url, "http://", 7) == 0 && url[n - 1] == '/' && !strpbrk(url, " \r\n\"");
}

bool frameUrl(char* out, size_t cap, const char* homeyUrl) {
  const int n = snprintf(out, cap, "%sframe", homeyUrl);
  return n > 0 && (size_t)n < cap;
}

bool bearerMatches(const char* header, const char* token) {
  if (!header || !token || !*token || strncmp(header, "Bearer ", 7) != 0) return false;
  const char* given = header + 7;
  const size_t a = strlen(given), b = strlen(token);
  unsigned char diff = (unsigned char)(a != b);
  for (size_t i = 0; i < b; i++) diff |= (unsigned char)(token[i] ^ (i < a ? given[i] : 0));
  return diff == 0;
}

}  // namespace core

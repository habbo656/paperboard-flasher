#pragma once
// USER-button long press for the factory reset on the NM-EPD-420 (FW-102). Pure state machine, unit-tested in
// test/test_long_press. The active level of the button is a board constant: callers pass `pressed`.

#include <stdint.h>

namespace core {

class LongPress {
 public:
  explicit LongPress(uint32_t debounceMs = 50, uint32_t holdMs = 5000) : debounceMs_(debounceMs), holdMs_(holdMs) {}

  // Feed the (raw) button state with the current time. Returns true exactly once per press, when the debounced
  // press has lasted holdMs. A button already pressed at the first call (e.g. held at boot, GPIO45 is a
  // strapping pin) never fires: the machine arms only after a released state has been seen.
  bool update(bool pressed, uint32_t nowMs);

 private:
  uint32_t debounceMs_, holdMs_;
  bool started_ = false;
  bool raw_ = false;      // last raw sample
  bool stable_ = false;   // debounced state
  bool armed_ = false;    // a released state has been seen
  bool fired_ = false;    // already fired for the current press
  uint32_t rawSince_ = 0;    // time of the last raw change
  uint32_t pressStart_ = 0;  // time the current debounced press began
};

}  // namespace core

#include "long_press.h"

namespace core {

bool LongPress::update(bool pressed, uint32_t nowMs) {
  if (!started_) {
    started_ = true;
    raw_ = stable_ = pressed;
    rawSince_ = nowMs;
    armed_ = !pressed;
    return false;
  }
  if (pressed != raw_) {
    raw_ = pressed;
    rawSince_ = nowMs;
  }
  if (raw_ != stable_ && nowMs - rawSince_ >= debounceMs_) {
    stable_ = raw_;
    if (stable_) {
      pressStart_ = rawSince_;
      fired_ = false;
    } else {
      armed_ = true;
    }
  }
  if (stable_ && raw_ && armed_ && !fired_ && nowMs - pressStart_ >= holdMs_) {
    fired_ = true;
    return true;
  }
  return false;
}

}  // namespace core

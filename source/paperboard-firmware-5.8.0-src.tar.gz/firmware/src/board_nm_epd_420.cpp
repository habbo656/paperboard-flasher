// Board layer for the NM-EPD-420 (ESP32-S3, tri-colour 4.2" panel), see board.h and docs/hardware.md section 7.
#include "board.h"

#include <Arduino.h>
#include <ESPmDNS.h>
#include <LittleFS.h>
#include <WiFi.h>
#include <esp_heap_caps.h>
#include <esp_ota_ops.h>
#include <esp_random.h>
#include <esp_system.h>
#include <esp_wifi.h>

#include "button_press.h"
#include "event_queue.h"

// ADR-18, NFR-012: keep the new image "pending verify" until ota::confirmBoot() (first answered poll). By default
// Arduino confirms it in initArduino(), before Wi-Fi is up. Any reset before confirmation makes the bootloader
// start the previous slot.
extern "C" bool verifyRollbackLater() { return true; }

namespace board {

const char* const ID = "nm_epd_420";
const char* const FRAME_FORMAT = "bwr";
const char* const PANEL = "GDEY042Z98";
const char* const RESET_HINT = "hold USER for 5 s";

// USER button (hardware.md section 7): GPIO45 is a strapping pin (VDD_SPI), never hold it while resetting.
// Pin and active level are vendor values, [open] until check N-7 (#47).
static constexpr int PIN_USER = 45;
static constexpr int USER_ACTIVE_LEVEL = LOW;
// BOOT (GPIO0, strapping pin) as a second event button (FW-080): off until check N-7 confirms it at runtime [open].
static constexpr bool BOOT_BUTTON = false;
static constexpr int PIN_BOOT = 0;
static constexpr int BOOT_ACTIVE_LEVEL = LOW;

void begin() {
  Serial.setTxTimeoutMs(0);  // HWCDC: never block on logging when no host reads the port (runs on a charger)
  pinMode(PIN_USER, INPUT_PULLUP);
  if (BOOT_BUTTON) pinMode(PIN_BOOT, INPUT_PULLUP);
}

uint32_t chipId() {
  // The eFuse MAC holds byte 0 in the lowest byte; bytes 0..2 are the vendor OUI, the last three differ per chip.
  return (uint32_t)(ESP.getEfuseMac() >> 24) & 0xFFFFFF;
}

const char* resetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "power-on";
    case ESP_RST_SW: return "restart";
    case ESP_RST_PANIC: return "exception";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT: return "hw-watchdog";
    default: return "unknown";  // brown-out, external reset, ...
  }
}

uint32_t freeHeap() { return heap_caps_get_free_size(MALLOC_CAP_INTERNAL); }
uint32_t maxBlock() { return heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL); }
void restart() {
  esp_restart();
  for (;;) {}
}
void hardReset() { restart(); }
uint32_t hwRandom() { return esp_random(); }
void otaConfirm() { esp_ota_mark_app_valid_cancel_rollback(); }  // ADR-18; harmless if already valid

// Survives software/watchdog resets but not power loss, like the ESP8266 RTC user memory. Garbage after power-on
// is rejected by the magic values of the users.
struct RtcArea {
  uint8_t health[8];
  uint8_t ota[40];
  uint8_t doubleReset[8];
};
static RTC_NOINIT_ATTR RtcArea rtcArea;

static uint8_t* rtcSlot(Rtc slot, size_t* cap) {
  switch (slot) {
    case Rtc::Health: *cap = sizeof(rtcArea.health); return rtcArea.health;
    case Rtc::Ota: *cap = sizeof(rtcArea.ota); return rtcArea.ota;
    default: *cap = sizeof(rtcArea.doubleReset); return rtcArea.doubleReset;
  }
}
void rtcRead(Rtc slot, void* data, size_t bytes) {
  size_t cap;
  uint8_t* p = rtcSlot(slot, &cap);
  memcpy(data, p, bytes < cap ? bytes : cap);
}
void rtcWrite(Rtc slot, const void* data, size_t bytes) {
  size_t cap;
  uint8_t* p = rtcSlot(slot, &cap);
  memcpy(p, data, bytes < cap ? bytes : cap);
}

void wifiDrop() { esp_wifi_disconnect(); }
bool wifiCredentialsSaved() {
  WiFi.mode(WIFI_STA);  // brings the driver up; esp_wifi_get_config fails (and leaves conf untouched) before that
  wifi_config_t conf;
  memset(&conf, 0, sizeof(conf));
  if (esp_wifi_get_config(WIFI_IF_STA, &conf) != ESP_OK) return false;
  return conf.sta.ssid[0] != 0;
}
void wifiModemSleep() { WiFi.setSleep(true); }

bool fsBegin() { return LittleFS.begin(true); }  // formats on first use

bool mdnsBegin(const char* host) { return MDNS.begin(host); }
static const char* svcName = "paperboard";
void mdnsAddService(const char* name, uint16_t port) {
  svcName = name;
  MDNS.addService(name, "tcp", port);
}
void mdnsTxt(const char* key, const char* value) { MDNS.addServiceTxt(svcName, "tcp", key, value); }
void mdnsTxtReplace(const char* key, const char* value) { MDNS.addServiceTxt(svcName, "tcp", key, value); }  // sets
void mdnsAnnounce() {}  // the mDNS responder re-announces changed TXT records itself
void mdnsUpdate() {}
void mdnsEnd() { MDNS.end(); }

bool factoryResetAtBoot() { return false; }

// FW-102/FW-080: USER classified as short/long (on release) or reset (>= 5 s, while held). The state machines
// ignore a button that is already held at boot. BOOT never resets.
static core::ButtonPress userPress;
static core::ButtonPress bootPress(50, 1000, 3000, 5000, false);
static bool resetRequested = false;

// Pending presses for popButtonEvent (2 slots; further presses before the next events::loop() are dropped).
struct Pending { uint8_t button, press; };
static Pending pending[2];
static uint8_t pendingCount = 0;

static void latch(core::ButtonId id, core::Press p) {
  if (pendingCount < 2) pending[pendingCount++] = Pending{(uint8_t)id, (uint8_t)p};
}

// Also called from the GxEPD2 busy callback (display.cpp): only digitalRead, no network, no allocation.
void loop() {
  static uint32_t last = 0;
  const uint32_t now = millis();
  if (now - last < 10) return;
  last = now;
  const core::Press u = userPress.update(digitalRead(PIN_USER) == USER_ACTIVE_LEVEL, now);
  if (u == core::Press::Reset) resetRequested = true;
  else if (u != core::Press::None) latch(core::ButtonId::User, u);
  if (BOOT_BUTTON) {
    const core::Press b = bootPress.update(digitalRead(PIN_BOOT) == BOOT_ACTIVE_LEVEL, now);
    if (b != core::Press::None) latch(core::ButtonId::Boot, b);
  }
}

bool factoryResetRequested() {
  const bool r = resetRequested;
  resetRequested = false;
  return r;
}

bool popButtonEvent(uint8_t* button, uint8_t* press) {
  if (!pendingCount) return false;
  *button = pending[0].button;
  *press = pending[0].press;
  pending[0] = pending[1];
  pendingCount--;
  return true;
}

}  // namespace board

#pragma once
// Board layer (ADR-19, FW-100): the only place where the two supported boards differ. Exactly one implementation
// file is compiled per env (board_d1_mini.cpp | board_nm_epd_420.cpp, chosen by build_src_filter in platformio.ini);
// there are no virtual classes and no heap use. `#if PB_BOARD_*` appears only in board*.{h,cpp} and display.cpp.
// Hardware facts: docs/hardware.md.

#include <stddef.h>
#include <stdint.h>

#if defined(PB_BOARD_D1_MINI)
#elif defined(PB_BOARD_NM_EPD_420)
#else
#error "Define PB_BOARD_D1_MINI or PB_BOARD_NM_EPD_420 (see platformio.ini)"
#endif

namespace board {

extern const char* const ID;             // "d1_mini" | "nm_epd_420"        (IF-020 board)
extern const char* const FRAME_FORMAT;   // "bw" | "bwr"                    (IF-020 fmt, ADR-20)
extern const char* const PANEL;          // "GxEPD2_420" | "GDEY042Z98"     (IF-010 panel)
extern const char* const RESET_HINT;     // how to factory reset, for on-screen texts (FW-008, FW-102)

#if defined(PB_BOARD_D1_MINI)
constexpr size_t FRAME_BUF_BYTES = 400 * 300 / 8;      // FW-033: black plane only
constexpr bool PARTIAL_REFRESH = true;
constexpr uint8_t API_VERSION = 2;                     // stays on protocol 2: requests byte-identical (NFR-041/047)
constexpr uint32_t MIN_REFRESH_MS = 0;                 // FW-103: no firmware floor for the b/w panel
constexpr uint32_t OTA_MAX_BYTES = 1024UL * 1024;      // NFR-031
constexpr bool IMAGE_ESP32S3 = false;                  // OTA header check (core::otaImageMatches)
constexpr bool HAS_BUTTONS = false;                    // D-26: the D1 mini has no buttons (FW-080 is NM-EPD-420 only)
inline bool popButtonEvent(uint8_t*, uint8_t*) { return false; }
#else
constexpr size_t FRAME_BUF_BYTES = 2 * 400 * 300 / 8;  // black plane + red plane (red stays white, 0xFF)
constexpr bool PARTIAL_REFRESH = false;                // 3C panel: full refresh only
constexpr uint8_t API_VERSION = 3;                     // IF-021: X-Board / X-Frame-Format on every poll
constexpr uint32_t MIN_REFRESH_MS = 60000;             // FW-103: hard floor between two panel refreshes
constexpr uint32_t OTA_MAX_BYTES = 2UL * 1024 * 1024;  // NFR-031 (slot is 6.25 MB)
constexpr bool IMAGE_ESP32S3 = true;
constexpr bool HAS_BUTTONS = true;                     // FW-080: USER button short/long press
// Next classified button press (core::ButtonId, core::Press::Short|Long), oldest first; false if none pending.
bool popButtonEvent(uint8_t* button, uint8_t* press);
#endif

// True if p points into memory-mapped flash (a PSTR on the ESP8266, #63). The ESP32 has no separate flash
// address space for literals (PSTR is a plain literal), so it is always false there.
#if defined(PB_BOARD_D1_MINI) || defined(ESP8266)
inline bool inFlash(const void* p) { return (uintptr_t)p >= 0x40000000u; }
#else
inline bool inFlash(const void*) { return false; }
#endif

// Call once in setup() after Serial.begin(). S3: Serial.setTxTimeoutMs(0) so logging never blocks without a host.
void begin();

uint32_t chipId();            // 24 bit, printed as %06x (D1: ESP chip ID, S3: last three bytes of the eFuse MAC)
const char* resetReason();    // hardware reset reason as an X-Reset-Reason string (FW-062)
uint32_t freeHeap();          // internal RAM (FW-062)
uint32_t maxBlock();
[[noreturn]] void restart();      // clean software restart
[[noreturn]] void hardReset();    // for the watchdog: restarts even when the system is stuck
uint32_t hwRandom();

// OTA (FW-072, NFR-012): confirms the running image after its first answered poll. S3: ends the bootloader
// rollback window (ADR-18); D1: no-op (eboot has no rollback).
void otaConfirm();

// Small persistent areas surviving software/watchdog resets, not power loss (ESP8266 RTC user memory; S3:
// RTC_NOINIT_ATTR struct). Sizes must be multiples of 4 and within the slot (Health 8, Ota 40, DoubleReset 8 bytes).
enum class Rtc : uint8_t { Health, Ota, DoubleReset };
void rtcRead(Rtc slot, void* data, size_t bytes);
void rtcWrite(Rtc slot, const void* data, size_t bytes);

void wifiDrop();         // drops the connection but keeps the stored credentials (never WiFi.disconnect())
// FW-001: true if station credentials are stored in flash. Must not depend on the Wi-Fi driver state (#88: on the
// ESP32-S3 WiFiManager::getWiFiIsSaved() reads uninitialised memory before the driver is up).
bool wifiCredentialsSaved();
void wifiModemSleep();   // FW-041: modem sleep while connected

bool fsBegin();          // mounts LittleFS (S3: formats on first use)

bool mdnsBegin(const char* host);
void mdnsAddService(const char* service, uint16_t port);  // "_service._tcp"
void mdnsTxt(const char* key, const char* value);          // call after mdnsAddService
void mdnsTxtReplace(const char* key, const char* value);   // replaces an existing key
void mdnsAnnounce();
void mdnsUpdate();       // call from loop()
void mdnsEnd();

bool factoryResetAtBoot();      // D1: double reset (FW-008); S3: false
void loop();                    // D1: disarms the double-reset window after 3 s; S3: samples USER
bool factoryResetRequested();   // S3: USER held >= 5 s (FW-102), once per press; D1: false

}  // namespace board

#include "poller.h"

#include "board.h"
#include "board_net.h"
#include "crc32.h"
#include "device_api.h"
#include "frame_format.h"
#include "display.h"
#include "health.h"
#include "ota.h"
#include "ota_logic.h"
#include "pairing.h"
#include "pairing_logic.h"
#include "poll_logic.h"
#include "screens.h"
#include "version.h"

namespace poller {

static constexpr uint32_t HTTP_TIMEOUT_MS = 10000;
static constexpr uint32_t OFFLINE_ICON_AFTER_MS = 5UL * 60 * 1000;   // FW-051
static constexpr uint32_t UNREACHABLE_AFTER_MS = 30UL * 60 * 1000;   // FW-052

// The one frame buffer (FW-033): received frame, kept for partial-update sync and the status overlay.
// Protocol 2 delivers exactly display::FRAME_BYTES (the black plane). On a bwr board the buffer is twice as large:
// the second plane (red) stays 0xFF = white (set once in begin(), never written by a poll).
static uint8_t frame[board::FRAME_BUF_BYTES];

static constexpr uint32_t UNKNOWN_DEVICE_STRIKES = 3;  // FW-023 only after repeated 401/404
static uint32_t unknownDeviceCount = 0;
static char etag[24] = "";
static core::Rect statusArea;
static core::RefreshCounter refreshes;
static bool frameShown = false;        // panel shows `frame`
static bool forceFull = true;          // next frame needs a full refresh (after a local screen)
static bool offlineIconShown = false;
static bool unreachableShown = false;
static bool resetReasonSent = false;
static uint32_t lastSuccessMs = 0;
static uint32_t failures = 0;
static uint32_t nextPollMs = 0;
static char lastError[48] = "";

enum class Result { Changed, Unchanged, Failed, UnknownDevice };

static bool readFully(WiFiClient* stream, uint8_t* buf, size_t len) {
  size_t got = 0;
  uint32_t start = millis();
  while (got < len && millis() - start < HTTP_TIMEOUT_MS) {
    size_t n = stream->readBytes(buf + got, len - got);
    got += n;
    if (!n) delay(1);
  }
  return got == len;
}

// FW-103: milliseconds until the panel may be refreshed again (always 0 on boards without a floor).
static uint32_t floorRemaining() {
  if (board::MIN_REFRESH_MS == 0) {
    return 0;
  } else {
    core::RefreshFloor f;
    uint32_t last;
    if (display::lastRefresh(&last)) f.onRefresh(last);
    return f.remainingMs(millis(), board::MIN_REFRESH_MS);
  }
}

static Result pollOnce(uint32_t* pollSeconds) {
  if (WiFi.status() != WL_CONNECTED) {
    snprintf_P(lastError, sizeof(lastError), PSTR("Wi-Fi not connected"));
    return Result::Failed;
  }
  WiFiClient client;
  HTTPClient http;
  static const char* keys[] = {"ETag", "X-Crc32", "X-Poll-S", "X-Refresh", "X-Status-Area", "X-Ota"};
  http.setTimeout(HTTP_TIMEOUT_MS);
  char url[core::PAIR_URL_MAX + 8];
  if (!core::frameUrl(url, sizeof(url), pairing::homeyUrl()) || !http.begin(client, url)) {
    snprintf_P(lastError, sizeof(lastError), PSTR("invalid URL"));
    return Result::Failed;
  }
  if (board::API_VERSION >= 3) {  // X-Frame-Format only from API 3 (the API 2 build keeps its RAM budget, NFR-047)
    static const char* keys3[] = {"ETag", "X-Crc32", "X-Poll-S", "X-Refresh", "X-Status-Area", "X-Ota", "X-Frame-Format"};
    http.collectHeaders(keys3, 7);
  } else {
    http.collectHeaders(keys, 6);
  }
  char value[24];
  http.addHeader(F("Authorization"), String("Bearer ") + pairing::token());
  http.addHeader(F("X-Api-Version"), String(board::API_VERSION));
  if (board::API_VERSION >= 3) {  // IF-021: capability announcement on every poll
    http.addHeader(F("X-Board"), board::ID);
    http.addHeader(F("X-Frame-Format"), board::FRAME_FORMAT);
  }
  http.addHeader(F("X-Fw-Version"), FW_VERSION);
  http.addHeader(F("X-RSSI"), String(WiFi.RSSI()));
  snprintf_P(value, sizeof(value), PSTR("%lu"), (unsigned long)(millis() / 1000));
  http.addHeader(F("X-Uptime-S"), value);
  http.addHeader(F("X-Free-Heap"), health::heapReport());
  snprintf_P(value, sizeof(value), PSTR("%lu"), (unsigned long)refreshes.partialsSinceFull);
  http.addHeader(F("X-Partial-Count"), value);
  if (!resetReasonSent) http.addHeader(F("X-Reset-Reason"), health::resetReason());
  if (ota::pendingResult()[0]) http.addHeader(F("X-Ota-Result"), ota::pendingResult());  // IF-003, once
  if (frameShown && etag[0]) http.addHeader(F("If-None-Match"), etag);

  const uint32_t t0 = millis();
  const int code = http.GET();
  *pollSeconds = core::clampPollSeconds(http.header("X-Poll-S").c_str());
  Result result = Result::Failed;
  if (code > 0) {
    ota::clearPendingResult();  // reported (or at least delivered to the server) once
    ota::confirmBoot();         // NFR-012: the image can poll, end the S3 rollback window
  }
  // Copy before http.end(): the OTA download must not run with two HTTP clients open (FW-070).
  static core::OtaHint otaHint;
  const bool hasOtaHint = (code == HTTP_CODE_OK || code == HTTP_CODE_NOT_MODIFIED) &&
                          core::parseOtaHint(http.header("X-Ota").c_str(), &otaHint, board::API_VERSION >= 3 ? board::ID : nullptr);

  if (code == HTTP_CODE_NOT_MODIFIED) {
    result = Result::Unchanged;
  } else if (code == HTTP_CODE_OK) {
    // IF-021: the echoed format must be bw or the board's own; the length must match it exactly (FW-034)
    String fmt;
    bool hasFmt = false;
    if (board::API_VERSION >= 3) {
      hasFmt = http.hasHeader("X-Frame-Format");
      if (hasFmt) fmt = http.header("X-Frame-Format");
    }
    const uint8_t planes = core::framePlanes(hasFmt ? fmt.c_str() : nullptr, board::FRAME_FORMAT);
    const size_t bodyBytes = (size_t)planes * display::FRAME_BYTES;
    if (!planes) {
      snprintf_P(lastError, sizeof(lastError), PSTR("bad format %.12s"), fmt.c_str());
    } else if (!core::frameLengthValid(http.getSize(), planes, board::FRAME_BUF_BYTES)) {
      snprintf_P(lastError, sizeof(lastError), PSTR("bad length %d"), http.getSize());
    } else if (!readFully(http.getStreamPtr(), frame, bodyBytes)) {
      snprintf_P(lastError, sizeof(lastError), PSTR("body timeout"));
      frameShown = false;  // buffer no longer matches the panel
    } else {
      char crcHex[9];
      snprintf_P(crcHex, sizeof(crcHex), PSTR("%x"), crc32Update(0, frame, bodyBytes));
      if (!http.header("X-Crc32").equalsIgnoreCase(crcHex)) {
        snprintf_P(lastError, sizeof(lastError), PSTR("CRC mismatch"));  // FW-034: panel keeps the old image
        frameShown = false;
      } else {
        // A bw body on a bwr board: red plane white. A bwr body: red wins where both planes are inked (FW-101).
        if (board::FRAME_BUF_BYTES > display::FRAME_BYTES) {
          if (planes == 1) memset(frame + display::FRAME_BYTES, 0xFF, display::FRAME_BYTES);
          else core::resolveRed(frame, frame + display::FRAME_BYTES, display::FRAME_BYTES);
        }
        const uint32_t tr = millis();
        const bool full = display::showFrame(frame, forceFull || !board::PARTIAL_REFRESH || http.header("X-Refresh") != "partial");
        forceFull = false;
        refreshes.onRefresh(full);
        Serial.printf_P(PSTR("[poll] new frame %s, fetched in %lu ms, %s refresh %lu ms\n"), crcHex, tr - t0,
                      full ? "full" : "partial", millis() - tr);
        strlcpy(etag, http.header("ETag").c_str(), sizeof(etag));
        statusArea = core::parseStatusArea(http.header("X-Status-Area").c_str());
        frameShown = true;
        offlineIconShown = false;
        unreachableShown = false;
        result = Result::Changed;
      }
    }
  } else if (code == HTTP_CODE_UNAUTHORIZED || code == HTTP_CODE_NOT_FOUND) {
    snprintf_P(lastError, sizeof(lastError), PSTR("unknown device (HTTP %d)"), code);
    result = Result::UnknownDevice;
  } else if (code < 0) {
    snprintf_P(lastError, sizeof(lastError), PSTR("%s"), HTTPClient::errorToString(code).c_str());
  } else {
    snprintf_P(lastError, sizeof(lastError), PSTR("HTTP %d"), code);
  }
  http.end();
  if (hasOtaHint && ota::offer(otaHint)) invalidateFrame();  // failure screen replaced the frame
  return result;
}

static void onSuccess() {
  resetReasonSent = true;
  health::heapMark(core::HeapStage::Poll1);
  lastSuccessMs = millis();
  failures = 0;
  if (offlineIconShown && frameShown && floorRemaining() == 0) {  // inside the floor: next poll
    display::showStatusIcon(frame, statusArea, false);  // FW-051: remove icon on recovery
    offlineIconShown = false;
    Serial.println(F("[poll] offline icon removed"));
  }
}

static void onFailure() {
  failures++;
  const uint32_t offlineMs = millis() - lastSuccessMs;
  Serial.printf_P(PSTR("[poll] failed (%lu in a row, %lu s since last success): %s\n"), (unsigned long)failures,
                (unsigned long)(offlineMs / 1000), lastError);
  if (frameShown && !offlineIconShown && statusArea.valid() && floorRemaining() == 0 && offlineMs >= OFFLINE_ICON_AFTER_MS &&
      offlineMs < UNREACHABLE_AFTER_MS) {  // the unreachable screen replaces the frame anyway
    display::showStatusIcon(frame, statusArea, true);
    offlineIconShown = true;
    Serial.println(F("[poll] offline icon shown"));
  }
  // Only when Wi-Fi works: Wi-Fi problems have their own screens (connectivity.cpp, FW-007)
  if (!unreachableShown && offlineMs >= UNREACHABLE_AFTER_MS && WiFi.isConnected()) {
    static char urlLine[96];
    static char errLine[64];
    snprintf_P(urlLine, sizeof(urlLine), PSTR("Homey: %s"), pairing::homeyUrl());
    snprintf_P(errLine, sizeof(errLine), PSTR("Last error: %s"), lastError);
    const char* lines[] = {PSTR("The display cannot reach the Homey app."), PSTR("Check that Homey is on and the"), PSTR("Paperboard app is running."), nullptr, urlLine, errLine, PSTR("Retrying every minute.")};
    display::showMessage(PSTR("Homey not reachable"), lines, 7);
    Serial.println(F("[poll] 'Homey not reachable' screen shown"));
    unreachableShown = true;
    invalidateFrame();  // next successful poll must fetch the full frame again
  }
}

#ifdef PB_DEBUG
void debugShowOffline() {
  if (!frameShown || !statusArea.valid()) return;
  display::showStatusIcon(frame, statusArea, true);
  offlineIconShown = true;
  Serial.println(F("[poll] offline icon shown (debug)"));
}

// Hardware check N-3 without the app: black square, red square, a square inked in both planes (must show red),
// an asymmetric "L" marker (orientation) and a 1 px black border, through the normal resolveRed + showFrame path.
static void fillPixels(uint8_t* plane, int x0, int y0, int w, int h) {
  for (int y = y0; y < y0 + h; y++)
    for (int x = x0; x < x0 + w; x++) plane[y * 50 + x / 8] &= (uint8_t)~(0x80 >> (x % 8));
}

void debugTestPattern() {
  if (board::FRAME_BUF_BYTES <= display::FRAME_BYTES) {
    Serial.println(F("[debug] test pattern needs a bwr board"));
    return;
  }
  uint8_t* red = frame + display::FRAME_BYTES;
  memset(frame, 0xFF, sizeof(frame));
  fillPixels(frame, 20, 20, 60, 60);                           // black
  fillPixels(red, 100, 20, 60, 60);                            // red
  fillPixels(frame, 180, 20, 60, 60);                          // both -> red
  fillPixels(red, 180, 20, 60, 60);
  fillPixels(frame, 20, 100, 20, 100);                         // "L" marker: black, bottom-left of the squares
  fillPixels(frame, 20, 180, 60, 20);
  fillPixels(frame, 0, 0, 400, 1);                             // border
  fillPixels(frame, 0, 299, 400, 1);
  fillPixels(frame, 0, 0, 1, 300);
  fillPixels(frame, 399, 0, 1, 300);
  core::resolveRed(frame, red, display::FRAME_BYTES);
  const uint32_t t = millis();
  display::showFrame(frame, true);
  Serial.printf_P(PSTR("[debug] test pattern shown, refresh %lu ms\n"), (unsigned long)(millis() - t));
  invalidateFrame();
}

void debugAgeLastSuccess() {
  lastSuccessMs = millis() - UNREACHABLE_AFTER_MS;
  Serial.println(F("[poll] last success aged by 30 min (debug)"));
}
#endif

void invalidateFrame() {
  frameShown = false;
  forceFull = true;  // a different image is on the panel: avoid ghosting
  offlineIconShown = false;
}

void kick() { nextPollMs = millis() + floorRemaining(); }  // FW-103: deferred inside the floor, not dropped

void begin() {
  memset(frame, 0xFF, sizeof(frame));
  lastSuccessMs = millis();
  nextPollMs = millis();
}

void loop() {
  if ((int32_t)(millis() - nextPollMs) < 0) return;
  if (const uint32_t wait = floorRemaining()) {  // FW-103: a local screen refreshed the panel recently
    nextPollMs = millis() + wait;
    return;
  }
  uint32_t pollSeconds = core::POLL_DEFAULT_S;
  const Result r = pollOnce(&pollSeconds);
  if (r == Result::UnknownDevice && ++unknownDeviceCount >= UNKNOWN_DEVICE_STRIKES) {
    // FW-023: the device was deleted in Homey → back to the unpaired state
    Serial.println(F("[poll] device unknown to Homey -> unpairing"));
    unknownDeviceCount = 0;
    failures = 0;
    pairing::clear();
    device_api::announcePaired(false);
    screens::showAddToHomey();
    return;
  }
  if (r == Result::Failed || r == Result::UnknownDevice) {
    onFailure();
    pollSeconds = core::backoffSeconds(failures);
  } else {
    unknownDeviceCount = 0;
    onSuccess();
  }
  health::checkHeap();
  uint32_t delayMs = pollSeconds * 1000;
  if (const uint32_t wait = floorRemaining()) delayMs = delayMs > wait ? delayMs : wait;  // FW-103
  nextPollMs = millis() + delayMs;
}

}  // namespace poller

#include "display.h"

#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <qrcode.h>

#include "board.h"
#include "device_api.h"
#include "health.h"
#include "sleep_logic.h"
#include "status_icon.h"

#if defined(PB_PANEL_GDEY0420F51)
#include <GxEPD2_4C.h>  // NM-EPD-420-4C: b/w/r/y panel, packed 2 bpp (FW-116)
#elif defined(PB_BOARD_NM_EPD_420)
#include <GxEPD2_3C.h>
#else
#include <GxEPD2_BW.h>  // D1 mini and TRMNL 7.5": b/w panels
#endif

namespace display {

// Small page buffer (panel width x 30 rows: 1 500 B on the 400 px boards, 3 000 B on the TRMNL) for local screens drawn
// with GFX; received frames are written straight from the caller's frame buffer, so no second frame buffer is needed.
// Local screens are drawn in the 400x300 window at (ORIGIN_X, ORIGIN_Y) (ADR-25): X0/Y0 are 0 on the 400x300 boards.
static constexpr int16_t X0 = board::ORIGIN_X, Y0 = board::ORIGIN_Y, WIN_W = 400, WIN_H = 300;
static constexpr uint16_t PAGE_HEIGHT = 30;
#if defined(PB_BOARD_D1_MINI)
static GxEPD2_BW<GxEPD2_420, PAGE_HEIGHT> epd(GxEPD2_420(/*CS=D8*/ 15, /*DC=D1*/ 5, /*RST=D2*/ 4, /*BUSY=D6*/ 12));

void begin() {
  // initial = true: the first refresh is a full one; the panel keeps its old image until then
  epd.init(0, true, 2, false);
}
#elif defined(PB_BOARD_TRMNL_75)
// TRMNL 7.5" pins (Seeed DEV_Config.h, docs/hardware.md section 8): vendor values, [open] until check T-2. CS is GPIO44 =
// U0RXD (T-3); the console runs on USB-CDC. Panel class [open] T-2: GxEPD2_750_GDEY075T7, fallback GxEPD2_750_T7.
static constexpr int8_t PIN_SCK = 7, PIN_MOSI = 9, PIN_CS = 44, PIN_DC = 10, PIN_RST = 38, PIN_BUSY = 4;
static GxEPD2_BW<GxEPD2_750_GDEY075T7, PAGE_HEIGHT> epd(GxEPD2_750_GDEY075T7(PIN_CS, PIN_DC, PIN_RST, PIN_BUSY));

// FW-102: keep sampling KEY3 during a refresh (a full refresh blocks for seconds); replaces GxEPD2's delay(1).
static void busyCallback(const void*) {
  board::loop();
  delay(1);
}

void begin() {
  SPI.begin(PIN_SCK, -1, PIN_MOSI, PIN_CS);
  epd.init(0, true, 2, false, SPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
  epd.epd2.setBusyCallback(busyCallback);
}
#elif defined(PB_PANEL_GDEY0420F51)
// NM-EPD-420-4C (#111, FW-116): the same PCB and pins as the 3C, GDEY0420F51 panel (HX8717), BUSY active low,
// full refresh ~27 s (docs/hardware.md section 7, spike S4).
static constexpr int8_t PIN_SCK = 2, PIN_MOSI = 1, PIN_CS = 46, PIN_DC = 4, PIN_RST = 5, PIN_BUSY = 6;
static GxEPD2_4C<GxEPD2_420c_GDEY0420F51, PAGE_HEIGHT> epd(GxEPD2_420c_GDEY0420F51(PIN_CS, PIN_DC, PIN_RST, PIN_BUSY));
static bool inRefresh = false;  // a panel refresh is running (set by RefreshScope)

// FW-080 + FW-116: during the ~27 s refresh keep sampling USER, keep the loop watchdog fed (the refresh is bounded by the
// library's busy timeout) and serve HTTP and mDNS, so a pairing call is answered within the app's 8 s timeout.
// The handlers never touch the display, the frame buffer, OTA or audio (audit: device_api.cpp). Replaces GxEPD2's delay(1).
static void busyCallback(const void*) {
  board::loop();
  health::feed();
  if (board::SERVE_DURING_REFRESH) device_api::serviceDuringRefresh();
  delay(1);
}

struct RefreshScope {
  RefreshScope() { inRefresh = true; }
  ~RefreshScope() { inRefresh = false; }
};

void begin() {
  SPI.begin(PIN_SCK, -1, PIN_MOSI, PIN_CS);
  // reset_duration 20 ms: after hibernate() (deep sleep) the panel stays asleep with the library's default 2 ms pulse
  // (spike S4, C-10); init() does the hard reset right here, so the first write after a wake works.
  epd.init(0, true, 20, false, SPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
  epd.epd2.setBusyCallback(busyCallback);
}
#else
// NM-EPD-420 pins (docs/hardware.md section 7): vendor values, [open] until check N-3 (#47).
static constexpr int8_t PIN_SCK = 2, PIN_MOSI = 1, PIN_CS = 46, PIN_DC = 4, PIN_RST = 5, PIN_BUSY = 6;
static GxEPD2_3C<GxEPD2_420c_GDEY042Z98, PAGE_HEIGHT> epd(GxEPD2_420c_GDEY042Z98(PIN_CS, PIN_DC, PIN_RST, PIN_BUSY));

// FW-080: a bwr refresh blocks for seconds; keep sampling the USER button meanwhile so a press is classified by
// its real timestamps. The callback replaces GxEPD2's own delay(1) in the busy wait, hence the delay here.
static void busyCallback(const void*) {
  board::loop();
  delay(1);
}

void begin() {
  SPI.begin(PIN_SCK, -1, PIN_MOSI, PIN_CS);
  epd.init(0, true, 2, false, SPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
  epd.epd2.setBusyCallback(busyCallback);
}
#endif

#if !defined(PB_PANEL_GDEY0420F51)
struct RefreshScope {
  RefreshScope() {}  // only the 4C panel tracks a running refresh (refreshing())
};
#endif

static bool firstRefreshDone = false;
static int lastScreenId = 0;
static uint32_t lastRefreshAt = 0;
static bool refreshedOnce = false;

// FW-103: remember when the panel was last refreshed (any content); compiled out for boards without a floor.
static void markRefresh() {
  if (board::MIN_REFRESH_MS > 0) {
    lastRefreshAt = millis();
    refreshedOnce = true;
  }
}

bool lastRefresh(uint32_t* ms) {
  if (board::MIN_REFRESH_MS > 0) {
    *ms = lastRefreshAt;
    return refreshedOnce;
  } else {
    return false;
  }
}

uint32_t refreshAgeS() {
  core::RefreshFloor f;
  if (board::MIN_REFRESH_MS > 0 && refreshedOnce) f.onRefresh(lastRefreshAt);
  return core::refreshAgeS(f, millis());
}

void restoreRefresh(uint32_t sinceRefreshAtSleepS, uint32_t sleptS) {
  if (board::MIN_REFRESH_MS == 0) return;
  core::RefreshFloor f;
  core::restoreRefreshFloor(&f, millis(), sinceRefreshAtSleepS, sleptS);
  if (f.valid) {
    lastRefreshAt = f.lastMs;
    refreshedOnce = true;
  }
}

void hibernate() { epd.hibernate(); }

bool refreshing() {
#if defined(PB_PANEL_GDEY0420F51)
  return inRefresh;
#else
  return false;
#endif
}

int lastScreen() { return lastScreenId; }

#if defined(PB_PANEL_GDEY0420F51)
// FW-116, IF-023: the frame is the panel's native packed 2-bpp layout (30 000 B): one writeNative, full refresh only.
bool showFrame(const uint8_t* frame, bool) {
  RefreshScope scope;
  auto& e = epd.epd2;
  e.writeNative(frame, nullptr, 0, 0, 400, 300);
  e.refresh(false);
  e.powerOff();  // FW-036
  markRefresh();
  lastScreenId = -1;
  return true;
}
#elif !defined(PB_BOARD_NM_EPD_420)
bool showFrame(const uint8_t* frame, bool full) {
  auto& e = epd.epd2;
  full = full || !firstRefreshDone;
  if (full) {
    e.writeImageForFullRefresh(frame, 0, 0, board::PANEL_W, board::PANEL_H);
    e.refresh(false);
  } else {
    e.writeImage(frame, 0, 0, board::PANEL_W, board::PANEL_H);
    e.refresh(true);
  }
  // Controller keeps "previous" image RAM for differential partial updates → sync it to the new frame
  e.writeImageAgain(frame, 0, 0, board::PANEL_W, board::PANEL_H);
  e.powerOff();  // FW-036
  markRefresh();
  firstRefreshDone = true;
  lastScreenId = -1;
  return full;
}

#else
// FW-100: bwr panel – the black plane is `frame`, the red plane follows it in the buffer. Full refresh only.
bool showFrame(const uint8_t* frame, bool) {
  auto& e = epd.epd2;
  e.writeImage(frame, frame + FRAME_BYTES, 0, 0, 400, 300);
  e.refresh(false);
  e.powerOff();  // FW-036
  markRefresh();
  lastScreenId = -1;
  return true;
}
#endif

#if defined(PB_PANEL_GDEY0420F51)
// FW-116, FW-051: the 2-bpp window under the icon is saved, turned into a 1-bpp mask, the icon drawn into it and written
// back as black/white (yellow and red under the window are cleared while the icon is shown), then a full refresh, then
// the original bytes are restored.
void showStatusIcon(uint8_t* frame, const core::Rect& area, bool offline) {
  const core::Window win = core::alignedWindow(area);
  if (!win.size()) return;
  static uint8_t orig[2 * core::MAX_WINDOW_BYTES], icon[2 * core::MAX_WINDOW_BYTES], mask[core::MAX_WINDOW_BYTES];
  const size_t bpr2 = win.bytesPerRow() * 2;
  auto rowOf = [&](int16_t r) { return frame + (size_t)(win.y + r) * (board::PANEL_W / 4) + win.x / 4; };
  core::copyWindow2bpp(frame, win, orig, board::PANEL_W);
  if (offline) {
    memcpy(icon, orig, win.size() * 2);
    core::maskFrom2bpp(icon, win, mask);
    core::drawOfflineIcon(mask, win, area);
    core::mergeMask2bpp(icon, win, mask);
    for (int16_t r = 0; r < win.h; r++) memcpy(rowOf(r), icon + (size_t)r * bpr2, bpr2);
  }
  showFrame(frame, true);
  for (int16_t r = 0; r < win.h; r++) memcpy(rowOf(r), orig + (size_t)r * bpr2, bpr2);
}
#elif !defined(PB_BOARD_NM_EPD_420)
// X-Status-Area is in panel coordinates (IF-022). Boards without a usable partial refresh (TRMNL until T-2) draw the
// icon into the frame, refresh fully and restore the frame, like the 3C path below.
void showStatusIcon(uint8_t* frame, const core::Rect& area, bool offline) {
  const core::Window win = core::alignedWindow(area);
  if (!win.size()) return;
  static uint8_t buf[core::MAX_WINDOW_BYTES];
  core::copyWindow(frame, win, buf, board::PANEL_W);
  if (!board::PARTIAL_REFRESH) {
    static uint8_t orig[core::MAX_WINDOW_BYTES];
    memcpy(orig, buf, win.size());
    const size_t bpr = win.bytesPerRow();
    auto rowOf = [&](int16_t r) { return frame + (size_t)(win.y + r) * (board::PANEL_W / 8) + win.x / 8; };
    if (offline) {
      core::drawOfflineIcon(buf, win, area);
      for (int16_t r = 0; r < win.h; r++) memcpy(rowOf(r), buf + (size_t)r * bpr, bpr);
    }
    showFrame(frame, true);
    for (int16_t r = 0; r < win.h; r++) memcpy(rowOf(r), orig + (size_t)r * bpr, bpr);
    return;
  }
  if (offline) core::drawOfflineIcon(buf, win, area);
  auto& e = epd.epd2;
  e.writeImage(buf, win.x, win.y, win.w, win.h);
  e.refresh(win.x, win.y, win.w, win.h);
  e.writeImageAgain(buf, win.x, win.y, win.w, win.h);
  e.powerOff();
}
#else
// The window refresh of the 3C panel is a full refresh anyway (ADR-19): the icon is drawn into the frame, the panel
// refreshed, and the frame restored so that the icon can be removed again.
// FW-051: red ink under the icon would hide it, so the red window is cleared (0xFF) while the icon is shown.
void showStatusIcon(uint8_t* frame, const core::Rect& area, bool offline) {
  const core::Window win = core::alignedWindow(area);
  if (!win.size()) return;
  static uint8_t orig[core::MAX_WINDOW_BYTES], icon[core::MAX_WINDOW_BYTES], origRed[core::MAX_WINDOW_BYTES];
  uint8_t* red = frame + FRAME_BYTES;
  const size_t bpr = win.bytesPerRow();
  auto rowOf = [&](uint8_t* plane, int16_t r) { return plane + (size_t)(win.y + r) * (400 / 8) + win.x / 8; };
  core::copyWindow(frame, win, orig);
  core::copyWindow(red, win, origRed);
  if (offline) {
    memcpy(icon, orig, win.size());
    core::drawOfflineIcon(icon, win, area);
    for (int16_t r = 0; r < win.h; r++) {
      memcpy(rowOf(frame, r), icon + (size_t)r * bpr, bpr);
      memset(rowOf(red, r), 0xFF, bpr);
    }
  }
  showFrame(frame, true);
  for (int16_t r = 0; r < win.h; r++) {
    memcpy(rowOf(frame, r), orig + (size_t)r * bpr, bpr);
    memcpy(rowOf(red, r), origRed + (size_t)r * bpr, bpr);
  }
}
#endif

// Screen texts are PSTRs on the ESP8266 (#63, static RAM), formatted lines are RAM strings: print either.
static void printAny(const char* s) {
  if (board::inFlash(s)) epd.print(reinterpret_cast<const __FlashStringHelper*>(s));
  else epd.print(s);
}

static void drawTitle(const char* title) {
  epd.fillScreen(GxEPD_WHITE);
  epd.fillRect(X0, Y0, WIN_W, 40, GxEPD_BLACK);
  epd.setTextColor(GxEPD_WHITE);
  epd.setFont(&FreeSansBold12pt7b);
  epd.setCursor(X0 + 12, Y0 + 28);
  printAny(title);
  epd.setTextColor(GxEPD_BLACK);
  epd.setFont(&FreeSans9pt7b);
}

static void drawLines(const char* const* lines, size_t count, int16_t x, int16_t y, int16_t step) {
  for (size_t i = 0; i < count; i++, y += step) {
    if (!lines[i]) continue;
    epd.setCursor(X0 + x, Y0 + y);
    printAny(lines[i]);
  }
}

void showMessage(const char* title, const char* const* lines, size_t count, int screenId) {
  RefreshScope scope;
  epd.setRotation(0);
  epd.setFullWindow();
  epd.firstPage();
  do {
    drawTitle(title);
    drawLines(lines, count, 12, 70, 24);
  } while (epd.nextPage());
  epd.powerOff();
  firstRefreshDone = true;
  markRefresh();
  lastScreenId = screenId;
}

void showSetup(const char* apName, const char* password, const char* qrPayload, bool wifiLost) {
  // QR version 4 (33x33 modules) holds up to 78 bytes at ECC_LOW – enough for the escaped payload
  static uint8_t qrData[(33 * 33 + 7) / 8];  // qrcode_getBufferSize(4), not constexpr
  QRCode qr;
  const bool qrOk = qrcode_initText(&qr, qrData, 4, ECC_LOW, qrPayload) == 0;
  const int16_t scale = 4;
  const int16_t qrPx = qrOk ? qr.size * scale : 0;
  const int16_t qrX = X0 + WIN_W - 12 - qrPx;
  const int16_t qrY = Y0 + 56;

  char line[40];
  snprintf_P(line, sizeof(line), PSTR("Password: %s"), password);
  const char* lines[] = {
      wifiLost ? PSTR("Wi-Fi lost. To change it:") : PSTR("1. Scan the QR code or"),
      wifiLost ? PSTR("1. Scan the QR code or") : PSTR("   join this Wi-Fi:"),
      nullptr,  // AP name (bold, below)
      line,
      PSTR("2. Choose your home Wi-Fi"),
      PSTR("   and enter its password."),
      PSTR("3. No page opens? Go to"),
      PSTR("   http://192.168.4.1"),
  };
  RefreshScope scope;
  epd.setRotation(0);
  epd.setFullWindow();
  epd.firstPage();
  do {
    drawTitle(wifiLost ? PSTR("Paperboard: Wi-Fi setup") : PSTR("Paperboard setup"));
    drawLines(lines, 8, 12, 70, 26);
    epd.setFont(&FreeSansBold12pt7b);
    epd.setCursor(X0 + 24, Y0 + 70 + 2 * 26 + 2);
    epd.print(apName);
    epd.setFont(&FreeSans9pt7b);
    epd.setCursor(X0 + 12, Y0 + 292);
    epd.print(F("Factory reset: "));
    epd.print(board::RESET_HINT);
    if (qrOk) {
      for (uint8_t y = 0; y < qr.size; y++)
        for (uint8_t x = 0; x < qr.size; x++)
          if (qrcode_getModule(&qr, x, y)) epd.fillRect(qrX + x * scale, qrY + y * scale, scale, scale, GxEPD_BLACK);
    }
  } while (epd.nextPage());
  epd.powerOff();
  firstRefreshDone = true;
  markRefresh();
  lastScreenId = -2;
}

}  // namespace display

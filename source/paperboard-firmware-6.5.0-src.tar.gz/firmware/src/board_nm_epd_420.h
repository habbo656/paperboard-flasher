#pragma once
// Constants and inline stubs of the NM-EPD-420 (ESP32-S3, tri-colour 4.2"); included by board.h (ADR-19, ADR-25). Hardware: docs/hardware.md.

#include <stddef.h>
#include <stdint.h>

namespace board {

constexpr int PANEL_W = 400, PANEL_H = 300;            // IF-022 frame geometry
constexpr int ORIGIN_X = 0, ORIGIN_Y = 0;              // top-left of the 400x300 window for local screens (ADR-25)
// 3C: black plane + red plane (red stays white, 0xFF). 4C (FW-116, IF-023): packed 2 bpp bwry, the same 30 000 B.
constexpr size_t FRAME_BUF_BYTES = 2 * PANEL_W * PANEL_H / 8;
#if defined(PB_PANEL_GDEY0420F51)
// NM-EPD-420-4C (#111, ADR-27): GDEY0420F51 / HX8717, ~27 s full refresh. The busy callback serves HTTP and mDNS meanwhile
// (device_api::serviceDuringRefresh), otherwise the app's 8 s device-call timeout would fail a pairing at that moment.
constexpr bool FRAME_PACKED_2BPP = true;
constexpr bool SERVE_DURING_REFRESH = true;
#else
constexpr bool FRAME_PACKED_2BPP = false;
constexpr bool SERVE_DURING_REFRESH = false;
#endif
// HWCDC hangs with 0 when a host read the port and then closed it (docs/hardware.md section 7, FW-115): never use 0.
constexpr uint32_t SERIAL_TX_TIMEOUT_MS = 10;
constexpr bool PARTIAL_REFRESH = false;                // 3C panel: full refresh only
constexpr uint8_t API_VERSION = 3;                     // IF-021: X-Board / X-Frame-Format on every poll
constexpr uint32_t MIN_REFRESH_MS = 60000;             // FW-103: hard floor between two panel refreshes
constexpr uint32_t OTA_MAX_BYTES = 2UL * 1024 * 1024;  // NFR-031 (slot is 6.25 MB)
constexpr bool IMAGE_ESP32S3 = true;
// FW-081, FW-104 (#80): AHT20, implemented in board_nm_epd_420.cpp
constexpr bool HAS_CLIMATE = true;
void climateLoop();                                // call from loop(): non-blocking read schedule
bool climate(int16_t* deciC, uint8_t* rhPct);      // last good reading, false if older than 180 s or none
const char* climateState();                        // IF-010 "sensor": "ok" | "missing" | "error"
void debugClimateFail();                           // debug build: no sensor reads for 5 min (FW-104 check)
// FW-106 (#83): ES8311 + NS4150B speaker, implemented in board_nm_epd_420.cpp
constexpr bool HAS_AUDIO = true;
void audioBegin();                                 // once in setup(): probes the codec on I2C 0x18, then everything off
const char* audioState();                          // "ok" | "missing" | "error": X-Audio (ok / error) and IF-010 "audio"
bool playChime(uint8_t chime, uint8_t volume);     // blocking, <= 1.5 s; chime 0..3, volume 1..100; false on failure
constexpr bool HAS_BUTTONS = true;                     // FW-080: USER button short/long press
// Next classified button press (core::ButtonId, core::Press::Short|Long), oldest first; false if none pending.
bool popButtonEvent(uint8_t* button, uint8_t* press);
bool userHeld();                                       // USER pressed right now (FW-038 stay-awake rule 5)
constexpr bool DEEP_SLEEP = true;                      // FW-038: verified by spike S1 (hardware.md N-6, N-15)
// FW-112 (#104): cell voltage in mV (BATT_ADC behind the 2:1 divider, ADC_EN switched only for the measurement:
// settle 5 ms, 16 samples of analogReadMilliVolts with eFuse calibration, x 2). 0 = ADC failed. NOT range-checked:
// the caller applies core::batteryValid().
constexpr bool HAS_BATTERY = true;
uint16_t batteryReadMv();
// FW-113, IF-006: battery mode armed by the app (X-Battery-Mode: 1). Cached in NVS, written only on change; default off.
bool batteryMode();
void setBatteryMode(bool on);

}  // namespace board

#pragma once
// Device side of discovery and pairing (FW-020…022, IF-010…013, IF-020): mDNS announcement
// `_paperboard._tcp` and a small HTTP server on port 80. Runs only while connected to the home Wi-Fi
// and no setup portal is open (the portal uses port 80 as well).

namespace device_api {

// Call from loop(): starts/stops server and mDNS as needed and handles requests. allowed = false keeps them off: a
// short deep-sleep wake cycle starts them only once the device decides to stay awake (FW-038, amends ADR-4).
void loop(bool allowed);

// FW-116: called from the display's busy callback (board::SERVE_DURING_REFRESH only): handles pending HTTP requests and
// mDNS while the panel refreshes, so a pairing call is answered within the app's timeout. Never starts or stops the
// server and never shows a screen. Handler audit (re-entrancy): /api/info only reads, /api/pair stores the pairing and
// defers the "Paired" screen via pairedScreenPending (shown by loop() after the refresh), /api/config and /api/kick
// only store the Homey URL / set the next poll time. No handler touches the display, the frame buffer, OTA or audio.
void serviceDuringRefresh();

// Updates the "paired" TXT record after pairing or unpairing.
void announcePaired(bool paired);

}  // namespace device_api

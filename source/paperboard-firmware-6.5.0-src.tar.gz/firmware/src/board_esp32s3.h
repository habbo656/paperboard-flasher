#pragma once
// Hooks of the board-specific files for the shared ESP32-S3 code in board_esp32s3.cpp (ADR-25). Not for other modules.

namespace board {
namespace s3 {

void boardBegin();   // from board::begin(): release pad holds, configure the board's pins
void armWake();      // before the deep sleep: arm the board's wake button (timer wake is armed by the caller)

// FW-112/FW-117: battery voltage in mV. Load switch `enPin` HIGH only while measuring, `settleMs`, 16 samples of
// analogReadMilliVolts (11 dB, eFuse calibration), x mulNum/mulDen for the divider. 0 = not plausible/failed.
uint16_t readBatteryMv(int adcPin, int enPin, uint32_t settleMs, uint32_t mulNum, uint32_t mulDen);

}  // namespace s3
}  // namespace board

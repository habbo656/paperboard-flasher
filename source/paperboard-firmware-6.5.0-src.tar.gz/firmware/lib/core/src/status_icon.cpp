#include "status_icon.h"

#include <string.h>

namespace core {

Window alignedWindow(const Rect& area) {
  Window win;
  if (!area.valid()) return win;
  int16_t x0 = area.x - area.x % 8;
  int16_t x1 = area.x + area.w;  // exclusive
  if (x1 % 8) x1 += 8 - x1 % 8;
  win.x = x0;
  win.y = area.y;
  win.w = x1 - x0;
  win.h = area.h;
  if (win.size() > MAX_WINDOW_BYTES) return Window();
  return win;
}

void copyWindow(const uint8_t* frame, const Window& win, uint8_t* out, int16_t panelW) {
  const size_t bpr = win.bytesPerRow();
  for (int16_t row = 0; row < win.h; row++) {
    memcpy(out + row * bpr, frame + ((size_t)(win.y + row) * panelW + win.x) / 8, bpr);
  }
}

void copyWindow2bpp(const uint8_t* frame, const Window& win, uint8_t* out, int16_t panelW) {
  const size_t bpr = win.bytesPerRow() * 2;
  for (int16_t row = 0; row < win.h; row++) {
    memcpy(out + row * bpr, frame + ((size_t)(win.y + row) * panelW + win.x) / 4, bpr);
  }
}

void maskFrom2bpp(const uint8_t* win2, const Window& win, uint8_t* mask) {
  const size_t bpr = win.bytesPerRow();  // 1-bpp bytes per row; the 2-bpp row is twice as long
  for (int16_t row = 0; row < win.h; row++) {
    for (size_t b = 0; b < bpr; b++) {
      uint8_t m = 0;
      for (int half = 0; half < 2; half++) {
        const uint8_t v = win2[(size_t)row * bpr * 2 + b * 2 + half];
        for (int p = 0; p < 4; p++)
          if (((v >> (6 - 2 * p)) & 3) != 0) m |= (uint8_t)(0x80 >> (half * 4 + p));
      }
      mask[(size_t)row * bpr + b] = m;
    }
  }
}

void mergeMask2bpp(uint8_t* win2, const Window& win, const uint8_t* mask) {
  const size_t bpr = win.bytesPerRow();
  for (int16_t row = 0; row < win.h; row++) {
    for (size_t b = 0; b < bpr; b++) {
      const uint8_t m = mask[(size_t)row * bpr + b];
      for (int half = 0; half < 2; half++) {
        uint8_t v = 0;
        for (int p = 0; p < 4; p++)
          if (m & (0x80 >> (half * 4 + p))) v |= (uint8_t)(1 << (6 - 2 * p));  // white = 01
        win2[(size_t)row * bpr * 2 + b * 2 + half] = v;
      }
    }
  }
}

static void setPixel(uint8_t* window, const Window& win, int16_t x, int16_t y, bool white) {
  if (x < 0 || y < 0 || x >= win.w || y >= win.h) return;
  uint8_t& b = window[(size_t)y * win.bytesPerRow() + x / 8];
  uint8_t mask = 0x80 >> (x % 8);
  if (white) b |= mask;
  else b &= ~mask;
}

void drawOfflineIcon(uint8_t* window, const Window& win, const Rect& area) {
  // icon origin in window coordinates, centred in the status area
  const int16_t ox = area.x - win.x + (area.w - ICON_SIZE) / 2;
  const int16_t oy = area.y - win.y + (area.h - ICON_SIZE) / 2;
  const float c = (ICON_SIZE - 1) / 2.0f;
  for (int16_t y = 0; y < ICON_SIZE; y++) {
    for (int16_t x = 0; x < ICON_SIZE; x++) {
      const float dx = x - c, dy = y - c;
      const float d2 = dx * dx + dy * dy;
      if (d2 > c * c + c) continue;  // outside the disc: keep frame content
      const bool ring = d2 >= (c - 2.5f) * (c - 2.5f);
      const float diag1 = dx - dy, diag2 = dx + dy;
      const bool onDiag = (diag1 > -1.6f && diag1 < 1.6f) || (diag2 > -1.6f && diag2 < 1.6f);
      const bool cross = d2 <= (c - 5.0f) * (c - 5.0f) && onDiag;
      setPixel(window, win, ox + x, oy + y, !(ring || cross));
    }
  }
}

}  // namespace core

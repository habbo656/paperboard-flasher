#pragma once
// Platform-independent poll logic (FW-031, FW-035, FW-050, IF-003). Unit-tested in test/test_poll_logic.

#include <stddef.h>
#include <stdint.h>

namespace core {

// Poll interval from X-Poll-S, bounded to 5 s … 1 h; default 15 s if missing/invalid (FW-031).
constexpr uint32_t POLL_MIN_S = 5;
constexpr uint32_t POLL_MAX_S = 3600;
constexpr uint32_t POLL_DEFAULT_S = 15;
uint32_t clampPollSeconds(const char* header);

// Retry delay after consecutive failures: 15, 30, 60, 60, … seconds (FW-050).
uint32_t backoffSeconds(uint32_t consecutiveFailures);

struct Rect {
  int16_t x = 0, y = 0, w = 0, h = 0;
  bool valid() const { return w > 0 && h > 0; }
};

// "x,y,w,h" (X-Status-Area) → rect inside the panelW x panelH panel (default 400x300; the board passes its own size, IF-022); invalid → !valid().
Rect parseStatusArea(const char* header, int16_t panelW = 400, int16_t panelH = 300);

// Partial refresh bookkeeping: count partials since the last full refresh (sent as X-Partial-Count).
struct RefreshCounter {
  uint32_t partialsSinceFull = 0;
  void onRefresh(bool full) { partialsSinceFull = full ? 0 : partialsSinceFull + 1; }
};

// Minimum time between two panel refreshes (FW-103): floor 0 = off. Wrap-safe (millis() overflow).
struct RefreshFloor {
  uint32_t lastMs = 0;
  bool valid = false;
  void onRefresh(uint32_t now) {
    lastMs = now;
    valid = true;
  }
  // Milliseconds until the next refresh is allowed; 0 if none refreshed yet or the floor has passed.
  uint32_t remainingMs(uint32_t now, uint32_t floorMs) const {
    if (!valid) return 0;
    const uint32_t elapsed = now - lastMs;
    return elapsed >= floorMs ? 0 : floorMs - elapsed;
  }
};

}  // namespace core

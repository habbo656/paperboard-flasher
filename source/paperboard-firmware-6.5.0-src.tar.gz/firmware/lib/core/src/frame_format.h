#pragma once
// Frame format negotiation and plane handling (IF-003, IF-021, FW-034, FW-101, ADR-20). Unit-tested in
// test/test_frame_format.

#include <stddef.h>
#include <stdint.h>

namespace core {

constexpr size_t PLANE_BYTES = 400 * 300 / 8;  // 400x300 boards (D1 mini, NM-EPD-420); default of the functions below

// Bytes of one 1-bpp plane of a w x h panel (IF-022). Width must be a multiple of 8.
constexpr size_t planeBytes(int w, int h) { return (size_t)w / 8 * (size_t)h; }

// Number of planes of a response whose X-Frame-Format header is `hdr` (nullptr = header missing = "bw").
// Accepted: exactly "bw" (1 plane) and the board's own format `ownFmt` ("bw", "bwr" or "bwry"; the latter two
// = 2 planes of length; bwry is packed 2 bpp, IF-023, a bwry body on a bwr board and vice versa is rejected).
// Anything else (case, whitespace, prefixes, empty, unknown) returns 0 = reject.
uint8_t framePlanes(const char* hdr, const char* ownFmt);

// Content-Length is exactly planes x plane size (default 400x300; the board passes planeBytes(PANEL_W, PANEL_H), IF-022),
// fits the frame buffer, and is not chunked (-1).
bool frameLengthValid(long contentLength, uint8_t planes, size_t bufBytes, size_t plane = PLANE_BYTES);

// "Red wins" (ADR-20): where red ink is set (bit 0 in red), clear the black ink (set the bit to 1 = white).
void resolveRed(uint8_t* black, const uint8_t* red, size_t n);

// FW-116, IF-023: expands a 1-bpp plane (planeBytes, 1 = white) in place to the packed 2-bpp bwry layout (2 x
// planeBytes; buf must hold that): white -> 01, black -> 00, leftmost pixel in bits 7-6. Runs back to front.
void expandBwTo2bpp(uint8_t* buf, size_t planeBytes);

}  // namespace core

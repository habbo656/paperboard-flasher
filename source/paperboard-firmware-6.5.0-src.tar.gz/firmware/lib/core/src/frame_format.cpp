#include "frame_format.h"

#include <string.h>

namespace core {

uint8_t framePlanes(const char* hdr, const char* ownFmt) {
  if (!hdr) return 1;  // missing header = bw (IF-021)
  if (strcmp(hdr, "bw") == 0) return 1;
  // bwr = black + red plane, bwry = packed 2 bpp (IF-023): both are 2 x the 1-bpp plane in length
  if (ownFmt && strcmp(hdr, ownFmt) == 0) return strcmp(hdr, "bwr") == 0 || strcmp(hdr, "bwry") == 0 ? 2 : 0;
  return 0;
}

bool frameLengthValid(long contentLength, uint8_t planes, size_t bufBytes, size_t plane) {
  if (planes == 0 || contentLength < 0) return false;
  const size_t want = (size_t)planes * plane;
  return (size_t)contentLength == want && want <= bufBytes;
}

void resolveRed(uint8_t* black, const uint8_t* red, size_t n) {
  for (size_t i = 0; i < n; i++) black[i] |= (uint8_t)~red[i];
}

// Spreads the 4 bits of a nibble (bit 3 = leftmost pixel) to 2 bpp codes: 1 (white) -> 01, 0 (black) -> 00.
static uint8_t spreadNibble(uint8_t n) {
  return (uint8_t)(((n & 8) << 3) | ((n & 4) << 2) | ((n & 2) << 1) | (n & 1));
}

void expandBwTo2bpp(uint8_t* buf, size_t planeBytes) {
  for (size_t i = planeBytes; i-- > 0;) {  // back to front: 2i >= i, the source byte is read before it is overwritten
    const uint8_t b = buf[i];
    buf[2 * i] = spreadNibble(b >> 4);
    buf[2 * i + 1] = spreadNibble(b & 0x0F);
  }
}

}  // namespace core

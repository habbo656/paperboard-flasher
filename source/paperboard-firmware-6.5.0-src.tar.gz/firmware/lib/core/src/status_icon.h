#pragma once
// Offline icon overlay for the status area (FW-051).
// The frame (1 bpp, panel width as parameter: 400 or 800, IF-022, MSB first, 1 = white) stays untouched; the icon is composed into a small
// byte-aligned window copied from it, which is then written to the panel with a partial refresh.

#include <stddef.h>
#include <stdint.h>

#include "poll_logic.h"

namespace core {

constexpr int16_t ICON_SIZE = 24;
constexpr int16_t PANEL_W = 400;  // default panel width of copyWindow
constexpr size_t MAX_WINDOW_BYTES = 8 * 64;  // up to 64 px wide (8 bytes) and 64 rows

// Byte-aligned window around a status area (x and w multiples of 8, as the controller requires).
struct Window {
  int16_t x = 0, y = 0, w = 0, h = 0;
  size_t bytesPerRow() const { return (size_t)w / 8; }
  size_t size() const { return bytesPerRow() * (size_t)h; }
};

Window alignedWindow(const Rect& area);

// Copies the window's bytes out of the full frame into out (size() bytes).
void copyWindow(const uint8_t* frame, const Window& win, uint8_t* out, int16_t panelW = PANEL_W);

// FW-116 (4-colour panel, packed 2 bpp bwry, 4 px per byte, 00 black / 01 white / 10 yellow / 11 red): window bytes
// per row are w/4. copyWindow2bpp copies them out of the frame (size 2 x size()); maskFrom2bpp builds the 1-bpp mask
// (0 = black ink, 1 = anything else) that drawOfflineIcon works on; mergeMask2bpp writes the mask back as 00/01, so
// yellow and red under the window are cleared while the icon is shown (the same as FW-051 does for the red plane).
void copyWindow2bpp(const uint8_t* frame, const Window& win, uint8_t* out, int16_t panelW = PANEL_W);
void maskFrom2bpp(const uint8_t* win2, const Window& win, uint8_t* mask);
void mergeMask2bpp(uint8_t* win2, const Window& win, const uint8_t* mask);

// Draws the offline icon (24x24, centred in area) into the window buffer: white disc with black ring
// and a black X – rotation-symmetric, so it reads the same for every display rotation.
void drawOfflineIcon(uint8_t* window, const Window& win, const Rect& area);

}  // namespace core

#include <initializer_list>
#include <string.h>
#include <unity.h>

#include "crc32.h"
#include "frame_format.h"

using namespace core;

void setUp() {}
void tearDown() {}

void test_planes_bw_board() {
  TEST_ASSERT_EQUAL_UINT8(1, framePlanes(nullptr, "bw"));
  TEST_ASSERT_EQUAL_UINT8(1, framePlanes("bw", "bw"));
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes("bwr", "bw"));
}

void test_planes_bwr_board() {
  TEST_ASSERT_EQUAL_UINT8(1, framePlanes(nullptr, "bwr"));
  TEST_ASSERT_EQUAL_UINT8(1, framePlanes("bw", "bwr"));
  TEST_ASSERT_EQUAL_UINT8(2, framePlanes("bwr", "bwr"));
}

void test_planes_reject() {
  for (const char* h : {"BWR", "bwr ", " bwr", "bwry", "", "b", "bwrbwr", "Bw", "bw\r"})
    TEST_ASSERT_EQUAL_UINT8_MESSAGE(0, framePlanes(h, "bwr"), h);
  char longHdr[200];
  memset(longHdr, 'b', sizeof(longHdr) - 1);
  longHdr[sizeof(longHdr) - 1] = 0;
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes(longHdr, "bwr"));
}

void test_length() {
  TEST_ASSERT_TRUE(frameLengthValid(15000, 1, 30000));
  TEST_ASSERT_TRUE(frameLengthValid(30000, 2, 30000));
  TEST_ASSERT_FALSE(frameLengthValid(29999, 2, 30000));
  TEST_ASSERT_FALSE(frameLengthValid(30001, 2, 30000));
  TEST_ASSERT_FALSE(frameLengthValid(-1, 2, 30000));
  TEST_ASSERT_FALSE(frameLengthValid(15000, 0, 30000));
  TEST_ASSERT_FALSE(frameLengthValid(30000, 2, 15000));  // does not fit the buffer
}

// FW-114, IF-022: the 800x480 b/w board accepts exactly 48 000 B.
void test_length_800x480() {
  constexpr size_t P = planeBytes(800, 480);
  TEST_ASSERT_EQUAL_UINT32(48000, P);
  TEST_ASSERT_EQUAL_UINT32(15000, planeBytes(400, 300));
  TEST_ASSERT_TRUE(frameLengthValid(48000, 1, 48000, P));
  TEST_ASSERT_FALSE(frameLengthValid(15000, 1, 48000, P));  // 400x300 body from an old app
  TEST_ASSERT_FALSE(frameLengthValid(30000, 2, 48000, P));
  TEST_ASSERT_FALSE(frameLengthValid(47999, 1, 48000, P));
  TEST_ASSERT_FALSE(frameLengthValid(48001, 1, 48000, P));
  TEST_ASSERT_FALSE(frameLengthValid(-1, 1, 48000, P));      // chunked
  TEST_ASSERT_FALSE(frameLengthValid(96000, 2, 48000, P));   // bwr does not fit
  TEST_ASSERT_FALSE(frameLengthValid(48000, 1, 15000, P));   // buffer too small
  TEST_ASSERT_FALSE(frameLengthValid(48000, 1, 30000));      // 400x300 board rejects the large body
}

void test_resolve_red() {
  uint8_t black[4] = {0x00, 0xFF, 0x00, 0xF0};  // 0 = ink
  uint8_t red[4] = {0x00, 0x00, 0xFF, 0xFF};
  resolveRed(black, red, 4);
  TEST_ASSERT_EQUAL_HEX8(0xFF, black[0]);  // both inked -> black cleared
  TEST_ASSERT_EQUAL_HEX8(0xFF, black[1]);  // red only: black stays white
  TEST_ASSERT_EQUAL_HEX8(0x00, black[2]);  // black only: unchanged
  TEST_ASSERT_EQUAL_HEX8(0xF0, black[3]);  // partial black, no red: unchanged
  TEST_ASSERT_EQUAL_HEX8(0x00, red[0]);    // red plane untouched
  const uint8_t once[4] = {black[0], black[1], black[2], black[3]};
  resolveRed(black, red, 4);
  TEST_ASSERT_EQUAL_MEMORY(once, black, 4);  // idempotent
}

void test_crc_two_planes() {
  static uint8_t body[2 * PLANE_BYTES];
  for (size_t i = 0; i < sizeof(body); i++) body[i] = (uint8_t)(i * 13 + 5);
  const uint32_t whole = crc32Update(0, body, sizeof(body));
  const uint32_t parts = crc32Update(crc32Update(0, body, PLANE_BYTES), body + PLANE_BYTES, PLANE_BYTES);
  TEST_ASSERT_EQUAL_HEX32(whole, parts);
}

// FW-116, IF-023: the 4C board accepts bw and bwry (2 x plane length), rejects bwr; the 3C rejects bwry.
void test_planes_bwry_board() {
  TEST_ASSERT_EQUAL_UINT8(1, framePlanes(nullptr, "bwry"));
  TEST_ASSERT_EQUAL_UINT8(1, framePlanes("bw", "bwry"));
  TEST_ASSERT_EQUAL_UINT8(2, framePlanes("bwry", "bwry"));
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes("bwr", "bwry"));
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes("BWRY", "bwry"));
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes("bwry ", "bwry"));
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes("bwry", "bwr"));
  TEST_ASSERT_EQUAL_UINT8(0, framePlanes("bwry", "bw"));
  TEST_ASSERT_TRUE(frameLengthValid(30000, 2, 30000));
  TEST_ASSERT_TRUE(frameLengthValid(15000, 1, 30000));  // bw body, expanded in place afterwards
}

// bit 1 = white -> 01, bit 0 = black -> 00; leftmost pixel in bits 7-6
void test_expand_bw_2bpp() {
  uint8_t b[6] = {0xFF, 0x00, 0xA5, 0, 0, 0};
  expandBwTo2bpp(b, 3);
  const uint8_t want[6] = {0x55, 0x55, 0x00, 0x00, 0x44, 0x11};  // 0xA5 = 1010 0101 -> 01 00 01 00 | 00 01 00 01
  TEST_ASSERT_EQUAL_HEX8(want[0], b[0]);
  TEST_ASSERT_EQUAL_HEX8(want[1], b[1]);
  TEST_ASSERT_EQUAL_HEX8(want[2], b[2]);
  TEST_ASSERT_EQUAL_HEX8(want[3], b[3]);
  TEST_ASSERT_EQUAL_HEX8(want[4], b[4]);
  TEST_ASSERT_EQUAL_HEX8(want[5], b[5]);
}

void test_expand_bw_2bpp_all_patterns_in_place() {
  static uint8_t buf[512], ref[256];
  for (int i = 0; i < 256; i++) ref[i] = (uint8_t)i;
  memcpy(buf, ref, 256);
  expandBwTo2bpp(buf, 256);
  for (int i = 0; i < 256; i++) {
    for (int px = 0; px < 8; px++) {
      const uint8_t code = (buf[2 * i + px / 4] >> (6 - 2 * (px % 4))) & 3;
      const uint8_t white = (ref[i] >> (7 - px)) & 1;
      TEST_ASSERT_EQUAL_UINT8(white ? 1 : 0, code);  // never yellow (2) or red (3)
    }
  }
}

void test_expand_bw_2bpp_full_frame() {
  static uint8_t buf[30000];
  memset(buf, 0xFF, 15000);
  buf[14999] = 0xFE;  // last pixel black
  expandBwTo2bpp(buf, 15000);
  TEST_ASSERT_EQUAL_HEX8(0x55, buf[0]);
  TEST_ASSERT_EQUAL_HEX8(0x55, buf[29997]);
  TEST_ASSERT_EQUAL_HEX8(0x55, buf[29998]);
  TEST_ASSERT_EQUAL_HEX8(0x54, buf[29999]);
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_planes_bw_board);
  RUN_TEST(test_planes_bwr_board);
  RUN_TEST(test_planes_reject);
  RUN_TEST(test_length);
  RUN_TEST(test_length_800x480);
  RUN_TEST(test_resolve_red);
  RUN_TEST(test_crc_two_planes);
  RUN_TEST(test_planes_bwry_board);
  RUN_TEST(test_expand_bw_2bpp);
  RUN_TEST(test_expand_bw_2bpp_all_patterns_in_place);
  RUN_TEST(test_expand_bw_2bpp_full_frame);
  return UNITY_END();
}

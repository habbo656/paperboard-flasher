#include <string.h>
#include <unity.h>

#include "poll_logic.h"
#include "status_icon.h"

using namespace core;

void setUp() {}
void tearDown() {}

void test_poll_interval_bounds() {
  TEST_ASSERT_EQUAL_UINT32(15, clampPollSeconds(nullptr));
  TEST_ASSERT_EQUAL_UINT32(15, clampPollSeconds(""));
  TEST_ASSERT_EQUAL_UINT32(15, clampPollSeconds("abc"));
  TEST_ASSERT_EQUAL_UINT32(15, clampPollSeconds("12x"));
  TEST_ASSERT_EQUAL_UINT32(15, clampPollSeconds("0"));
  TEST_ASSERT_EQUAL_UINT32(15, clampPollSeconds("-3"));
  TEST_ASSERT_EQUAL_UINT32(5, clampPollSeconds("1"));
  TEST_ASSERT_EQUAL_UINT32(30, clampPollSeconds("30"));
  TEST_ASSERT_EQUAL_UINT32(3600, clampPollSeconds("99999"));
}

void test_backoff() {
  TEST_ASSERT_EQUAL_UINT32(15, backoffSeconds(1));
  TEST_ASSERT_EQUAL_UINT32(30, backoffSeconds(2));
  TEST_ASSERT_EQUAL_UINT32(60, backoffSeconds(3));
  TEST_ASSERT_EQUAL_UINT32(60, backoffSeconds(100));
}

void test_status_area_parsing() {
  Rect r = parseStatusArea("373,3,24,24");
  TEST_ASSERT_TRUE(r.valid());
  TEST_ASSERT_EQUAL_INT16(373, r.x);
  TEST_ASSERT_EQUAL_INT16(24, r.h);
  TEST_ASSERT_FALSE(parseStatusArea(nullptr).valid());
  TEST_ASSERT_FALSE(parseStatusArea("1,2,3").valid());
  TEST_ASSERT_FALSE(parseStatusArea("1,2,3,4,5").valid());
  TEST_ASSERT_FALSE(parseStatusArea("390,0,24,24").valid());  // outside the panel
  TEST_ASSERT_FALSE(parseStatusArea("-1,0,24,24").valid());
  TEST_ASSERT_FALSE(parseStatusArea("a,b,c,d").valid());
}

// FW-114, IF-022: X-Status-Area is in panel coordinates and bounds-checked against the board's own size.
void test_status_area_800x480() {
  Rect r = parseStatusArea("573,93,24,24", 800, 480);  // 400x300 area (373,3) shifted by (200,90)
  TEST_ASSERT_TRUE(r.valid());
  TEST_ASSERT_EQUAL_INT16(573, r.x);
  TEST_ASSERT_EQUAL_INT16(93, r.y);
  TEST_ASSERT_TRUE(parseStatusArea("776,456,24,24", 800, 480).valid());   // flush with the corner
  TEST_ASSERT_FALSE(parseStatusArea("777,456,24,24", 800, 480).valid());
  TEST_ASSERT_FALSE(parseStatusArea("776,457,24,24", 800, 480).valid());
  TEST_ASSERT_FALSE(parseStatusArea("573,93,24,24").valid());             // an 800x480 rect is invalid for 400x300
  TEST_ASSERT_TRUE(parseStatusArea("373,3,24,24", 800, 480).valid());     // and a 400x300 rect stays valid for 800x480
}

void test_refresh_counter() {
  RefreshCounter c;
  c.onRefresh(false);
  c.onRefresh(false);
  TEST_ASSERT_EQUAL_UINT32(2, c.partialsSinceFull);
  c.onRefresh(true);
  TEST_ASSERT_EQUAL_UINT32(0, c.partialsSinceFull);
}

void test_refresh_floor() {
  RefreshFloor f;
  TEST_ASSERT_EQUAL_UINT32(0, f.remainingMs(1000, 60000));  // nothing refreshed yet
  f.onRefresh(1000);
  TEST_ASSERT_EQUAL_UINT32(0, f.remainingMs(1000, 0));      // floor 0 = off
  TEST_ASSERT_EQUAL_UINT32(60000, f.remainingMs(1000, 60000));
  TEST_ASSERT_EQUAL_UINT32(15000, f.remainingMs(46000, 60000));
  TEST_ASSERT_EQUAL_UINT32(0, f.remainingMs(61000, 60000));
  TEST_ASSERT_EQUAL_UINT32(0, f.remainingMs(500000, 60000));
}

void test_refresh_floor_wrap() {
  RefreshFloor f;
  f.onRefresh(0xFFFFFF00u);
  TEST_ASSERT_EQUAL_UINT32(60000 - 0x100 - 100, f.remainingMs(100, 60000));  // millis() wrapped
  TEST_ASSERT_EQUAL_UINT32(0, f.remainingMs(60000, 60000));
}

void test_refresh_floor_kick_deferred() {
  // kick: nextPoll = now + remaining -> not dropped, runs when the floor ends
  RefreshFloor f;
  f.onRefresh(10000);
  const uint32_t now = 30000;
  const uint32_t next = now + f.remainingMs(now, 60000);
  TEST_ASSERT_EQUAL_UINT32(70000, next);
  TEST_ASSERT_EQUAL_UINT32(0, f.remainingMs(next, 60000));
}

void test_aligned_window() {
  Window w = alignedWindow(parseStatusArea("373,3,24,24"));
  TEST_ASSERT_EQUAL_INT16(368, w.x);
  TEST_ASSERT_EQUAL_INT16(32, w.w);  // 368..399
  TEST_ASSERT_EQUAL_INT16(3, w.y);
  TEST_ASSERT_EQUAL_UINT32(4 * 24, w.size());
  Window a = alignedWindow(parseStatusArea("8,0,16,16"));
  TEST_ASSERT_EQUAL_INT16(8, a.x);
  TEST_ASSERT_EQUAL_INT16(16, a.w);
}

void test_copy_window_and_icon() {
  static uint8_t frame[15000];
  memset(frame, 0x00, sizeof(frame));  // all black (like a black header)
  Rect area = parseStatusArea("373,3,24,24");
  Window win = alignedWindow(area);
  uint8_t buf[MAX_WINDOW_BYTES];
  copyWindow(frame, win, buf);
  for (size_t i = 0; i < win.size(); i++) TEST_ASSERT_EQUAL_HEX8(0x00, buf[i]);
  drawOfflineIcon(buf, win, area);
  // centre pixel is part of the X → black; a pixel between ring and cross → white
  auto px = [&](int x, int y) { return (buf[y * win.bytesPerRow() + x / 8] >> (7 - x % 8)) & 1; };
  int cx = area.x - win.x + 12, cy = 12;
  TEST_ASSERT_EQUAL_INT(0, px(cx, cy));
  TEST_ASSERT_EQUAL_INT(1, px(cx, cy - 6));
  // pixels left of the area (inside the window, outside the disc) keep the frame content
  TEST_ASSERT_EQUAL_INT(0, px(0, 0));
}

void test_copy_window_800() {
  static uint8_t frame[48000];
  memset(frame, 0xFF, sizeof(frame));
  Rect area = parseStatusArea("573,93,24,24", 800, 480);
  Window win = alignedWindow(area);
  TEST_ASSERT_EQUAL_INT16(568, win.x);
  TEST_ASSERT_EQUAL_INT16(32, win.w);
  // mark the first window byte of row 93 (byte 568/8 = 71 in a 100-byte row)
  frame[93 * 100 + 71] = 0x12;
  frame[94 * 100 + 71] = 0x34;
  uint8_t buf[MAX_WINDOW_BYTES];
  copyWindow(frame, win, buf, 800);
  TEST_ASSERT_EQUAL_HEX8(0x12, buf[0]);
  TEST_ASSERT_EQUAL_HEX8(0x34, buf[win.bytesPerRow()]);
  TEST_ASSERT_EQUAL_HEX8(0xFF, buf[1]);
}

// FW-116, FW-051: 2-bpp window of the 4C panel; the mask round trip clears yellow/red, restore = original bytes.
void test_window_2bpp_mask_roundtrip() {
  static uint8_t frame[30000];
  memset(frame, 0x55, sizeof(frame));  // all white
  Rect area = parseStatusArea("373,3,24,24");
  Window win = alignedWindow(area);
  // row 3 of the frame, pixels 368..: black, white, yellow, red, then white
  uint8_t* row = frame + 3 * 100 + 368 / 4;
  row[0] = (uint8_t)((0 << 6) | (1 << 4) | (2 << 2) | 3);
  static uint8_t orig[2 * MAX_WINDOW_BYTES], win2[2 * MAX_WINDOW_BYTES], mask[MAX_WINDOW_BYTES];
  copyWindow2bpp(frame, win, orig);
  TEST_ASSERT_EQUAL_HEX8(row[0], orig[0]);
  memcpy(win2, orig, win.size() * 2);
  maskFrom2bpp(win2, win, mask);
  TEST_ASSERT_EQUAL_HEX8(0x70, mask[0] & 0xF0);  // black = 0 (ink), white/yellow/red = 1
  drawOfflineIcon(mask, win, area);
  mergeMask2bpp(win2, win, mask);
  for (size_t i = 0; i < win.size() * 2; i++)  // only 00 or 01 codes
    for (int p = 0; p < 4; p++) TEST_ASSERT_TRUE(((win2[i] >> (6 - 2 * p)) & 3) <= 1);
  // pixel 0 (black) stays black; pixel 2 (yellow) and 3 (red) are cleared to white unless the icon covers them
  TEST_ASSERT_EQUAL_UINT8(0, (win2[0] >> 6) & 3);
  TEST_ASSERT_EQUAL_UINT8(1, (win2[0] >> 2) & 3);
  TEST_ASSERT_EQUAL_UINT8(1, win2[0] & 3);
  // icon centre is black
  const int cx = area.x - win.x + 12, cy = 12;
  TEST_ASSERT_EQUAL_UINT8(0, (win2[cy * win.bytesPerRow() * 2 + cx / 4] >> (6 - 2 * (cx % 4))) & 3);
  // restore: copying the saved window back gives the original frame
  uint8_t saved[30000];
  memcpy(saved, frame, sizeof(saved));
  for (int16_t r = 0; r < win.h; r++) memcpy(frame + (size_t)(win.y + r) * 100 + win.x / 4, win2 + (size_t)r * win.bytesPerRow() * 2, win.bytesPerRow() * 2);
  for (int16_t r = 0; r < win.h; r++) memcpy(frame + (size_t)(win.y + r) * 100 + win.x / 4, orig + (size_t)r * win.bytesPerRow() * 2, win.bytesPerRow() * 2);
  TEST_ASSERT_EQUAL_MEMORY(saved, frame, sizeof(saved));
}

void test_window_2bpp_mask_pixels() {
  Window win;
  win.x = 0; win.y = 0; win.w = 16; win.h = 1;
  const uint8_t w2[4] = {0x1B, 0x00, 0xFF, 0x55};  // 00 01 10 11 | 00 00 00 00 | 11 11 11 11 | 01 01 01 01
  uint8_t mask[2];
  maskFrom2bpp(w2, win, mask);
  TEST_ASSERT_EQUAL_HEX8(0x70, mask[0]);
  TEST_ASSERT_EQUAL_HEX8(0xFF, mask[1]);
  uint8_t out[4];
  mergeMask2bpp(out, win, mask);
  TEST_ASSERT_EQUAL_HEX8(0x15, out[0]);  // mask 0111 -> 00 01 01 01
  TEST_ASSERT_EQUAL_HEX8(0x00, out[1]);  // mask 0000 -> all black
  TEST_ASSERT_EQUAL_HEX8(0x55, out[2]);
  TEST_ASSERT_EQUAL_HEX8(0x55, out[3]);
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_poll_interval_bounds);
  RUN_TEST(test_backoff);
  RUN_TEST(test_status_area_parsing);
  RUN_TEST(test_status_area_800x480);
  RUN_TEST(test_refresh_counter);
  RUN_TEST(test_refresh_floor);
  RUN_TEST(test_refresh_floor_wrap);
  RUN_TEST(test_refresh_floor_kick_deferred);
  RUN_TEST(test_aligned_window);
  RUN_TEST(test_copy_window_and_icon);
  RUN_TEST(test_copy_window_800);
  RUN_TEST(test_window_2bpp_mask_roundtrip);
  RUN_TEST(test_window_2bpp_mask_pixels);
  return UNITY_END();
}

#include "power.h"

#include <Arduino.h>

#include "board.h"
#include "board_net.h"
#include "display.h"
#include "poller.h"

namespace power {

static core::WakeClock clock_;
static core::WakeKind kind_ = core::WakeKind::Boot;
static uint8_t bssid_[6];
static uint8_t channel_ = 0;

void begin() {
  uint8_t raw[core::SLEEP_RECORD_BYTES];
  core::SleepRecord rec;  // 56 B on the stack; no static mirror (D1 RAM budget)
  bool valid = false;
  if (board::DEEP_SLEEP) {
    board::rtcRead(board::Rtc::Sleep, raw, sizeof(raw));
    valid = core::unpackSleepRecord(raw, &rec);
  }
  kind_ = valid ? board::wakeReason() : core::WakeKind::Boot;
  uint32_t sleptS = 0;
  if (kind_ != core::WakeKind::Boot) {
    sleptS = board::sleptMs(rec.plannedSleepS * 1000UL) / 1000;
    clock_.startWake(millis(), rec.uptimeAtSleepS, sleptS);
    poller::restoreEtag(rec.etag);                                    // FW-032 across sleeps: unchanged = 304
    display::restoreRefresh(rec.sinceRefreshS, sleptS);              // FW-103 across a button wake
  } else {
    clock_.startCold(millis());
  }
  if (valid && rec.hasBssid) {
    memcpy(bssid_, rec.bssid, sizeof(bssid_));
    channel_ = rec.channel;  // 0 = none
  }
}

core::WakeKind wake() { return kind_; }
bool realReset() { return kind_ == core::WakeKind::Boot; }
uint32_t uptimeS() { return clock_.uptimeS(millis()); }

bool hasBssid() { return channel_ != 0; }
const uint8_t* bssid() { return bssid_; }
uint8_t channel() { return channel_; }
void clearBssid() { channel_ = 0; }

void sleepFor(uint32_t seconds) {
  core::SleepRecord rec;
  strlcpy(rec.etag, poller::etag(), sizeof(rec.etag));
  board::wifiApInfo(bssid_, &channel_);  // remember the access point for the fast reconnect
  if (hasBssid()) {
    memcpy(rec.bssid, bssid_, sizeof(rec.bssid));
    rec.channel = channel_;
    rec.hasBssid = true;
  }
  rec.uptimeAtSleepS = uptimeS();
  rec.plannedSleepS = seconds;
  rec.sinceRefreshS = display::refreshAgeS();
  uint8_t raw[core::SLEEP_RECORD_BYTES];
  core::packSleepRecord(rec, raw);
  board::rtcWrite(board::Rtc::Sleep, raw, sizeof(raw));  // RTC memory: no flash write per wake
  Serial.printf_P(PSTR("[sleep] deep sleep for %lu s (up %lu s)\n"), (unsigned long)seconds, (unsigned long)rec.uptimeAtSleepS);
  board::prepareSleep();
  display::hibernate();  // FW-036
  board::deepSleep(seconds);
}

}  // namespace power

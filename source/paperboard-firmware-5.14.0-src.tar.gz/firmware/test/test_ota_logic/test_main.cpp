#include <stdio.h>
#include <string.h>
#include <unity.h>

#include "ota_logic.h"
#include "sleep_logic.h"

using namespace core;

void setUp() {}
void tearDown() {}

static const char* MD5 = "0123456789abcdef0123456789abcdef";

static bool parse(const char* h, OtaHint* o) { return parseOtaHint(h, o, nullptr); }

void test_hint_valid() {
  OtaHint h;
  TEST_ASSERT_TRUE(parse("0.3.0;/firmware/0.3.0.bin;0123456789ABCDEF0123456789abcdef", &h));
  TEST_ASSERT_EQUAL_STRING("0.3.0", h.version);
  TEST_ASSERT_EQUAL_STRING(MD5, h.md5);
}

void test_hint_invalid() {
  OtaHint h;
  TEST_ASSERT_FALSE(parse(nullptr, &h));
  TEST_ASSERT_FALSE(parse("", &h));
  TEST_ASSERT_FALSE(parse("0.3.0", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/0.3.0.bin", &h));
  TEST_ASSERT_FALSE(parse("0.3;/firmware/0.3.bin;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.0.1;/firmware/0.3.0.1.bin;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.;/firmware/0.3..bin;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;http://evil/firmware/0.3.0.bin;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/../app.js;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/0.3.1.bin;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/0.3.0.bin;0123456789abcdef0123456789abcde", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/0.3.0.bin;0123456789abcdef0123456789abcdef0", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/0.3.0.bin;0123456789abcdef0123456789abcdeg", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/0.3.0.bin;0123456789abcdef0123456789abcdef;x", &h));
  TEST_ASSERT_FALSE(parse("1234567.1234567.123;/firmware/1234567.1234567.123.bin;0123456789abcdef0123456789abcdef", &h));
}

void test_compare() {
  TEST_ASSERT_TRUE(compareVersions("0.10.0", "0.9.0") > 0);
  TEST_ASSERT_TRUE(compareVersions("0.3.0", "0.3.0") == 0);
  TEST_ASSERT_TRUE(compareVersions("0.2.9", "0.3.0") < 0);
  TEST_ASSERT_TRUE(compareVersions("1.0.0", "0.99.99") > 0);
}

void test_url() {
  char u[80];
  TEST_ASSERT_TRUE(otaUrl(u, sizeof(u), "http://192.168.1.2:8787/", "0.3.0", nullptr));
  TEST_ASSERT_EQUAL_STRING("http://192.168.1.2:8787/firmware/0.3.0.bin", u);
  TEST_ASSERT_TRUE(otaUrl(u, sizeof(u), "http://192.168.1.2:8787/", "0.3.0", "nm_epd_420"));
  TEST_ASSERT_EQUAL_STRING("http://192.168.1.2:8787/firmware/nm_epd_420/0.3.0.bin", u);
  TEST_ASSERT_FALSE(otaUrl(u, 20, "http://192.168.1.2:8787/", "0.3.0", nullptr));
  TEST_ASSERT_FALSE(otaUrl(u, 50, "http://192.168.1.2:8787/", "0.3.0", "nm_epd_420"));  // too small
  TEST_ASSERT_FALSE(otaUrl(u, sizeof(u), "http://h/", "../x", nullptr));
  TEST_ASSERT_FALSE(otaUrl(u, sizeof(u), "http://h/", "0.3.0", "../x"));
  TEST_ASSERT_FALSE(otaUrl(u, sizeof(u), "http://h/", "0.3.0", "NM"));
}

static const char* S3 = "nm_epd_420";
static bool parseS3(const char* h, OtaHint* o) { return parseOtaHint(h, o, S3); }

void test_hint_d1_rejects_board_paths() {  // FW-070: the D1 (API 2) takes only the legacy path
  OtaHint h;
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/d1_mini/0.3.0.bin;0123456789abcdef0123456789abcdef", &h));
  TEST_ASSERT_FALSE(parse("0.3.0;/firmware/nm_epd_420/0.3.0.bin;0123456789abcdef0123456789abcdef", &h));
}

void test_hint_s3() {  // IF-005, ADR-20: only the own board segment
  OtaHint h;
  TEST_ASSERT_TRUE(parseS3("0.3.0;/firmware/nm_epd_420/0.3.0.bin;0123456789ABCDEF0123456789abcdef", &h));
  TEST_ASSERT_EQUAL_STRING("0.3.0", h.version);
  TEST_ASSERT_EQUAL_STRING(MD5, h.md5);
  const char* m = ";0123456789abcdef0123456789abcdef";
  const char* bad[] = {
      "0.3.0;/firmware/0.3.0.bin",                 // legacy path = D1 image
      "0.3.0;/firmware/d1_mini/0.3.0.bin",
      "0.3.0;/firmware/nm_epd_42/0.3.0.bin",
      "0.3.0;/firmware/nm_epd_4200/0.3.0.bin",
      "0.3.0;/firmware/NM_EPD_420/0.3.0.bin",
      "0.3.0;/firmware/../0.3.0.bin",
      "0.3.0;/firmware//0.3.0.bin",
      "0.3.0;/firmware/nm_epd_420//0.3.0.bin",
      "0.3.0;/firmware/nm_epd_420/../0.3.0.bin",
      "0.3.0;/firmware/nm_epd_420/0.3.1.bin",      // version mismatch
      "0.3.0;/firmware/nm_epd_420/0.3.0.bin/x",
      "0.3.0;http://evil/firmware/nm_epd_420/0.3.0.bin",
  };
  for (const char* b : bad) {
    char hdr[160];
    snprintf(hdr, sizeof(hdr), "%s%s", b, m);
    TEST_ASSERT_FALSE_MESSAGE(parseS3(hdr, &h), b);
  }
  TEST_ASSERT_FALSE(parseOtaHint("0.3.0;/firmware/x/0.3.0.bin;0123456789abcdef0123456789abcdef", &h, "X"));  // bad own ID
  TEST_ASSERT_FALSE(parseOtaHint("0.3.0;/firmware/abcdefghijklmnopq/0.3.0.bin;0123456789abcdef0123456789abcdef", &h,
                                 "abcdefghijklmnopq"));  // too long
}

// First 24 bytes of real builds (firmware.bin of env d1_mini and nm_epd_420, v4.2.0)
static const uint8_t D1_HEAD[24] = {0xe9, 0x02, 0x02, 0x40, 0x80, 0xf4, 0x10, 0x40, 0x00, 0xf0, 0x10, 0x40,
                                    0x60, 0x0d, 0x00, 0x00, 0x00, 0x80, 0xfe, 0x3f, 0x00, 0x90, 0xfe, 0x3f};
static const uint8_t S3_HEAD[24] = {0xe9, 0x05, 0x02, 0x4f, 0xc8, 0x70, 0x37, 0x40, 0xee, 0x00, 0x00, 0x00,
                                    0x09, 0x00, 0x00, 0x00, 0x00, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x01};

void test_image_matches() {  // NFR-012: boards never flash each other's image
  TEST_ASSERT_TRUE(otaImageMatches(S3_HEAD, 24, true));
  TEST_ASSERT_FALSE(otaImageMatches(S3_HEAD, 24, false));
  TEST_ASSERT_TRUE(otaImageMatches(D1_HEAD, 24, false));
  TEST_ASSERT_FALSE(otaImageMatches(D1_HEAD, 24, true));
  TEST_ASSERT_FALSE(otaImageMatches(S3_HEAD, 23, true));  // too short
  TEST_ASSERT_FALSE(otaImageMatches(D1_HEAD, 0, false));
  TEST_ASSERT_FALSE(otaImageMatches(nullptr, 24, false));
  uint8_t bad[24];
  memcpy(bad, S3_HEAD, 24);
  bad[0] = 0x00;  // wrong magic
  TEST_ASSERT_FALSE(otaImageMatches(bad, 24, true));
}

void test_result_format() {
  char r[48];
  TEST_ASSERT_TRUE(formatOtaResult(r, sizeof(r), "0.3.0", "http-404"));
  TEST_ASSERT_EQUAL_STRING("0.3.0;http-404", r);
  TEST_ASSERT_FALSE(formatOtaResult(r, sizeof(r), "0.3.0", "Bad"));
  TEST_ASSERT_FALSE(formatOtaResult(r, sizeof(r), "0.3.0", ""));
  TEST_ASSERT_FALSE(formatOtaResult(r, sizeof(r), "0.3.0", "abcdefghijklmnopq"));
  TEST_ASSERT_FALSE(formatOtaResult(r, sizeof(r), "x", "md5"));
  TEST_ASSERT_TRUE(formatOtaResult(r, sizeof(r), "0.3.0", "board"));  // FW-072
  TEST_ASSERT_EQUAL_STRING("0.3.0;board", r);
}

void test_guard() {
  OtaHint h;
  TEST_ASSERT_TRUE(parse("0.3.0;/firmware/0.3.0.bin;0123456789abcdef0123456789abcdef", &h));
  OtaGuard g;
  TEST_ASSERT_FALSE(g.allowed(0, 59, h, "0.2.0"));        // uptime < 60 s
  TEST_ASSERT_TRUE(g.allowed(0, 60, h, "0.2.0"));
  TEST_ASSERT_FALSE(g.allowed(0, 100, h, "0.3.0"));       // equal
  TEST_ASSERT_FALSE(g.allowed(0, 100, h, "0.4.0"));       // older
  g.onFailure(1000, "0.3.0");
  TEST_ASSERT_FALSE(g.allowed(1000 + OTA_RETRY_HOLD_MS - 1, 100, h, "0.2.0"));
  TEST_ASSERT_TRUE(g.allowed(1000 + OTA_RETRY_HOLD_MS, 100, h, "0.2.0"));
  OtaHint h2;
  TEST_ASSERT_TRUE(parse("0.3.1;/firmware/0.3.1.bin;0123456789abcdef0123456789abcdef", &h2));
  TEST_ASSERT_TRUE(g.allowed(2000, 100, h2, "0.2.0"));    // other version not held
}

void test_test_build() {  // ADR-18: a test build (PATCH >= 900) accepts any other version
  TEST_ASSERT_TRUE(isTestVersion("3.0.900"));
  TEST_ASSERT_TRUE(isTestVersion("3.1.901"));
  TEST_ASSERT_FALSE(isTestVersion("3.0.899"));
  TEST_ASSERT_FALSE(isTestVersion("bad"));
  OtaHint rel;
  TEST_ASSERT_TRUE(parse("3.0.0;/firmware/3.0.0.bin;0123456789abcdef0123456789abcdef", &rel));
  OtaGuard g;
  TEST_ASSERT_TRUE(g.allowed(0, 100, rel, "3.0.900"));   // back from the test build to the release
  TEST_ASSERT_FALSE(g.allowed(0, 100, rel, "3.0.0"));    // equal
  TEST_ASSERT_FALSE(g.allowed(0, 100, rel, "3.0.5"));    // normal build: still no downgrade
  OtaHint same;
  TEST_ASSERT_TRUE(parse("3.0.900;/firmware/3.0.900.bin;0123456789abcdef0123456789abcdef", &same));
  TEST_ASSERT_FALSE(g.allowed(0, 100, same, "3.0.900"));  // same test build: nothing to do
}

void test_boot_failed() {
  TEST_ASSERT_FALSE(otaBootFailed("", "0.3.0"));
  TEST_ASSERT_FALSE(otaBootFailed(nullptr, "0.3.0"));
  TEST_ASSERT_FALSE(otaBootFailed("0.3.1", "0.3.1"));  // update installed
  TEST_ASSERT_TRUE(otaBootFailed("0.3.1", "0.3.0"));   // old image booted again
}

void test_heap_action() {
  TEST_ASSERT_EQUAL(OtaHeapAction::Proceed, otaHeapAction(16384, 8192, false));
  TEST_ASSERT_EQUAL(OtaHeapAction::Proceed, otaHeapAction(30000, 20000, true));
  TEST_ASSERT_EQUAL(OtaHeapAction::Reboot, otaHeapAction(16383, 9000, false));
  TEST_ASSERT_EQUAL(OtaHeapAction::Reboot, otaHeapAction(20000, 8191, false));
  TEST_ASSERT_EQUAL(OtaHeapAction::Refuse, otaHeapAction(16383, 9000, true));
  TEST_ASSERT_EQUAL(OtaHeapAction::Refuse, otaHeapAction(20000, 8191, true));
}

void test_hold_indefinitely() {
  OtaHint h;
  TEST_ASSERT_TRUE(parse("0.3.1;/firmware/0.3.1.bin;0123456789abcdef0123456789abcdef", &h));
  OtaGuard g;
  g.holdIndefinitely("0.3.1");
  TEST_ASSERT_FALSE(g.allowed(0, 100, h, "0.3.0"));
  TEST_ASSERT_FALSE(g.allowed(10 * OTA_RETRY_HOLD_MS, 100, h, "0.3.0"));  // no time limit
  OtaHint h2;
  TEST_ASSERT_TRUE(parse("0.3.2;/firmware/0.3.2.bin;0123456789abcdef0123456789abcdef", &h2));
  TEST_ASSERT_TRUE(g.allowed(0, 100, h2, "0.3.0"));
}

// FW-074, ADR-23: the guard takes the uptime across sleeps (WakeClock), so a normal timer wake passes it and a real boot
// does not (the OTA is then offered at the next wake).
void test_guard_uptime_across_sleeps() {
  OtaHint h;
  TEST_ASSERT_TRUE(parse("0.3.0;/firmware/0.3.0.bin;0123456789abcdef0123456789abcdef", &h));
  OtaGuard g;
  WakeClock c;
  c.startWake(1500, 290, 300);  // woke 1.5 s ago from a 300 s sleep after 290 s of uptime: 590 s
  TEST_ASSERT_EQUAL_UINT32(590, c.uptimeS(1500));
  TEST_ASSERT_TRUE(g.allowed(1500, c.uptimeS(2500), h, "0.2.0"));    // millis() alone (2.5 s) would refuse
  TEST_ASSERT_FALSE(g.allowed(2500, 2, h, "0.2.0"));                  // the same millis() without the clock
  WakeClock real;
  real.startCold(0);                                                  // real boot, 10 s ago
  TEST_ASSERT_FALSE(g.allowed(10000, real.uptimeS(10000), h, "0.2.0"));
  TEST_ASSERT_TRUE(g.allowed(60000, real.uptimeS(60000), h, "0.2.0"));  // 60 s: allowed
  real.startWake(500, real.uptimeS(60000), 300);                      // slept 5 min: now well past the guard
  TEST_ASSERT_TRUE(g.allowed(500, real.uptimeS(500), h, "0.2.0"));
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_hint_valid);
  RUN_TEST(test_hint_invalid);
  RUN_TEST(test_compare);
  RUN_TEST(test_url);
  RUN_TEST(test_hint_d1_rejects_board_paths);
  RUN_TEST(test_hint_s3);
  RUN_TEST(test_image_matches);
  RUN_TEST(test_result_format);
  RUN_TEST(test_guard);
  RUN_TEST(test_test_build);
  RUN_TEST(test_boot_failed);
  RUN_TEST(test_hold_indefinitely);
  RUN_TEST(test_heap_action);
  RUN_TEST(test_guard_uptime_across_sleeps);
  return UNITY_END();
}

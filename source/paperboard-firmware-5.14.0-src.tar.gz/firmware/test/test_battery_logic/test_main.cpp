#include <string.h>
#include <unity.h>

#include "battery_logic.h"
#include "sleep_logic.h"

using namespace core;

void setUp() {}
void tearDown() {}

void test_parse_mv() {
  uint16_t v = 0;
  TEST_ASSERT_TRUE(parseMv("2800", &v));
  TEST_ASSERT_EQUAL_UINT16(2800, v);
  TEST_ASSERT_TRUE(parseMv("4400", &v));
  TEST_ASSERT_EQUAL_UINT16(4400, v);
  TEST_ASSERT_TRUE(parseMv("3874", &v));
  TEST_ASSERT_FALSE(parseMv("2799", &v));
  TEST_ASSERT_FALSE(parseMv("4401", &v));
  TEST_ASSERT_FALSE(parseMv("387", &v));
  TEST_ASSERT_FALSE(parseMv("38740", &v));
  TEST_ASSERT_FALSE(parseMv("38a4", &v));
  TEST_ASSERT_FALSE(parseMv("-387", &v));
  TEST_ASSERT_FALSE(parseMv(" 387", &v));
  TEST_ASSERT_FALSE(parseMv("", &v));
  TEST_ASSERT_FALSE(parseMv(nullptr, &v));
}

void test_format_mv() {
  char b[8];
  TEST_ASSERT_TRUE(formatMv(b, sizeof b, 3874));
  TEST_ASSERT_EQUAL_STRING("3874", b);
  TEST_ASSERT_TRUE(formatMv(b, sizeof b, 2800));
  TEST_ASSERT_EQUAL_STRING("2800", b);
  TEST_ASSERT_TRUE(formatMv(b, sizeof b, 4400));
  TEST_ASSERT_EQUAL_STRING("4400", b);
  strcpy(b, "x");
  TEST_ASSERT_FALSE(formatMv(b, sizeof b, 2799));
  TEST_ASSERT_FALSE(formatMv(b, sizeof b, 4401));
  TEST_ASSERT_FALSE(formatMv(b, 4, 3874));
  TEST_ASSERT_EQUAL_STRING("x", b);
}

void test_battery_mode() {
  TEST_ASSERT_TRUE(parseBatteryMode("1"));
  TEST_ASSERT_FALSE(parseBatteryMode("0"));
  TEST_ASSERT_FALSE(parseBatteryMode("11"));
  TEST_ASSERT_FALSE(parseBatteryMode("1 "));
  TEST_ASSERT_FALSE(parseBatteryMode("true"));
  TEST_ASSERT_FALSE(parseBatteryMode(""));
  TEST_ASSERT_FALSE(parseBatteryMode(nullptr));
}

void test_critical_enter() {
  CriticalPolicy p;
  TEST_ASSERT_FALSE(p.feed(3490));
  TEST_ASSERT_FALSE(p.feed(3490));
  TEST_ASSERT_TRUE(p.feed(3490));
}

void test_critical_boundary_and_reset() {
  CriticalPolicy p;
  TEST_ASSERT_FALSE(p.feed(BATTERY_CRITICAL_MV - 1));
  TEST_ASSERT_FALSE(p.feed(BATTERY_CRITICAL_MV));  // not below: counter reset
  TEST_ASSERT_FALSE(p.feed(BATTERY_CRITICAL_MV - 1));
  TEST_ASSERT_FALSE(p.feed(BATTERY_CRITICAL_MV - 1));
  TEST_ASSERT_FALSE(p.feed(1200));  // implausible: resets
  TEST_ASSERT_FALSE(p.feed(BATTERY_CRITICAL_MV - 1));
  TEST_ASSERT_FALSE(p.feed(BATTERY_CRITICAL_MV - 1));
  TEST_ASSERT_TRUE(p.feed(BATTERY_CRITICAL_MV - 1));
}

void test_critical_recover_hysteresis() {
  CriticalPolicy p;
  for (int i = 0; i < 3; i++) p.feed(3400);
  TEST_ASSERT_TRUE(p.critical);
  TEST_ASSERT_TRUE(p.feed(3650 - 1));  // below recover: stays
  TEST_ASSERT_TRUE(p.feed(3700));
  TEST_ASSERT_TRUE(p.feed(3700));
  TEST_ASSERT_TRUE(p.feed(3600));      // interrupts the run
  TEST_ASSERT_TRUE(p.feed(3700));
  TEST_ASSERT_TRUE(p.feed(3700));
  TEST_ASSERT_TRUE(p.feed(5000));      // implausible: resets, state kept
  TEST_ASSERT_TRUE(p.feed(3700));
  TEST_ASSERT_TRUE(p.feed(3700));
  TEST_ASSERT_FALSE(p.feed(3700));
  TEST_ASSERT_FALSE(p.feed(3550));     // between 3.50 and 3.65 V after recovery: counts as normal
}

void test_fail_backoff() {
  TEST_ASSERT_EQUAL_UINT32(300, FailBackoff::seconds(0));
  TEST_ASSERT_EQUAL_UINT32(600, FailBackoff::seconds(1));
  TEST_ASSERT_EQUAL_UINT32(1200, FailBackoff::seconds(2));
  TEST_ASSERT_EQUAL_UINT32(3600, FailBackoff::seconds(3));
  TEST_ASSERT_EQUAL_UINT32(3600, FailBackoff::seconds(100));
}

void test_record_roundtrip() {
  BatteryRecord r, o;
  r.policy.lowCount = 2;
  r.policy.highCount = 1;
  r.policy.critical = true;
  r.failStreak = 3;
  uint8_t raw[BATTERY_RECORD_BYTES];
  packBatteryRecord(r, raw);
  TEST_ASSERT_TRUE(unpackBatteryRecord(raw, &o));
  TEST_ASSERT_EQUAL_UINT8(2, o.policy.lowCount);
  TEST_ASSERT_EQUAL_UINT8(1, o.policy.highCount);
  TEST_ASSERT_TRUE(o.policy.critical);
  TEST_ASSERT_EQUAL_UINT8(3, o.failStreak);
  raw[4] ^= 1;
  TEST_ASSERT_FALSE(unpackBatteryRecord(raw, &o));
  TEST_ASSERT_FALSE(o.policy.critical);
  memset(raw, 0, sizeof raw);
  TEST_ASSERT_FALSE(unpackBatteryRecord(raw, &o));
  memset(raw, 0xFF, sizeof raw);
  TEST_ASSERT_FALSE(unpackBatteryRecord(raw, &o));
}

static SleepInputs failed() {
  SleepInputs i;
  i.paired = true;
  i.lastPollOk = false;
  i.pollFailed = true;
  i.wake = WakeKind::Timer;
  i.awakeMs = 120000;
  i.onBattery = true;
  return i;
}

void test_sleep_failed_poll_on_battery() {
  SleepInputs i = failed();
  SleepDecision d = SleepPolicy::decide(i);
  TEST_ASSERT_TRUE(d.sleep);
  TEST_ASSERT_EQUAL_UINT32(300, d.seconds);
  i.failStreak = 5;
  TEST_ASSERT_EQUAL_UINT32(3600, SleepPolicy::decide(i).seconds);
  i.awakeMs = 119999;
  TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);
  i = failed();
  i.buttonHeld = true;
  TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);
  i = failed();
  i.portalOpen = true;
  TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);
  i = failed();
  i.pollFailed = false;  // no poll finished yet
  TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);
}

void test_sleep_unchanged_without_battery() {  // ADR-23 regression
  SleepInputs i = failed();
  i.onBattery = false;
  TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);
  i = failed();
  i.lastPollOk = true;
  i.pollFailed = false;
  i.sleepS = 900;
  i.awakeMs = 4000;
  SleepDecision d = SleepPolicy::decide(i);
  TEST_ASSERT_TRUE(d.sleep);
  TEST_ASSERT_EQUAL_UINT32(896, d.seconds);
  i.onBattery = false;
  TEST_ASSERT_EQUAL_UINT32(896, SleepPolicy::decide(i).seconds);
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_parse_mv);
  RUN_TEST(test_format_mv);
  RUN_TEST(test_battery_mode);
  RUN_TEST(test_critical_enter);
  RUN_TEST(test_critical_boundary_and_reset);
  RUN_TEST(test_critical_recover_hysteresis);
  RUN_TEST(test_fail_backoff);
  RUN_TEST(test_record_roundtrip);
  RUN_TEST(test_sleep_failed_poll_on_battery);
  RUN_TEST(test_sleep_unchanged_without_battery);
  return UNITY_END();
}

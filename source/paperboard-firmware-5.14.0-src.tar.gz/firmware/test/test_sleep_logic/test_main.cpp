#include <string.h>
#include <unity.h>

#include "sleep_logic.h"

using namespace core;

void setUp() {}
void tearDown() {}

static SleepInputs ok() {
  SleepInputs i;
  i.paired = true;
  i.lastPollOk = true;
  i.sleepS = 900;
  i.wake = WakeKind::Timer;
  i.awakeMs = 4000;
  return i;
}

void test_parse() {
  uint32_t v = 0;
  TEST_ASSERT_TRUE(parseSleepSeconds("300", &v));
  TEST_ASSERT_EQUAL_UINT32(300, v);
  TEST_ASSERT_TRUE(parseSleepSeconds("60", &v));
  TEST_ASSERT_EQUAL_UINT32(60, v);
  TEST_ASSERT_TRUE(parseSleepSeconds("3600", &v));
  TEST_ASSERT_EQUAL_UINT32(3600, v);
  TEST_ASSERT_FALSE(parseSleepSeconds("59", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds("3601", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds("1e3", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds(" 300", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds("300x", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds("-300", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds("00300", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds("", &v));
  TEST_ASSERT_FALSE(parseSleepSeconds(nullptr, &v));
}

void test_decide_success() {
  SleepDecision d = SleepPolicy::decide(ok());
  TEST_ASSERT_TRUE(d.sleep);
  TEST_ASSERT_EQUAL_UINT32(896, d.seconds);   // 900 - 4 s awake
  SleepInputs i = ok();
  i.awakeMs = 4001;                           // rounded up
  TEST_ASSERT_EQUAL_UINT32(895, SleepPolicy::decide(i).seconds);
}

void test_decide_min_60() {
  SleepInputs i = ok();
  i.sleepS = 70;
  i.awakeMs = 30000;
  TEST_ASSERT_EQUAL_UINT32(60, SleepPolicy::decide(i).seconds);
  i.sleepS = 60;
  i.awakeMs = 90000;   // longer than the interval
  TEST_ASSERT_EQUAL_UINT32(60, SleepPolicy::decide(i).seconds);
}

void test_stay_awake_rules() {
  SleepInputs i = ok(); i.paired = false;       TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 1
  i = ok(); i.portalOpen = true;                TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 1
  i = ok(); i.lastPollOk = false;               TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 2
  i = ok(); i.sleepS = 0;                       TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 3
  i = ok(); i.sleepS = 3601;                    TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);
  i = ok(); i.buttonHeld = true;                TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 5
  i = ok(); i.eventsPending = true;             TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 5
  i = ok(); i.otaRunning = true;                TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 6
}

void test_window_after_non_timer_boot() {
  const WakeKind kinds[] = {WakeKind::Boot, WakeKind::Button};
  for (WakeKind w : kinds) {
    SleepInputs i = ok();
    i.wake = w;
    i.awakeMs = 59999;
    TEST_ASSERT_FALSE(SleepPolicy::decide(i).sleep);   // rule 4
    i.awakeMs = 60000;
    SleepDecision d = SleepPolicy::decide(i);
    TEST_ASSERT_TRUE(d.sleep);
    TEST_ASSERT_EQUAL_UINT32(840, d.seconds);
  }
  SleepInputs t = ok();   // timer wake: no window
  t.awakeMs = 1000;
  TEST_ASSERT_TRUE(SleepPolicy::decide(t).sleep);
}

void test_wake_names() {
  TEST_ASSERT_EQUAL_STRING("boot", wakeKindName(WakeKind::Boot));
  TEST_ASSERT_EQUAL_STRING("timer", wakeKindName(WakeKind::Timer));
  TEST_ASSERT_EQUAL_STRING("button", wakeKindName(WakeKind::Button));
}

static SleepRecord sample() {
  SleepRecord r;
  strcpy(r.etag, "\"9f2c4a7e11b0c3d5\"");
  const uint8_t b[6] = {0xA4, 0x2B, 0xB0, 0x01, 0x02, 0xFE};
  memcpy(r.bssid, b, 6);
  r.channel = 11;
  r.hasBssid = true;
  r.uptimeAtSleepS = 123456;
  r.plannedSleepS = 896;
  r.sinceRefreshS = 42;
  return r;
}

void test_record_round_trip() {
  uint8_t buf[SLEEP_RECORD_BYTES];
  packSleepRecord(sample(), buf);
  SleepRecord o;
  TEST_ASSERT_TRUE(unpackSleepRecord(buf, &o));
  const SleepRecord s = sample();
  TEST_ASSERT_EQUAL_STRING(s.etag, o.etag);
  TEST_ASSERT_EQUAL_MEMORY(s.bssid, o.bssid, 6);
  TEST_ASSERT_EQUAL_UINT8(11, o.channel);
  TEST_ASSERT_TRUE(o.hasBssid);
  TEST_ASSERT_EQUAL_UINT32(123456, o.uptimeAtSleepS);
  TEST_ASSERT_EQUAL_UINT32(896, o.plannedSleepS);
  TEST_ASSERT_EQUAL_UINT32(42, o.sinceRefreshS);
}

void test_record_defaults_round_trip() {
  uint8_t buf[SLEEP_RECORD_BYTES];
  packSleepRecord(SleepRecord(), buf);
  SleepRecord o;
  TEST_ASSERT_TRUE(unpackSleepRecord(buf, &o));
  TEST_ASSERT_EQUAL_STRING("", o.etag);
  TEST_ASSERT_FALSE(o.hasBssid);
  TEST_ASSERT_EQUAL_UINT32(REFRESH_AGE_NONE, o.sinceRefreshS);
}

void test_record_invalid_is_cold() {
  uint8_t buf[SLEEP_RECORD_BYTES];
  SleepRecord o = sample();
  memset(buf, 0xFF, sizeof buf);
  TEST_ASSERT_FALSE(unpackSleepRecord(buf, &o));
  TEST_ASSERT_EQUAL_STRING("", o.etag);   // reset to defaults
  TEST_ASSERT_FALSE(o.hasBssid);
  memset(buf, 0x00, sizeof buf);
  TEST_ASSERT_FALSE(unpackSleepRecord(buf, &o));
  packSleepRecord(sample(), buf);
  for (size_t i = 0; i < sizeof buf; i++) {   // a flipped bit anywhere is detected
    buf[i] ^= 0x10;
    TEST_ASSERT_FALSE(unpackSleepRecord(buf, &o));
    buf[i] ^= 0x10;
  }
  TEST_ASSERT_TRUE(unpackSleepRecord(buf, &o));
}

void test_clock_three_cycles() {
  WakeClock c;
  c.startCold(0);
  TEST_ASSERT_EQUAL_UINT32(5, c.uptimeS(5000));
  uint32_t atSleep = c.uptimeS(5400);   // 5 s
  c.startWake(100, atSleep, 900);       // wake 1: 900 s slept
  TEST_ASSERT_EQUAL_UINT32(905, c.uptimeS(100));
  atSleep = c.uptimeS(4600);
  TEST_ASSERT_EQUAL_UINT32(909, atSleep);   // 905 + 4.5 s floors to 909
  c.startWake(120, atSleep, 900);           // wake 2
  atSleep = c.uptimeS(120 + 3000);
  TEST_ASSERT_EQUAL_UINT32(909 + 900 + 3, atSleep);
  c.startWake(50, atSleep, 3600);           // wake 3
  TEST_ASSERT_EQUAL_UINT32(atSleep + 3600, c.uptimeS(50));
}

void test_clock_millis_wrap() {
  WakeClock c;
  c.startCold(0xFFFFFC18UL);   // 1000 ms before wrap
  TEST_ASSERT_EQUAL_UINT32(0, c.uptimeS(0xFFFFFFFFUL));
  TEST_ASSERT_EQUAL_UINT32(2, c.uptimeS(1000));   // 2000 ms in total
  // sub-second remainders are not lost over many calls (always-on, polls every 15.5 s)
  c.startCold(0);
  uint32_t t = 0;
  uint32_t u = 0;
  for (int k = 0; k < 100; k++) {
    t += 15500;
    u = c.uptimeS(t);
  }
  TEST_ASSERT_EQUAL_UINT32(1550, u);
}

void test_clock_saturates() {
  WakeClock c;
  c.startWake(0, 0xFFFFFFF0UL, 100);
  TEST_ASSERT_EQUAL_UINT32(0xFFFFFFFFUL, c.uptimeS(0));
}

void test_ota_guard_uptime_across_sleep() {
  // FW-074: a wake at 5 min uptime passes the 60 s guard, a real boot after 10 s does not.
  WakeClock c;
  c.startWake(0, 290, 900);
  TEST_ASSERT_TRUE(c.uptimeS(2000) >= 60);
  WakeClock b;
  b.startCold(0);
  TEST_ASSERT_TRUE(b.uptimeS(10000) < 60);
}

void test_refresh_floor_across_button_wake() {
  // FW-103: refresh, 20 s later asleep -> record; button wake after 20 s slept, floor 60 s.
  RefreshFloor f;
  f.onRefresh(1000);
  uint32_t age = refreshAgeS(f, 21000);
  TEST_ASSERT_EQUAL_UINT32(20, age);
  RefreshFloor g;
  restoreRefreshFloor(&g, 800, age, 20);   // slept 20 s -> 40 s old
  TEST_ASSERT_EQUAL_UINT32(20000, g.remainingMs(800, 60000));
  TEST_ASSERT_EQUAL_UINT32(0, g.remainingMs(800 + 20000, 60000));
  restoreRefreshFloor(&g, 500, age, 900);  // timer wake after 900 s: floor passed
  TEST_ASSERT_EQUAL_UINT32(0, g.remainingMs(500, 60000));
}

void test_refresh_floor_none_and_wrap() {
  RefreshFloor f;
  TEST_ASSERT_EQUAL_UINT32(REFRESH_AGE_NONE, refreshAgeS(f, 1234));
  RefreshFloor g;
  g.onRefresh(5);
  restoreRefreshFloor(&g, 100, REFRESH_AGE_NONE, 50);
  TEST_ASSERT_FALSE(g.valid);
  TEST_ASSERT_EQUAL_UINT32(0, g.remainingMs(100, 60000));
  restoreRefreshFloor(&g, 1000, 30, 0);   // lastMs wraps below 0, remaining stays correct
  TEST_ASSERT_EQUAL_UINT32(30000, g.remainingMs(1000, 60000));
  restoreRefreshFloor(&g, 1000, 0xFFFFFFF0UL, 0xFFFFFFF0UL);   // huge values are capped
  TEST_ASSERT_EQUAL_UINT32(0, g.remainingMs(1000, 60000));
  RefreshFloor h;
  h.onRefresh(0xFFFFFC18UL);   // refresh age across a millis() wrap
  TEST_ASSERT_EQUAL_UINT32(3, refreshAgeS(h, 2000));
}

void test_fast_connect_success() {
  FastConnect fc(true);
  TEST_ASSERT_EQUAL(ConnectAction::BeginFast, fc.step(false, 100));
  TEST_ASSERT_EQUAL(ConnectAction::Wait, fc.step(false, 1100));
  TEST_ASSERT_EQUAL(ConnectAction::Connected, fc.step(true, 1500));
  TEST_ASSERT_FALSE(fc.clearBssid());
  TEST_ASSERT_EQUAL(ConnectAction::Connected, fc.step(false, 9000));   // sticky
}

void test_fast_connect_fallback_clears_bssid() {
  FastConnect fc(true);
  TEST_ASSERT_EQUAL(ConnectAction::BeginFast, fc.step(false, 0xFFFFFF00UL));
  TEST_ASSERT_EQUAL(ConnectAction::Wait, fc.step(false, 2000));   // 2.3 s incl. wrap
  TEST_ASSERT_FALSE(fc.clearBssid());
  TEST_ASSERT_EQUAL(ConnectAction::FallbackNormal, fc.step(false, 2800));
  TEST_ASSERT_TRUE(fc.clearBssid());
  TEST_ASSERT_EQUAL(ConnectAction::Wait, fc.step(false, 20000));   // normal connect has its own timeout
  TEST_ASSERT_EQUAL(ConnectAction::Connected, fc.step(true, 21000));
}

void test_begin_path_needs_stored_ssid() {
  TEST_ASSERT_EQUAL(BeginPath::Stored, chooseBeginPath(""));       // S3 after a wake: WiFi.SSID() was empty (#84)
  TEST_ASSERT_EQUAL(BeginPath::Stored, chooseBeginPath(nullptr));
  TEST_ASSERT_EQUAL(BeginPath::Explicit, chooseBeginPath("home"));
}

void test_fast_connect_without_bssid() {
  FastConnect fc(false);
  TEST_ASSERT_EQUAL(ConnectAction::BeginNormal, fc.step(false, 0));
  TEST_ASSERT_EQUAL(ConnectAction::Wait, fc.step(false, 10000));
  TEST_ASSERT_FALSE(fc.clearBssid());
  TEST_ASSERT_EQUAL(ConnectAction::Connected, fc.step(true, 10500));
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_parse);
  RUN_TEST(test_decide_success);
  RUN_TEST(test_decide_min_60);
  RUN_TEST(test_stay_awake_rules);
  RUN_TEST(test_window_after_non_timer_boot);
  RUN_TEST(test_wake_names);
  RUN_TEST(test_record_round_trip);
  RUN_TEST(test_record_defaults_round_trip);
  RUN_TEST(test_record_invalid_is_cold);
  RUN_TEST(test_clock_three_cycles);
  RUN_TEST(test_clock_millis_wrap);
  RUN_TEST(test_clock_saturates);
  RUN_TEST(test_ota_guard_uptime_across_sleep);
  RUN_TEST(test_refresh_floor_across_button_wake);
  RUN_TEST(test_refresh_floor_none_and_wrap);
  RUN_TEST(test_fast_connect_success);
  RUN_TEST(test_fast_connect_fallback_clears_bssid);
  RUN_TEST(test_fast_connect_without_bssid);
  RUN_TEST(test_begin_path_needs_stored_ssid);
  return UNITY_END();
}

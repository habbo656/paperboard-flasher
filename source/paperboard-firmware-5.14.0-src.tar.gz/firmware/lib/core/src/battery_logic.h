#pragma once
// Platform-independent battery logic (#104, FW-112, FW-113, IF-006, ADR-24). Unit-tested in test/test_battery_logic.
// No Arduino dependencies.

#include <stddef.h>
#include <stdint.h>

namespace core {

constexpr uint16_t BATTERY_MV_MIN = 2800;   // IF-006: valid reading range, also the only plausibility check
constexpr uint16_t BATTERY_MV_MAX = 4400;

// Critical level as measured with the uncalibrated ADC (FW-113): Li-Ion floor ~3.40 V plus ~100 mV for a typical
// +-3 % ADC/divider error. Test builds may lower/raise it with -DBATTERY_VCRIT_MV=...; never in a release.
#ifdef BATTERY_VCRIT_MV
constexpr uint16_t BATTERY_CRITICAL_MV = BATTERY_VCRIT_MV;
#else
constexpr uint16_t BATTERY_CRITICAL_MV = 3500;
#endif
constexpr uint16_t BATTERY_RECOVER_MV = BATTERY_CRITICAL_MV + 150;   // 3.65 V
constexpr uint8_t BATTERY_CONFIRM = 3;                             // readings in a row
constexpr uint32_t BATTERY_CRITICAL_SLEEP_S = 3600;                // critical wake: measure only
constexpr uint32_t BATTERY_FAIL_AWAKE_MS = 120UL * 1000;           // armed + failed poll: awake this long, then sleep

inline bool batteryValid(uint32_t mv) { return mv >= BATTERY_MV_MIN && mv <= BATTERY_MV_MAX; }

// X-Battery value: exactly four digits, 2800..4400.
bool parseMv(const char* v, uint16_t* out);
// Writes the four-digit value; false (buffer untouched) if out of range or the buffer is too small (< 5).
bool formatMv(char* buf, size_t size, uint16_t mv);

// X-Battery-Mode response header: only the literal "1" arms; null/anything else = not armed.
bool parseBatteryMode(const char* v);

// Critical shutdown (FW-113): 3 valid readings in a row below VCRIT enter it, 3 in a row >= VCRIT + 150 mV leave it.
// An out-of-range reading (implausible) resets both counters and never changes the state.
struct CriticalPolicy {
  uint8_t lowCount;
  uint8_t highCount;
  bool critical;
  CriticalPolicy() { reset(); }
  void reset() { lowCount = highCount = 0; critical = false; }
  // Returns the (new) critical state.
  bool feed(uint32_t mv);
};

// Backoff after failed polls on battery (ADR-24): 300, 600, 1200, then 3600 s. `streak` = failed sleeps so far.
struct FailBackoff {
  static uint32_t seconds(uint8_t streak);
};

// RTC record (12 B): counters survive deep sleep (S3 RTC memory, D1 stays unused). Layout: magic version
// lowCount highCount flags failStreak pad[3] crc32(4) over the first 8 bytes.
constexpr size_t BATTERY_RECORD_BYTES = 12;
struct BatteryRecord {
  CriticalPolicy policy;
  uint8_t failStreak;
  BatteryRecord() : failStreak(0) {}
};
void packBatteryRecord(const BatteryRecord& r, uint8_t out[BATTERY_RECORD_BYTES]);
// false (and `out` reset) on a wrong CRC/magic or counters out of range: power-on garbage is a cold start.
bool unpackBatteryRecord(const uint8_t in[BATTERY_RECORD_BYTES], BatteryRecord* out);

}  // namespace core

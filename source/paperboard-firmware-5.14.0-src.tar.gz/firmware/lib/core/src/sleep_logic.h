#pragma once
// Platform-independent deep-sleep logic (FW-037, FW-038, FW-107, FW-074, FW-103, ADR-23, IF-003 X-Sleep-S).
// Unit-tested in test/test_sleep_logic. No Arduino dependencies.

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "battery_logic.h"
#include "poll_logic.h"

namespace core {

constexpr uint32_t SLEEP_MIN_S = 60;     // device accepts X-Sleep-S 60..3600 and never sleeps shorter
constexpr uint32_t SLEEP_MAX_S = 3600;
constexpr uint32_t SLEEP_WINDOW_MS = 60UL * 1000;   // awake window after a non-timer boot (FW-107)
constexpr uint32_t FAST_CONNECT_MS = 3000;          // FW-037: fast connect gives up after 3 s

// X-Sleep-S: digits only (1..4), value 60..3600. Anything else (null, empty, sign, space, "1e3", "300x") -> false.
bool parseSleepSeconds(const char* v, uint32_t* out);

// How this awake period started (X-Wake: boot | timer | button).
enum class WakeKind : uint8_t { Boot, Timer, Button };
const char* wakeKindName(WakeKind w);

struct SleepInputs {
  bool paired = false;
  bool portalOpen = false;      // setup/loss portal
  bool lastPollOk = false;      // frame shown or 304 in this awake period
  uint32_t sleepS = 0;          // parsed X-Sleep-S of the last successful answer, 0 = none/invalid
  WakeKind wake = WakeKind::Boot;
  uint32_t awakeMs = 0;         // time since this awake period started (millis() since reset)
  bool buttonHeld = false;
  bool eventsPending = false;   // #81 event queue not empty
  bool otaRunning = false;
  // FW-113, ADR-24: battery mode armed by the app AND a valid reading. Without it the decision is exactly ADR-23.
  bool onBattery = false;
  bool pollFailed = false;      // a poll finished in this awake period and failed
  uint8_t failStreak = 0;       // failed sleeps in a row so far (backoff step)
};

struct SleepDecision {
  bool sleep = false;
  uint32_t seconds = 0;         // valid if sleep
};

struct SleepPolicy {
  // Stay awake unless all of: paired, no portal, last poll ok, valid X-Sleep-S, (timer wake or >= 60 s since a
  // non-timer boot), no button/event, no OTA. Sleep time = X-Sleep-S minus time awake (rounded up), min 60 s.
  static SleepDecision decide(const SleepInputs& in);
};

// RTC record (48 B). Stored by the board layer in RTC memory (D1: user RTC blocks, S3: RTC_NOINIT).
constexpr size_t SLEEP_RECORD_BYTES = 48;
constexpr size_t SLEEP_ETAG_BYTES = 24;
constexpr uint32_t REFRESH_AGE_NONE = 0xFFFFFFFFUL;   // no panel refresh yet in sinceRefreshS

struct SleepRecord {
  char etag[SLEEP_ETAG_BYTES];          // NUL-terminated, empty = none
  uint8_t bssid[6];
  uint8_t channel;
  bool hasBssid;                        // flags bit 0
  uint32_t uptimeAtSleepS;              // WakeClock value when going to sleep
  uint32_t plannedSleepS;
  uint32_t sinceRefreshS;               // seconds since the last panel refresh at sleep, REFRESH_AGE_NONE = none
  // memset instead of member initialisers: those compile to a 44 B constant image in RAM on the ESP8266 (D1 budget).
  SleepRecord() { reset(); }
  void reset() {
    memset(this, 0, sizeof(*this));
    sinceRefreshS = REFRESH_AGE_NONE;
  }
};

// Little-endian layout: etag[24] bssid[6] channel flags uptime[4] planned[4] sinceRefresh[4] crc32[4] (CRC over the
// first 44 bytes, same crc32Update as the frame CRC).
void packSleepRecord(const SleepRecord& r, uint8_t out[SLEEP_RECORD_BYTES]);
// false (and `out` reset to defaults) when the CRC is wrong, an unused flag bit is set or the ETag is not terminated:
// garbage, power-on RTC contents, all-0x00 and all-0xFF are a cold start.
bool unpackSleepRecord(const uint8_t in[SLEEP_RECORD_BYTES], SleepRecord* out);

// Uptime since the last real reset across deep sleeps (X-Uptime-S, FW-074). Wrap-safe against millis() overflow as
// long as uptimeS()/tick() is called at least once every 49 days.
class WakeClock {
 public:
  void startCold(uint32_t nowMs);                                              // real reset: 0
  void startWake(uint32_t nowMs, uint32_t uptimeAtSleepS, uint32_t sleptS);    // timer/button wake
  uint32_t uptimeS(uint32_t nowMs);

 private:
  uint32_t baseS_ = 0;
  uint32_t remMs_ = 0;
  uint32_t lastMs_ = 0;
};

// Refresh floor across a wake (FW-103): seconds since the last refresh to store when going to sleep.
uint32_t refreshAgeS(const RefreshFloor& f, uint32_t nowMs);
// ... and restoring it right after a wake (nowMs = millis() at that point): age at sleep + slept time.
void restoreRefreshFloor(RefreshFloor* f, uint32_t nowMs, uint32_t sinceRefreshAtSleepS, uint32_t sleptS);

// Which begin() to use after a wake (FW-037): explicit SSID/PSK/BSSID only when the stored station config yields an SSID;
// otherwise the plain stored-credentials begin(), which also works on a cold boot (never leaves the device offline).
enum class BeginPath : uint8_t { Explicit, Stored };
BeginPath chooseBeginPath(const char* storedSsid);

// Fast reconnect (FW-037): BSSID/channel from the record for 3 s, then the normal connect.
enum class ConnectAction : uint8_t { BeginFast, BeginNormal, Wait, Connected, FallbackNormal };
class FastConnect {
 public:
  explicit FastConnect(bool haveBssid) : have_(haveBssid) {}
  ConnectAction step(bool connected, uint32_t nowMs);
  // true after a failed fast connect: the caller clears BSSID/channel in the record.
  bool clearBssid() const { return cleared_; }

 private:
  enum class State : uint8_t { Init, Fast, Normal, Done };
  bool have_;
  bool cleared_ = false;
  State state_ = State::Init;
  uint32_t startMs_ = 0;
};

}  // namespace core

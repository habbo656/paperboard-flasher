#include "sleep_logic.h"

#include <string.h>

#include "crc32.h"

namespace core {

BeginPath chooseBeginPath(const char* storedSsid) {
  return (storedSsid && *storedSsid) ? BeginPath::Explicit : BeginPath::Stored;
}

bool parseSleepSeconds(const char* v, uint32_t* out) {
  if (!v || !*v) return false;
  uint32_t n = 0;
  size_t len = 0;
  for (; v[len]; len++) {
    if (v[len] < '0' || v[len] > '9' || len >= 4) return false;
    n = n * 10 + static_cast<uint32_t>(v[len] - '0');
  }
  if (n < SLEEP_MIN_S || n > SLEEP_MAX_S) return false;
  if (out) *out = n;
  return true;
}

const char* wakeKindName(WakeKind w) {
  switch (w) {
    case WakeKind::Timer: return "timer";
    case WakeKind::Button: return "button";
    default: return "boot";
  }
}

SleepDecision SleepPolicy::decide(const SleepInputs& in) {
  SleepDecision d;
  if (!in.paired || in.portalOpen) return d;
  if (!in.lastPollOk) {
    // FW-113: on battery a failed poll must not keep the device awake forever: 120 s awake, then a backoff sleep.
    if (in.onBattery && in.pollFailed && !in.buttonHeld && !in.eventsPending && !in.otaRunning &&
        in.awakeMs >= BATTERY_FAIL_AWAKE_MS) {
      d.sleep = true;
      d.seconds = FailBackoff::seconds(in.failStreak);
    }
    return d;
  }
  if (in.sleepS < SLEEP_MIN_S || in.sleepS > SLEEP_MAX_S) return d;
  if (in.wake != WakeKind::Timer && in.awakeMs < SLEEP_WINDOW_MS) return d;
  if (in.buttonHeld || in.eventsPending || in.otaRunning) return d;
  const uint32_t awakeS = in.awakeMs / 1000 + (in.awakeMs % 1000 ? 1 : 0);
  uint32_t s = in.sleepS > awakeS ? in.sleepS - awakeS : 0;
  if (s < SLEEP_MIN_S) s = SLEEP_MIN_S;
  d.sleep = true;
  d.seconds = s;
  return d;
}

static void put32(uint8_t* p, uint32_t v) {
  p[0] = static_cast<uint8_t>(v);
  p[1] = static_cast<uint8_t>(v >> 8);
  p[2] = static_cast<uint8_t>(v >> 16);
  p[3] = static_cast<uint8_t>(v >> 24);
}
static uint32_t get32(const uint8_t* p) {
  return static_cast<uint32_t>(p[0]) | static_cast<uint32_t>(p[1]) << 8 | static_cast<uint32_t>(p[2]) << 16 |
         static_cast<uint32_t>(p[3]) << 24;
}

constexpr size_t OFF_BSSID = SLEEP_ETAG_BYTES;       // 24
constexpr size_t OFF_CHANNEL = OFF_BSSID + 6;        // 30
constexpr size_t OFF_FLAGS = OFF_CHANNEL + 1;        // 31
constexpr size_t OFF_UPTIME = OFF_FLAGS + 1;         // 32
constexpr size_t OFF_PLANNED = OFF_UPTIME + 4;       // 36
constexpr size_t OFF_SINCE = OFF_PLANNED + 4;        // 40
constexpr size_t OFF_CRC = OFF_SINCE + 4;            // 44
static_assert(OFF_CRC + 4 == SLEEP_RECORD_BYTES, "record layout");
constexpr uint8_t FLAG_BSSID = 0x01;

void packSleepRecord(const SleepRecord& r, uint8_t out[SLEEP_RECORD_BYTES]) {
  memset(out, 0, SLEEP_RECORD_BYTES);
  memcpy(out, r.etag, SLEEP_ETAG_BYTES);
  out[SLEEP_ETAG_BYTES - 1] = 0;
  memcpy(out + OFF_BSSID, r.bssid, 6);
  out[OFF_CHANNEL] = r.channel;
  out[OFF_FLAGS] = r.hasBssid ? FLAG_BSSID : 0;
  put32(out + OFF_UPTIME, r.uptimeAtSleepS);
  put32(out + OFF_PLANNED, r.plannedSleepS);
  put32(out + OFF_SINCE, r.sinceRefreshS);
  put32(out + OFF_CRC, crc32Update(0, out, OFF_CRC));
}

bool unpackSleepRecord(const uint8_t in[SLEEP_RECORD_BYTES], SleepRecord* out) {
  SleepRecord fresh;
  bool ok = crc32Update(0, in, OFF_CRC) == get32(in + OFF_CRC) && (in[OFF_FLAGS] & ~FLAG_BSSID) == 0 &&
            in[SLEEP_ETAG_BYTES - 1] == 0;
  if (ok) {
    memcpy(fresh.etag, in, SLEEP_ETAG_BYTES);
    memcpy(fresh.bssid, in + OFF_BSSID, 6);
    fresh.channel = in[OFF_CHANNEL];
    fresh.hasBssid = (in[OFF_FLAGS] & FLAG_BSSID) != 0;
    fresh.uptimeAtSleepS = get32(in + OFF_UPTIME);
    fresh.plannedSleepS = get32(in + OFF_PLANNED);
    fresh.sinceRefreshS = get32(in + OFF_SINCE);
  }
  if (out) *out = fresh;
  return ok;
}

void WakeClock::startCold(uint32_t nowMs) {
  baseS_ = 0;
  remMs_ = 0;
  lastMs_ = nowMs;
}

void WakeClock::startWake(uint32_t nowMs, uint32_t uptimeAtSleepS, uint32_t sleptS) {
  baseS_ = uptimeAtSleepS + sleptS;
  if (baseS_ < uptimeAtSleepS) baseS_ = 0xFFFFFFFFUL;   // saturate
  remMs_ = 0;
  lastMs_ = nowMs;
}

uint32_t WakeClock::uptimeS(uint32_t nowMs) {
  remMs_ += nowMs - lastMs_;   // unsigned: wrap-safe
  lastMs_ = nowMs;
  const uint32_t add = remMs_ / 1000;
  remMs_ %= 1000;
  if (add > 0xFFFFFFFFUL - baseS_) baseS_ = 0xFFFFFFFFUL;
  else baseS_ += add;
  return baseS_;
}

uint32_t refreshAgeS(const RefreshFloor& f, uint32_t nowMs) {
  if (!f.valid) return REFRESH_AGE_NONE;
  const uint32_t s = (nowMs - f.lastMs) / 1000;
  return s == REFRESH_AGE_NONE ? REFRESH_AGE_NONE - 1 : s;
}

void restoreRefreshFloor(RefreshFloor* f, uint32_t nowMs, uint32_t sinceRefreshAtSleepS, uint32_t sleptS) {
  if (sinceRefreshAtSleepS == REFRESH_AGE_NONE) {
    *f = RefreshFloor();
    return;
  }
  // Cap at one day: far beyond any floor, and it keeps the millisecond value inside 32 bits.
  constexpr uint32_t CAP_S = 86400;
  uint32_t age = sinceRefreshAtSleepS > CAP_S ? CAP_S : sinceRefreshAtSleepS;
  age += sleptS > CAP_S ? CAP_S : sleptS;
  if (age > CAP_S) age = CAP_S;
  f->lastMs = nowMs - age * 1000;   // wrap-safe: remainingMs() uses (now - lastMs)
  f->valid = true;
}

ConnectAction FastConnect::step(bool connected, uint32_t nowMs) {
  if (state_ == State::Done) return ConnectAction::Connected;
  if (state_ == State::Init) {
    if (have_) {
      state_ = State::Fast;
      startMs_ = nowMs;
      return ConnectAction::BeginFast;
    }
    state_ = State::Normal;
    return ConnectAction::BeginNormal;
  }
  if (connected) {
    state_ = State::Done;
    return ConnectAction::Connected;
  }
  if (state_ == State::Fast && nowMs - startMs_ >= FAST_CONNECT_MS) {
    state_ = State::Normal;
    cleared_ = true;
    return ConnectAction::FallbackNormal;
  }
  return ConnectAction::Wait;
}

}  // namespace core

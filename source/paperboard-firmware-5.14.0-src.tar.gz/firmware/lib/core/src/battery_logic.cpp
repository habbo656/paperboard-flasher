#include "battery_logic.h"

#include <string.h>

#include "crc32.h"

namespace core {

bool parseMv(const char* v, uint16_t* out) {
  if (!v) return false;
  uint32_t n = 0;
  for (size_t i = 0; i < 4; i++) {
    if (v[i] < '0' || v[i] > '9') return false;
    n = n * 10 + static_cast<uint32_t>(v[i] - '0');
  }
  if (v[4] != 0 || !batteryValid(n)) return false;
  if (out) *out = static_cast<uint16_t>(n);
  return true;
}

bool formatMv(char* buf, size_t size, uint16_t mv) {
  if (!buf || size < 5 || !batteryValid(mv)) return false;
  buf[0] = static_cast<char>('0' + mv / 1000);
  buf[1] = static_cast<char>('0' + mv / 100 % 10);
  buf[2] = static_cast<char>('0' + mv / 10 % 10);
  buf[3] = static_cast<char>('0' + mv % 10);
  buf[4] = 0;
  return true;
}

bool parseBatteryMode(const char* v) { return v && v[0] == '1' && v[1] == 0; }

bool CriticalPolicy::feed(uint32_t mv) {
  if (!batteryValid(mv)) {
    lowCount = highCount = 0;
    return critical;
  }
  if (!critical) {
    highCount = 0;
    if (mv < BATTERY_CRITICAL_MV) {
      if (++lowCount >= BATTERY_CONFIRM) {
        critical = true;
        lowCount = 0;
      }
    } else {
      lowCount = 0;
    }
  } else {
    lowCount = 0;
    if (mv >= BATTERY_RECOVER_MV) {
      if (++highCount >= BATTERY_CONFIRM) {
        critical = false;
        highCount = 0;
      }
    } else {
      highCount = 0;
    }
  }
  return critical;
}

uint32_t FailBackoff::seconds(uint8_t streak) {
  static const uint16_t steps[] = {300, 600, 1200, 3600};
  return steps[streak < 3 ? streak : 3];
}

static constexpr uint8_t MAGIC = 0xB7;

void packBatteryRecord(const BatteryRecord& r, uint8_t out[BATTERY_RECORD_BYTES]) {
  memset(out, 0, BATTERY_RECORD_BYTES);
  out[0] = MAGIC;
  out[1] = r.policy.lowCount;
  out[2] = r.policy.highCount;
  out[3] = r.policy.critical ? 1 : 0;
  out[4] = r.failStreak;
  const uint32_t crc = crc32Update(0, out, 8);
  for (int i = 0; i < 4; i++) out[8 + i] = static_cast<uint8_t>(crc >> (8 * i));
}

bool unpackBatteryRecord(const uint8_t in[BATTERY_RECORD_BYTES], BatteryRecord* out) {
  *out = BatteryRecord();
  const uint32_t crc = crc32Update(0, in, 8);
  uint32_t stored = 0;
  for (int i = 0; i < 4; i++) stored |= static_cast<uint32_t>(in[8 + i]) << (8 * i);
  if (in[0] != MAGIC || crc != stored || in[1] >= BATTERY_CONFIRM || in[2] >= BATTERY_CONFIRM || in[3] > 1 ||
      in[4] > 100) {
    return false;
  }
  out->policy.lowCount = in[1];
  out->policy.highCount = in[2];
  out->policy.critical = in[3] == 1;
  out->failStreak = in[4];
  return true;
}

}  // namespace core

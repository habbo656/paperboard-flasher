#include "connectivity.h"

#include <WiFiManager.h>

#include "board.h"
#include "board_net.h"
#include "display.h"
#include "pairing.h"
#include "power.h"
#include "poller.h"
#include "setup_logic.h"

namespace connectivity {

static WiFiManager wm;
static core::WifiLossPolicy lossPolicy;
static char ap[24];
static char password[9];
static bool initialSetup = false;  // no Wi-Fi stored: portal stays open until configured
static bool lossScreenShown = false;
static core::FastConnect fastConnect(false);  // FW-037: fast reconnect after a deep-sleep wake, see begin()/loop()
static bool fastActive = false;
#ifdef PB_DEBUG
static uint32_t dropUntil = 0;  // debugDropWifi()
#endif

// WiFiManager shuts the portal down itself after a successful save; stopping it again dereferences the
// already freed web server (crash in handleClient) – so only stop a portal that is still active.
static void stopPortal() {
  if (wm.getConfigPortalActive()) wm.stopConfigPortal();
}

static void startPortal(bool wifiLost) {
  core::makePassword(password, 8, board::hwRandom);  // new password per setup session (FW-005)
  char qr[96];
  core::wifiQrPayload(qr, sizeof(qr), ap, password);
  Serial.printf_P(PSTR("[wifi] setup portal %s, password %s\n"), ap, password);
  poller::invalidateFrame();  // the setup screen replaces the frame
  display::showSetup(ap, password, qr, wifiLost);
  wm.startConfigPortal(ap, password);  // non-blocking: returns immediately
}

static void showLossScreen() {
  static char ssidLine[48];
  snprintf_P(ssidLine, sizeof(ssidLine), PSTR("Network: %s"), WiFi.SSID().c_str());
  char resetLine[40];
  snprintf_P(resetLine, sizeof(resetLine), PSTR("%s (factory reset)."), board::RESET_HINT);
  const char* lines[] = {ssidLine, PSTR("The display keeps trying to connect."), nullptr,
                         PSTR("Setup Wi-Fi opens again in 30 min."), PSTR("To change Wi-Fi now:"), resetLine};
  poller::invalidateFrame();
  display::showMessage(PSTR("Wi-Fi not available"), lines, 6);
  lossScreenShown = true;
}

static void showConnected() {
  static char l1[48], l2[40];
  snprintf_P(l1, sizeof(l1), PSTR("Wi-Fi: %s"), WiFi.SSID().c_str());
  snprintf_P(l2, sizeof(l2), PSTR("IP: %s"), WiFi.localIP().toString().c_str());
  const char* lines[] = {l1, l2, nullptr, PSTR("Next: add Paperboard in the Homey app.")};
  poller::invalidateFrame();
  display::showMessage(PSTR("Connected"), lines, 4);  // FW-006
}

// Factory reset (FW-008 double reset, FW-102 USER long press): erases Wi-Fi credentials and Homey pairing.
static void factoryReset() {
  const char* lines[] = {PSTR("Wi-Fi settings have been erased."), PSTR("Starting setup...")};
  display::showMessage(PSTR("Factory reset"), lines, 2);
  wm.resetSettings();  // erases the stored Wi-Fi credentials
  pairing::clear();     // and the Homey pairing
}

void begin() {
  // FW-037: after a deep-sleep wake with a known access point, connect with BSSID and channel (1.2 s instead of 5.9 s
  // on the D1 mini, S1). board::wifiFastBegin() switches persistence off: no flash write per wake.
  fastActive = board::DEEP_SLEEP && !power::realReset() && power::hasBssid();
  if (fastActive) fastConnect = core::FastConnect(true);
  core::apName(ap, sizeof(ap), board::chipId());
  wm.setDebugOutput(true);
  wm.setConfigPortalBlocking(false);
  wm.setConfigPortalTimeout(0);
  wm.setConnectTimeout(20);
  wm.setTitle("Paperboard");
  static std::vector<const char*> menu{"wifi", "exit"};
  wm.setMenu(menu);
  wm.setShowInfoUpdate(false);

  if (board::factoryResetAtBoot()) {
    Serial.println(F("[wifi] double reset -> factory reset"));
    factoryReset();
  }

  if (!board::wifiCredentialsSaved()) {  // FW-001 (#88)
    initialSetup = true;
    WiFi.mode(WIFI_AP);
    startPortal(false);
    return;
  }
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  board::wifiModemSleep();  // FW-041
  if (fastActive) {
    fastConnect.step(false, millis());  // BeginFast
    board::wifiFastBegin(power::bssid(), power::channel());
  } else {
    WiFi.begin();  // stored credentials
  }
}

// Fast reconnect: gives up after 3 s, clears the BSSID and connects normally (the AP may have changed channel).
static void fastConnectLoop() {
  switch (fastConnect.step(WiFi.isConnected(), millis())) {
    case core::ConnectAction::Connected:
      fastActive = false;
      WiFi.persistent(true);  // back to the default for the portal and the loss handling (no write by itself)
      break;
    case core::ConnectAction::FallbackNormal:
      Serial.println(F("[wifi] fast connect failed, normal connect"));
      power::clearBssid();
      board::wifiNormalBegin();
      WiFi.persistent(true);  // begin() is done; the setup portal needs persistence to save new credentials
      break;
    default:
      break;
  }
}

void loop() {
#ifdef PB_DEBUG
  if (dropUntil && (int32_t)(millis() - dropUntil) >= 0) {
    dropUntil = 0;
    WiFi.setAutoReconnect(true);
    WiFi.begin();
    Serial.println(F("[wifi] reconnecting after debug drop"));
  }
#endif
  if (fastActive) fastConnectLoop();
  board::loop();
  if (board::factoryResetRequested()) {  // FW-102: USER long press
    Serial.println(F("[wifi] USER reset"));
    factoryReset();
    board::restart();
  }

  if (initialSetup) {
    if (wm.process()) {  // credentials saved and connected
      Serial.printf_P(PSTR("[wifi] configured, connected to %s\n"), WiFi.SSID().c_str());
      initialSetup = false;
      stopPortal();
      WiFi.mode(WIFI_STA);
      WiFi.setAutoReconnect(true);
      board::wifiModemSleep();
      if (pairing::isPaired()) showConnected();  // unpaired: main shows "Add Paperboard in Homey"
    }
    return;
  }

  if (lossPolicy.portalOpen() && wm.process()) {
    Serial.printf_P(PSTR("[wifi] reconfigured via portal, connected to %s\n"), WiFi.SSID().c_str());
  }
  switch (lossPolicy.update(WiFi.isConnected(), millis())) {
    case core::WifiLossPolicy::Action::OpenPortal:
      Serial.println(F("[wifi] no connection for too long -> opening setup portal (FW-007)"));
      startPortal(true);
      break;
    case core::WifiLossPolicy::Action::ClosePortal:
      stopPortal();
      WiFi.mode(WIFI_STA);
      WiFi.setAutoReconnect(true);
      WiFi.begin();
      for (uint32_t t = millis(); !WiFi.isConnected() && millis() - t < 15000;) delay(100);
      if (WiFi.isConnected()) {
        Serial.println(F("[wifi] connected again, portal closed"));
        lossScreenShown = false;
      } else {
        Serial.println(F("[wifi] portal closed, still no connection"));
        showLossScreen();
      }
      break;
    default:
      break;
  }
  if (lossScreenShown && WiFi.isConnected()) lossScreenShown = false;  // poller fetches the frame again
}

bool online() { return !initialSetup && WiFi.isConnected(); }

bool portalActive() { return initialSetup || lossPolicy.portalOpen(); }

#ifdef PB_DEBUG
void debugDropWifi(uint32_t ms) {
  dropUntil = millis() + ms;
  WiFi.setAutoReconnect(false);
  board::wifiDrop();
  Serial.printf_P(PSTR("[wifi] Wi-Fi dropped for %lu s (debug)\n"), (unsigned long)(ms / 1000));
}

void debugSimulateWifiLoss() {
  lossPolicy = core::WifiLossPolicy(30000, 60000);
  WiFi.setAutoReconnect(false);
  // Not WiFi.disconnect(): with persistent mode it also erases the stored credentials (flash)
  board::wifiDrop();
  Serial.println(F("[wifi] simulated Wi-Fi loss (portal after 30 s for 60 s)"));
}
#endif

}  // namespace connectivity

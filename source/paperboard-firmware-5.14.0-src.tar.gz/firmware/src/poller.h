#pragma once
// Poll loop (FW-030…036, FW-050, FW-051, FW-060, IF-003): fetches the frame from the Homey app,
// updates the panel when it changed, handles errors with backoff and shows the offline state.

#include <stdint.h>

namespace poller {

void begin();

// Call from loop(); polls when due (blocking for the duration of one HTTP request).
void loop();

// Poll as soon as possible (pairing, config change, kick endpoint IF-013).
void kick();

// A local screen replaced the frame: the next poll fetches the frame again (no If-None-Match).
void invalidateFrame();

// Deep sleep (FW-038, FW-032 across sleeps, IF-003 X-Sleep-S). etag(): ETag of the frame the panel shows, "" if none.
const char* etag();
void restoreEtag(const char* etag);   // from the RTC record after a wake: the next poll sends If-None-Match
bool attempted();                     // a poll finished in this awake period (any result)
bool lastPollOk();                    // the last poll gave a frame or 304
uint32_t lastSleepS();                // valid X-Sleep-S (60..3600) of the last successful poll, else 0

#ifdef PB_DEBUG
// Shows the offline icon immediately (tests its removal on the next successful poll).
void debugShowOffline();
// Pretends the last successful poll was 30 min ago (tests the "Homey not reachable" screen).
void debugAgeLastSuccess();
// Draws black / red / both-inked squares and a border through the normal frame path (bwr boards only).
void debugTestPattern();
#endif

}  // namespace poller

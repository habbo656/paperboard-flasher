#pragma once
// Battery glue (#104, FW-112, FW-113, IF-006, ADR-24): measurement, armed state, critical shutdown and failure
// backoff counters. The decisions are core::CriticalPolicy / core::FailBackoff / core::SleepPolicy. NM-EPD-420 only;
// battery.cpp is not compiled for the D1 mini (build_src_filter); callers guard with `if (board::HAS_BATTERY)`.

#include <stdint.h>

#include "board.h"

namespace battery {

// Call in setup() after power::begin(): loads the RTC record (counters of the last wake).
void begin();
// Reads the cell (FW-112) and remembers a valid reading for onBattery()/mv(). Returns it, 0 if invalid.
uint16_t measure();
uint16_t mv();               // last valid reading of this awake period, 0 = none
bool armed();                // X-Battery-Mode: 1 cached from the app (NVS)
bool onBattery();            // armed AND a valid reading: the gate for backoff and critical shutdown
// The answer of a 200/304: "1" arms, anything else (also absent) disarms; written to NVS on change only.
void onModeHeader(const char* value);
// Critical shutdown (FW-113). burst = take 3 readings 200 ms apart (wake from sleep, after the display is up),
// else feed the last reading once (after each poll). Never returns when the device goes into the critical sleep;
// returns normally otherwise (also when a BOOT wake/USER press leaves the critical state).
void check(bool burst);
uint8_t failStreak();
// Called by power::sleepFor: updates the failed-sleep streak and writes the RTC record.
void onSleep(bool afterFailedPoll);

}  // namespace battery

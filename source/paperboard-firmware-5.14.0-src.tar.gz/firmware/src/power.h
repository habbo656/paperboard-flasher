#pragma once
// Deep sleep glue (FW-037, FW-038, FW-107, FW-074, ADR-23): reads the RTC record at boot, keeps the wake kind and the
// sleep-spanning uptime clock, writes the record and goes to sleep. The decision itself is core::SleepPolicy (main.cpp).

#include <stdint.h>

#include "sleep_logic.h"

namespace power {

// Call first in setup(): reads and validates the RTC record, hands the ETag to the poller and the refresh age to the
// display. Without a valid record (power-on, RESET on the S3, garbage) this is a cold start: wake() == Boot.
void begin();

core::WakeKind wake();       // how this awake period started (IF-003 X-Wake)
bool realReset();            // true unless this boot is a wake from our own deep sleep (X-Reset-Reason, FW-062)
uint32_t uptimeS();          // since the last real reset, across sleeps (X-Uptime-S, FW-074, FW-092)

// BSSID/channel of the last connect from the record (FW-037); clearBssid() after a failed fast connect.
bool hasBssid();
const uint8_t* bssid();
uint8_t channel();
void clearBssid();

// Hibernates the panel, writes the RTC record and deep-sleeps for `seconds`. Never returns.
[[noreturn]] void sleepFor(uint32_t seconds);

}  // namespace power

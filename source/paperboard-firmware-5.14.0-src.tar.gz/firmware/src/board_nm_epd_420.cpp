// Board layer for the NM-EPD-420 (ESP32-S3, tri-colour 4.2" panel), see board.h and docs/hardware.md section 7.
#include "board.h"

#include <Arduino.h>
#include <ESPmDNS.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <WiFi.h>
#include <Wire.h>
#include <esp_heap_caps.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <esp_ota_ops.h>
#include <esp_sleep.h>
#include <esp_random.h>
#include <esp_system.h>
#include <esp_wifi.h>

#include "aht20.h"
#include "button_press.h"
#include "sleep_logic.h"
#include "event_queue.h"

// RTC counter in microseconds (soc/esp32s3/rtc.h, not reachable through a public header); it keeps counting in deep sleep.
extern "C" uint64_t esp_rtc_get_time_us(void);

// ADR-18, NFR-012: keep the new image "pending verify" until ota::confirmBoot() (first answered poll). By default
// Arduino confirms it in initArduino(), before Wi-Fi is up. Any reset before confirmation makes the bootloader
// start the previous slot.
extern "C" bool verifyRollbackLater() { return true; }

namespace board {

const char* const ID = "nm_epd_420";
const char* const FRAME_FORMAT = "bwr";
const char* const PANEL = "GDEY042Z98";
const char* const RESET_HINT = "hold USER for 5 s";

// USER button (hardware.md section 7): GPIO45 is a strapping pin (VDD_SPI), never hold it while resetting.
// Pin and active level are vendor values, [open] until check N-7 (#47).
static constexpr int PIN_USER = 45;
static constexpr int USER_ACTIVE_LEVEL = LOW;
// BOOT (GPIO0, strapping pin) as a second event button (FW-080): off until check N-7 confirms it at runtime [open].
static constexpr bool BOOT_BUTTON = false;
static constexpr int PIN_BOOT = 0;
static constexpr int BOOT_ACTIVE_LEVEL = LOW;
static constexpr int PIN_TEMP_CTL = 40;  // AHT20 power gate, HIGH = on (#80)
static constexpr int PIN_BATT_ADC = 3;   // ADC1_CH2 behind a 2:1 divider (hardware.md N-16)
static constexpr int PIN_ADC_EN = 43;    // HIGH = divider on; U0TXD is unused (USB-CDC console), so it is free (N-18 rule)

void begin() {
  gpio_deep_sleep_hold_dis();        // FW-038: release the pad holds of the last deep sleep (TEMP_CTL)
  gpio_hold_dis((gpio_num_t)PIN_TEMP_CTL);
  gpio_hold_dis((gpio_num_t)PIN_ADC_EN);
  Serial.setTxTimeoutMs(0);  // HWCDC: never block on logging when no host reads the port (runs on a charger)
  pinMode(PIN_USER, INPUT_PULLUP);
  if (BOOT_BUTTON) pinMode(PIN_BOOT, INPUT_PULLUP);
}

uint32_t chipId() {
  // The eFuse MAC holds byte 0 in the lowest byte; bytes 0..2 are the vendor OUI, the last three differ per chip.
  return (uint32_t)(ESP.getEfuseMac() >> 24) & 0xFFFFFF;
}

const char* resetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "power-on";
    case ESP_RST_SW: return "restart";
    case ESP_RST_PANIC: return "exception";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT: return "hw-watchdog";
    case ESP_RST_DEEPSLEEP: return "deep-sleep";
    default: return "unknown";  // brown-out, external reset, ...
  }
}

uint32_t freeHeap() { return heap_caps_get_free_size(MALLOC_CAP_INTERNAL); }
uint32_t maxBlock() { return heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL); }
void restart() {
  esp_restart();
  for (;;) {}
}
void hardReset() { restart(); }
uint32_t hwRandom() { return esp_random(); }
void otaConfirm() { esp_ota_mark_app_valid_cancel_rollback(); }  // ADR-18; harmless if already valid

// FW-112: ADC_EN is only high while measuring (the divider would draw current in sleep). With the settle time of 5 ms
// (N-16: stable from 1 ms) and the eFuse calibration of analogReadMilliVolts; no further offset (no meter, ADR-24).
uint16_t batteryReadMv() {
  analogSetPinAttenuation(PIN_BATT_ADC, ADC_11db);
  pinMode(PIN_ADC_EN, OUTPUT);
  digitalWrite(PIN_ADC_EN, HIGH);
  delay(5);
  uint32_t sum = 0;
  for (int i = 0; i < 16; i++) sum += analogReadMilliVolts(PIN_BATT_ADC);
  digitalWrite(PIN_ADC_EN, LOW);
  return (uint16_t)(sum / 16 * 2);  // pin mV x 2 for the divider; at most ~3 V x 2, fits
}

// FW-113, IF-006: the armed flag lives in NVS (namespace "pb", key "batt"), read once, written on change only.
static int8_t batteryModeCache = -1;
bool batteryMode() {
  if (batteryModeCache < 0) {
    Preferences p;
    batteryModeCache = p.begin("pb", true) ? p.getUChar("batt", 0) == 1 : 0;
    p.end();
  }
  return batteryModeCache == 1;
}
void setBatteryMode(bool on) {
  if (batteryMode() == on) return;
  Preferences p;
  if (p.begin("pb", false)) {
    p.putUChar("batt", on ? 1 : 0);
    p.end();
    batteryModeCache = on ? 1 : 0;
  }
}

// Survives software/watchdog resets but not power loss, like the ESP8266 RTC user memory. Garbage after power-on
// is rejected by the magic values of the users.
struct RtcArea {
  uint8_t health[8];
  uint8_t ota[40];
  uint8_t doubleReset[8];
  uint8_t sleep[48];     // core::SleepRecord (FW-038)
  uint8_t battery[12];   // core::BatteryRecord (FW-113)
  uint64_t sleepAtUs;    // esp_rtc_get_time_us() when going to sleep: slept time after a BOOT wake
};
static RTC_NOINIT_ATTR RtcArea rtcArea;

static uint8_t* rtcSlot(Rtc slot, size_t* cap) {
  switch (slot) {
    case Rtc::Health: *cap = sizeof(rtcArea.health); return rtcArea.health;
    case Rtc::Ota: *cap = sizeof(rtcArea.ota); return rtcArea.ota;
    case Rtc::Sleep: *cap = sizeof(rtcArea.sleep); return rtcArea.sleep;
    case Rtc::Battery: *cap = sizeof(rtcArea.battery); return rtcArea.battery;
    default: *cap = sizeof(rtcArea.doubleReset); return rtcArea.doubleReset;
  }
}
void rtcRead(Rtc slot, void* data, size_t bytes) {
  size_t cap;
  uint8_t* p = rtcSlot(slot, &cap);
  memcpy(data, p, bytes < cap ? bytes : cap);
}
void rtcWrite(Rtc slot, const void* data, size_t bytes) {
  size_t cap;
  uint8_t* p = rtcSlot(slot, &cap);
  memcpy(p, data, bytes < cap ? bytes : cap);
}

// The stored credentials are read first: with persistent(false) before the Wi-Fi driver is up, the S3 driver would not
// load them from NVS. persistent(false) then keeps the SDK/NVS from rewriting the station config on every wake.
bool wifiApInfo(uint8_t bssid[6], uint8_t* channel) {
  wifi_ap_record_t ap;
  if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) return false;
  memcpy(bssid, ap.bssid, 6);
  *channel = ap.primary;
  return true;
}
// Station config stored in NVS. WiFi.SSID() is no use here: on Arduino-ESP32 it returns the SSID of the *connected* AP,
// i.e. an empty string right after a wake (#84).
static bool storedStaConfig(String* ssid, String* psk) {
  WiFi.mode(WIFI_STA);  // esp_wifi_get_config fails before the driver is up
  wifi_config_t conf;
  memset(&conf, 0, sizeof(conf));
  if (esp_wifi_get_config(WIFI_IF_STA, &conf) != ESP_OK || !conf.sta.ssid[0]) return false;
  char s[33], p[65];
  memcpy(s, conf.sta.ssid, 32); s[32] = 0;
  memcpy(p, conf.sta.password, 64); p[64] = 0;
  *ssid = s;
  *psk = p;
  return true;
}
void wifiFastBegin(const uint8_t* bssid, uint8_t channel) {
  String ssid, psk;
  storedStaConfig(&ssid, &psk);
  if (core::chooseBeginPath(ssid.c_str()) == core::BeginPath::Stored) {
    WiFi.begin();  // stored credentials, no BSSID
    return;
  }
  WiFi.persistent(false);
  WiFi.begin(ssid.c_str(), psk.c_str(), channel, bssid);
}
void wifiNormalBegin() {
  String ssid, psk;
  storedStaConfig(&ssid, &psk);
  if (core::chooseBeginPath(ssid.c_str()) == core::BeginPath::Stored) {
    WiFi.begin();
    return;
  }
  WiFi.persistent(false);
  WiFi.begin(ssid.c_str(), psk.c_str());
}

void wifiDrop() { esp_wifi_disconnect(); }
bool wifiCredentialsSaved() {
  WiFi.mode(WIFI_STA);  // brings the driver up; esp_wifi_get_config fails (and leaves conf untouched) before that
  wifi_config_t conf;
  memset(&conf, 0, sizeof(conf));
  if (esp_wifi_get_config(WIFI_IF_STA, &conf) != ESP_OK) return false;
  return conf.sta.ssid[0] != 0;
}
void wifiModemSleep() { WiFi.setSleep(true); }

bool fsBegin() { return LittleFS.begin(true); }  // formats on first use

bool mdnsBegin(const char* host) { return MDNS.begin(host); }
static const char* svcName = "paperboard";
void mdnsAddService(const char* name, uint16_t port) {
  svcName = name;
  MDNS.addService(name, "tcp", port);
}
void mdnsTxt(const char* key, const char* value) { MDNS.addServiceTxt(svcName, "tcp", key, value); }
void mdnsTxtReplace(const char* key, const char* value) { MDNS.addServiceTxt(svcName, "tcp", key, value); }  // sets
void mdnsAnnounce() {}  // the mDNS responder re-announces changed TXT records itself
void mdnsUpdate() {}
void mdnsEnd() { MDNS.end(); }

bool factoryResetAtBoot() { return false; }

// FW-102/FW-080: USER classified as short/long (on release) or reset (>= 5 s, while held). The state machines
// ignore a button that is already held at boot. BOOT never resets.
static core::ButtonPress userPress;
static core::ButtonPress bootPress(50, 1000, 3000, 5000, false);
static bool resetRequested = false;

// Pending presses for popButtonEvent (2 slots; further presses before the next events::loop() are dropped).
struct Pending { uint8_t button, press; };
static Pending pending[2];
static uint8_t pendingCount = 0;

static void latch(core::ButtonId id, core::Press p) {
  if (pendingCount < 2) pending[pendingCount++] = Pending{(uint8_t)id, (uint8_t)p};
}

// Also called from the GxEPD2 busy callback (display.cpp): only digitalRead, no network, no allocation.
void loop() {
  static uint32_t last = 0;
  const uint32_t now = millis();
  if (now - last < 10) return;
  last = now;
  const core::Press u = userPress.update(digitalRead(PIN_USER) == USER_ACTIVE_LEVEL, now);
  if (u == core::Press::Reset) resetRequested = true;
  else if (u != core::Press::None) latch(core::ButtonId::User, u);
  if (BOOT_BUTTON) {
    const core::Press b = bootPress.update(digitalRead(PIN_BOOT) == BOOT_ACTIVE_LEVEL, now);
    if (b != core::Press::None) latch(core::ButtonId::Boot, b);
  }
}

bool factoryResetRequested() {
  const bool r = resetRequested;
  resetRequested = false;
  return r;
}

// FW-081, FW-104 (#80): AHT20 on I2C address 0x38. Pins and power gate per docs/hardware.md section 7 (verified, N-11):
// SDA 39, SCL 38 (shared with the ES8311 codec at 0x18, unused), TEMP_CTL 40 powers the sensor (HIGH = on).
// -1 = not configured, the sensor then reads "missing" and no I2C code runs.
static constexpr int PIN_SDA = 39;
static constexpr int PIN_SCL = 38;
static constexpr uint32_t POWER_UP_MS = 100;  // AHT20 datasheet: >= 100 ms after power-on before the first command
static constexpr uint32_t POWER_OFF_MS = 100;  // gate held low for a power cycle (recovery after repeated failures)
static constexpr uint8_t AHT20_ADDR = 0x38;

static core::ClimateSchedule climateSched;
static bool i2cStarted = false;
static bool sensorInited = false;      // calibrated bit confirmed (or init command sent)
static bool sensorAnswered = false;    // the chip ever acked on the bus
static int16_t lastDeciC = 0;
static uint8_t lastRh = 0;
static uint32_t debugFailUntil = 0;
static bool debugFailActive = false;
static bool gatePowered = false;       // TEMP_CTL driven HIGH at least once
static bool gateOn = false;
static uint32_t gateChangeAt = 0;      // millis() of the last gate change

static bool i2cWrite(const uint8_t* d, size_t n) {
  Wire.beginTransmission(AHT20_ADDR);
  Wire.write(d, n);
  return Wire.endTransmission() == 0;
}

// Status byte 0x71; sends the init command if the calibrated bit (3) is not set. False if the chip does not answer.
static bool sensorInit() {
  const uint8_t st = 0x71;
  if (!i2cWrite(&st, 1) || Wire.requestFrom((int)AHT20_ADDR, 1) != 1) return false;
  sensorAnswered = true;
  const uint8_t status = (uint8_t)Wire.read();
  if (!(status & 0x08)) {
    const uint8_t init[3] = {0xBE, 0x08, 0x00};
    i2cWrite(init, 3);
    return false;  // calibrates in ~10 ms; the next cycle sees the bit set
  }
  return true;
}

void climateLoop() {
  if (PIN_SDA < 0 || PIN_SCL < 0) return;
  const uint32_t now = millis();
  if (debugFailActive && (int32_t)(now - debugFailUntil) >= 0) debugFailActive = false;
  // Power gate, non-blocking: HIGH on first call, then no I2C until POWER_UP_MS after every switch-on; a power cycle
  // keeps it low for POWER_OFF_MS.
  if (!gatePowered) {
    gatePowered = gateOn = true;
    pinMode(PIN_TEMP_CTL, OUTPUT);
    digitalWrite(PIN_TEMP_CTL, HIGH);
    gateChangeAt = now;
  }
  if (!gateOn) {
    if (now - gateChangeAt < POWER_OFF_MS) return;
    digitalWrite(PIN_TEMP_CTL, HIGH);
    gateOn = true;
    gateChangeAt = now;
  }
  if (now - gateChangeAt < POWER_UP_MS) return;
  const auto action = climateSched.next(now);
  if (action == core::ClimateSchedule::Action::Idle) return;
  if (!i2cStarted) {
    Wire.begin(PIN_SDA, PIN_SCL, 100000);
    Wire.setTimeOut(20);  // ms: a stuck bus must never block the loop (FW-104)
    i2cStarted = true;
  }
  if (action == core::ClimateSchedule::Action::Trigger) {
    if (climateSched.takeSoftReset()) {
      // Recovery after repeated failures: power-cycle the sensor via TEMP_CTL (also clears a wedged chip that ignores
      // the soft-reset command). The next cycle starts after POWER_OFF_MS + POWER_UP_MS.
      digitalWrite(PIN_TEMP_CTL, LOW);
      gateOn = false;
      gateChangeAt = now;
      sensorInited = false;
      return;
    }
    if (debugFailActive) return climateSched.failed(now);
    if (!sensorInited) sensorInited = sensorInit();
    const uint8_t trig[3] = {0xAC, 0x33, 0x00};
    if (sensorInited && i2cWrite(trig, 3)) climateSched.triggered(now);
    else climateSched.failed(now);
    return;
  }
  uint8_t f[7];
  int16_t t;
  uint8_t h;
  if (!debugFailActive && Wire.requestFrom((int)AHT20_ADDR, 7) == 7) {
    for (auto& b : f) b = (uint8_t)Wire.read();
    if (core::aht20Parse(f, &t, &h)) {
      lastDeciC = t;
      lastRh = h;
      sensorAnswered = true;
      return climateSched.readOk(now);
    }
  }
  climateSched.failed(now);
}

bool climate(int16_t* deciC, uint8_t* rhPct) {
  if (!climateSched.fresh(millis())) return false;
  *deciC = lastDeciC;
  *rhPct = lastRh;
  return true;
}

const char* climateState() {
  if (climateSched.fresh(millis())) return "ok";
  return sensorAnswered ? "error" : "missing";
}

void debugClimateFail() {
  debugFailActive = true;
  debugFailUntil = millis() + 300000UL;
}

bool userHeld() { return digitalRead(PIN_USER) == USER_ACTIVE_LEVEL; }

bool popButtonEvent(uint8_t* button, uint8_t* press) {
  if (!pendingCount) return false;
  *button = pending[0].button;
  *press = pending[0].press;
  pending[0] = pending[1];
  pendingCount--;
  return true;
}

// Deep sleep (FW-038, FW-107). Wake sources: timer and BOOT (GPIO0, ext0, low level). USER (GPIO45) is not an RTC GPIO
// and cannot wake the chip (hardware.md N-15).
core::WakeKind wakeReason() {
  if (esp_reset_reason() != ESP_RST_DEEPSLEEP) return core::WakeKind::Boot;
  switch (esp_sleep_get_wakeup_cause()) {
    case ESP_SLEEP_WAKEUP_TIMER: return core::WakeKind::Timer;
    case ESP_SLEEP_WAKEUP_EXT0: return core::WakeKind::Button;
    default: return core::WakeKind::Boot;
  }
}

// The RTC timer keeps counting in deep sleep, so the delta is exact also after a BOOT wake. Plausibility check against
// the planned time (a wrong value would only skew X-Uptime-S).
uint32_t sleptMs(uint32_t plannedMs) {
  const uint64_t now = esp_rtc_get_time_us();
  if (now < rtcArea.sleepAtUs) return plannedMs;
  const uint64_t ms = (now - rtcArea.sleepAtUs) / 1000;
  return ms > (uint64_t)plannedMs + 10000 ? plannedMs : (uint32_t)ms;
}

// AHT20 off (#80): TEMP_CTL low and held through deep sleep; the next climateLoop() drives it HIGH again.
void prepareSleep() {
  if (i2cStarted) Wire.end();
  pinMode(PIN_TEMP_CTL, OUTPUT);
  digitalWrite(PIN_TEMP_CTL, LOW);
  gpio_hold_en((gpio_num_t)PIN_TEMP_CTL);
  pinMode(PIN_ADC_EN, OUTPUT);   // FW-112: divider off through the sleep
  digitalWrite(PIN_ADC_EN, LOW);
  gpio_hold_en((gpio_num_t)PIN_ADC_EN);
  gpio_deep_sleep_hold_en();
  // #82 (RGB LED) and #83 (amplifier): not on this board / not merged; they add their shutdown here.
}

void deepSleep(uint32_t seconds) {
  esp_sleep_enable_timer_wakeup((uint64_t)seconds * 1000000ULL);
  // ext0 is level triggered: while BOOT is held the chip would wake again at once, in a loop (hardware.md N-15).
  // So it is only armed while BOOT is released; a held BOOT just means this sleep has the timer only.
  pinMode(PIN_BOOT, INPUT_PULLUP);
  delay(2);
  if (digitalRead(PIN_BOOT) != BOOT_ACTIVE_LEVEL) {
    rtc_gpio_pullup_en(GPIO_NUM_0);
    rtc_gpio_pulldown_dis(GPIO_NUM_0);
    esp_sleep_enable_ext0_wakeup(GPIO_NUM_0, 0);
  }
  rtcArea.sleepAtUs = esp_rtc_get_time_us();
  Serial.flush();
#ifdef PB_DEBUG
  delay(300);  // USB-CDC: the host reads the last log lines (they are otherwise lost, hardware.md N-15)
#endif
  esp_deep_sleep_start();
  for (;;) {}
}

}  // namespace board

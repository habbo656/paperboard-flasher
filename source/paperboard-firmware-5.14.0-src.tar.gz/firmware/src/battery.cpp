#include "battery.h"

#include <Arduino.h>

#include "battery_logic.h"
#include "display.h"
#include "poller.h"
#include "power.h"
#include "screens.h"

namespace battery {

static core::BatteryRecord rec;
static uint16_t lastMv = 0;

void begin() {
  uint8_t raw[core::BATTERY_RECORD_BYTES];
  board::rtcRead(board::Rtc::Battery, raw, sizeof(raw));
  core::unpackBatteryRecord(raw, &rec);  // garbage / power-on: defaults
}

uint16_t measure() {
  const uint16_t v = board::batteryReadMv();
  lastMv = core::batteryValid(v) ? v : 0;
  return lastMv;
}

uint16_t mv() { return lastMv; }
bool armed() { return board::batteryMode(); }
bool onBattery() { return armed() && lastMv != 0; }
uint8_t failStreak() { return rec.failStreak; }

void onModeHeader(const char* value) {
  const bool on = core::parseBatteryMode(value);
  if (on != board::batteryMode()) Serial.printf_P(PSTR("[battery] mode %s by the app\n"), on ? "armed" : "disarmed");
  board::setBatteryMode(on);  // no flash write unless it changed
  if (!on) rec.policy.reset();
}

void onSleep(bool afterFailedPoll) {
  if (afterFailedPoll && onBattery()) {
    if (rec.failStreak < 100) rec.failStreak++;
  } else if (!rec.policy.critical) {
    rec.failStreak = 0;  // successful poll (or no battery logic): backoff starts over
  }
  uint8_t raw[core::BATTERY_RECORD_BYTES];
  core::packBatteryRecord(rec, raw);
  board::rtcWrite(board::Rtc::Battery, raw, sizeof(raw));
}

[[noreturn]] static void criticalSleep(bool showScreen) {
  if (showScreen) {
    Serial.printf_P(PSTR("[battery] critical (%u mV), showing the empty screen\n"), (unsigned)lastMv);
    screens::showBatteryEmpty();
  } else {
    Serial.printf_P(PSTR("[battery] still critical (%u mV), sleeping 1 h\n"), (unsigned)lastMv);
  }
  power::sleepFor(core::BATTERY_CRITICAL_SLEEP_S);  // measure-only wake, no Wi-Fi
}

void check(bool burst) {
  if (!armed()) return;
  const bool wasCritical = rec.policy.critical;
  const bool leave = power::wake() == core::WakeKind::Button || board::userHeld();  // BOOT or USER: boot normally
  if (burst) {
    for (int i = 0; i < core::BATTERY_CONFIRM; i++) {
      if (i) delay(200);
      measure();
      rec.policy.feed(lastMv);
      // A first reading that is neither low nor (when critical) recovered needs no confirmation.
      if (!wasCritical && lastMv >= core::BATTERY_CRITICAL_MV) break;
      if (wasCritical && lastMv && lastMv < core::BATTERY_RECOVER_MV) break;
    }
  } else {
    rec.policy.feed(lastMv);
  }
  if (rec.policy.critical && leave) {
    Serial.println(F("[battery] critical state left by a button press"));
    rec.policy.reset();
    return;
  }
  if (rec.policy.critical) criticalSleep(!wasCritical);
  if (wasCritical) Serial.println(F("[battery] recovered, booting normally"));
}


}  // namespace battery

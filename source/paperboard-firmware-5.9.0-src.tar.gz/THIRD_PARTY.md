# Third-Party Components

Licences of third-party code, fonts and assets used in this repository (NFR-046).

| Component | Used in | Licence | Note |
|---|---|---|---|
| GxEPD2 (zinggjm) | hardware tests, firmware | GPL-3.0 | Firmware binaries are distributed under GPL-3.0 terms; the Homey app package bundles the release image (`homey-app/firmware/`, OTA, ADR-18), the source is in this repository; the public flasher repo carries a source tarball of the firmware next to the binaries (ADR-21) |
| ESP8266 Arduino core (esp8266/Arduino) | firmware (all binaries) | LGPL-2.1 | Includes `Updater` (OTA), ESP8266WiFi, ESP8266HTTPClient, ESP8266mDNS, LittleFS; linked into every firmware binary, core source: https://github.com/esp8266/Arduino |
| Arduino core for ESP32 (espressif/arduino-esp32) | firmware (NM-EPD-420 binaries) | LGPL-2.1 | Includes `Update` (OTA), WiFi, HTTPClient, ESPmDNS, LittleFS; linked into every `nm_epd_420` binary, core source: https://github.com/espressif/arduino-esp32 |
| ESP-IDF (Espressif) | firmware (NM-EPD-420 binaries, via the ESP32 Arduino core) | Apache-2.0 | Bootloader, `esp_ota`, Wi-Fi stack; source: https://github.com/espressif/esp-idf |
| Adafruit GFX Library | hardware tests, firmware | BSD-2-Clause | |
| WiFiManager (tzapu) | firmware | MIT | |
| QRCode (ricmoo) | firmware | MIT | |
| ArduinoJson (bblanchon) | firmware | MIT | |
| pureimage | Homey app renderer | MIT | |
| suncalc | sun and moon times (Homey app) | BSD-2-Clause | |
| ical.js | iCal parsing (Homey app) | MPL-2.0 | Used unmodified from npm |
| homey-api (Athom) | Homey app content sources | Proprietary, "may be used freely with Homey products" | Not in the repository (node_modules); installed with the app |
| Preact | layout editor (bundled into `homey-app/settings/editor.js`) | MIT | |
| esbuild | editor build tool only | MIT | Not shipped |
| ESP Web Tools (esphome) | browser flasher (`flasher/vendor/esp-web-tools/`, v10.4.0, unmodified `dist/web` of the npm package; includes esptool-js) | Apache-2.0 | Runs only in the user's browser, not part of the device or the Homey app; licence text next to it; ADR-21 |
| Open-Meteo API | weather data (fetched at runtime) | CC BY 4.0 (data), free for non-commercial use | Attribution: "Weather data by Open-Meteo.com" (shown in the editor hint) |
| @resvg/resvg-wasm | render spike only (rejected) | MPL-2.0 | Not used in the app |
| DejaVu Sans / Bold (subset) | `homey-app/assets/fonts`, `spikes/render-spike/fonts` | Bitstream Vera licence + public domain changes | Licence text next to the fonts (`LICENSE-DejaVu.txt`); subset with pyftsubset, name kept (allowed, contains neither "Bitstream" nor "Vera") |

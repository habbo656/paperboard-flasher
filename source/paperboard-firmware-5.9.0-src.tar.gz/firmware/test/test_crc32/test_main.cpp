#include <string.h>
#include <unity.h>

#include "crc32.h"

void setUp() {}
void tearDown() {}

void test_known_vector() {
  const char* s = "123456789";
  TEST_ASSERT_EQUAL_HEX32(0xCBF43926u, crc32Update(0, (const uint8_t*)s, strlen(s)));
}

void test_empty_input() { TEST_ASSERT_EQUAL_HEX32(0u, crc32Update(0, nullptr, 0)); }

void test_incremental_equals_one_shot() {
  // Frame streamed in 1 000-byte stripes must give the same CRC as the whole buffer (FW-033/034)
  static uint8_t frame[15000];
  for (size_t i = 0; i < sizeof(frame); i++) frame[i] = (uint8_t)(i * 31 + 7);
  uint32_t whole = crc32Update(0, frame, sizeof(frame));
  uint32_t parts = 0;
  for (size_t off = 0; off < sizeof(frame); off += 1000) parts = crc32Update(parts, frame + off, 1000);
  TEST_ASSERT_EQUAL_HEX32(whole, parts);
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_known_vector);
  RUN_TEST(test_empty_input);
  RUN_TEST(test_incremental_equals_one_shot);
  return UNITY_END();
}

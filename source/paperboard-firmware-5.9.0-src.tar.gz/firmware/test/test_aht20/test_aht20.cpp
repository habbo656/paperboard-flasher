#include <string.h>
#include <unity.h>

#include "aht20.h"

void setUp() {}
void tearDown() {}

// Builds a 7-byte frame from raw 20-bit values with a correct CRC.
static void frame(uint8_t f[7], uint32_t rawH, uint32_t rawT, uint8_t status = 0x18) {
  f[0] = status;
  f[1] = (rawH >> 12) & 0xFF;
  f[2] = (rawH >> 4) & 0xFF;
  f[3] = (uint8_t)(((rawH & 0x0F) << 4) | ((rawT >> 16) & 0x0F));
  f[4] = (rawT >> 8) & 0xFF;
  f[5] = rawT & 0xFF;
  f[6] = core::aht20Crc8(f, 6);
}

void test_crc8_check_value() {
  // CRC-8 poly 0x31, init 0xFF (CRC-8/NRSC-5) check value for "123456789"
  TEST_ASSERT_EQUAL_HEX8(0xF7, core::aht20Crc8((const uint8_t*)"123456789", 9));
  const uint8_t z = 0;
  TEST_ASSERT_EQUAL_HEX8(0xAC, core::aht20Crc8(&z, 1));  // datasheet example: CRC of one 0x00 byte
}

void test_parse_mid_codes() {
  uint8_t f[7];
  int16_t t;
  uint8_t h;
  frame(f, 1u << 19, 1u << 19);  // 50 %RH, 50 C
  TEST_ASSERT_TRUE(core::aht20Parse(f, &t, &h));
  TEST_ASSERT_EQUAL(500, t);
  TEST_ASSERT_EQUAL(50, h);
}

void test_parse_limits() {
  uint8_t f[7];
  int16_t t;
  uint8_t h;
  frame(f, 0, 0);  // 0 %RH, -50 C -> out of range
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
  frame(f, 0, 0x40000);  // -50 + 0.25*200 = 0.0 C, 0 %RH
  TEST_ASSERT_TRUE(core::aht20Parse(f, &t, &h));
  TEST_ASSERT_EQUAL(0, t);
  TEST_ASSERT_EQUAL(0, h);
  frame(f, 0xFFFFF, 0x40000 - 3000);  // 100 % RH; about -0.3 C
  TEST_ASSERT_TRUE(core::aht20Parse(f, &t, &h));
  TEST_ASSERT_EQUAL(100, h);
  TEST_ASSERT_TRUE(t < 0 && t > -10);
  frame(f, 1u << 19, 0xFFFFF);  // 150 C
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
  frame(f, 1u << 19, 0xACCCD);  // 85 C is the limit: 0xACCCD/2^20*200-50 = 85.0
  TEST_ASSERT_TRUE(core::aht20Parse(f, &t, &h));
  TEST_ASSERT_EQUAL(850, t);
  frame(f, 1u << 19, 0xACCCD + 1000);  // above 85.0
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
}

void test_parse_cold_limit() {
  uint8_t f[7];
  int16_t t;
  uint8_t h;
  frame(f, 1u << 19, 52429);  // (52429/2^20)*200-50 = -39.99
  TEST_ASSERT_TRUE(core::aht20Parse(f, &t, &h));
  TEST_ASSERT_EQUAL(-400, t);
  frame(f, 1u << 19, 52429 - 1000);
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
}

void test_parse_rejects_bad_frames() {
  uint8_t f[7];
  int16_t t;
  uint8_t h;
  frame(f, 1u << 19, 1u << 19, 0x98);  // busy
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
  frame(f, 1u << 19, 1u << 19, 0x10);  // not calibrated
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
  frame(f, 1u << 19, 1u << 19);
  f[6] ^= 1;  // wrong CRC
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
  frame(f, 1u << 19, 1u << 19);
  f[2] ^= 0x10;  // corrupted data
  TEST_ASSERT_FALSE(core::aht20Parse(f, &t, &h));
}

static void fmt(int16_t v, const char* want) {
  char b[8];
  TEST_ASSERT_TRUE(core::formatDeci(b, sizeof b, v));
  TEST_ASSERT_EQUAL_STRING(want, b);
}

void test_format_deci() {
  fmt(214, "21.4");
  fmt(-5, "-0.5");
  fmt(0, "0.0");
  fmt(850, "85.0");
  fmt(-400, "-40.0");
  fmt(5, "0.5");
  fmt(-123, "-12.3");
  char b[6];
  TEST_ASSERT_FALSE(core::formatDeci(b, sizeof b, 214));
}

using core::ClimateSchedule;
using A = core::ClimateSchedule::Action;

void test_schedule_interval_and_wait() {
  ClimateSchedule s;
  TEST_ASSERT_EQUAL(A::Trigger, s.next(1000));
  s.triggered(1000);
  TEST_ASSERT_EQUAL(A::Idle, s.next(1079));
  TEST_ASSERT_EQUAL(A::Read, s.next(1080));
  s.readOk(1100);
  TEST_ASSERT_EQUAL(A::Idle, s.next(60999));
  TEST_ASSERT_EQUAL(A::Trigger, s.next(61000));
}

void test_schedule_fresh_for_180s() {
  ClimateSchedule s;
  TEST_ASSERT_FALSE(s.fresh(0));
  s.triggered(0);
  s.readOk(100);
  TEST_ASSERT_TRUE(s.fresh(100 + 180000));
  TEST_ASSERT_FALSE(s.fresh(100 + 180001));
}

void test_schedule_failures_request_soft_reset_once() {
  ClimateSchedule s;
  uint32_t t = 0;
  for (int i = 0; i < 2; i++) {
    s.triggered(t);
    s.failed(t + 100);
    t += 60000;
    TEST_ASSERT_FALSE(s.takeSoftReset());
  }
  s.triggered(t);
  s.failed(t + 100);
  TEST_ASSERT_TRUE(s.takeSoftReset());
  TEST_ASSERT_FALSE(s.takeSoftReset());
}

void test_schedule_success_resets_failure_count() {
  ClimateSchedule s;
  uint32_t t = 0;
  for (int i = 0; i < 2; i++) {
    s.triggered(t);
    s.failed(t + 100);
    t += 60000;
  }
  s.triggered(t);
  s.readOk(t + 100);
  t += 60000;
  s.triggered(t);
  s.failed(t + 100);
  TEST_ASSERT_FALSE(s.takeSoftReset());
}

void test_schedule_failed_trigger_retries_after_interval() {
  ClimateSchedule s;
  TEST_ASSERT_EQUAL(A::Trigger, s.next(500));
  s.failed(500);  // I2C write failed, no conversion pending
  TEST_ASSERT_EQUAL(A::Idle, s.next(30000));
  TEST_ASSERT_EQUAL(A::Trigger, s.next(60500));
}

void test_schedule_millis_wrap() {
  ClimateSchedule s;
  const uint32_t t0 = 0xFFFFFFFFu - 40;
  s.triggered(t0);
  TEST_ASSERT_EQUAL(A::Idle, s.next(t0 + 79));
  TEST_ASSERT_EQUAL(A::Read, s.next(t0 + 80));  // wrapped
  s.readOk(t0 + 100);
  TEST_ASSERT_TRUE(s.fresh(t0 + 100 + 180000));
  TEST_ASSERT_FALSE(s.fresh(t0 + 100 + 180001));
  TEST_ASSERT_EQUAL(A::Trigger, s.next(t0 + 60000));
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_crc8_check_value);
  RUN_TEST(test_parse_mid_codes);
  RUN_TEST(test_parse_limits);
  RUN_TEST(test_parse_cold_limit);
  RUN_TEST(test_parse_rejects_bad_frames);
  RUN_TEST(test_format_deci);
  RUN_TEST(test_schedule_interval_and_wait);
  RUN_TEST(test_schedule_fresh_for_180s);
  RUN_TEST(test_schedule_failures_request_soft_reset_once);
  RUN_TEST(test_schedule_success_resets_failure_count);
  RUN_TEST(test_schedule_failed_trigger_retries_after_interval);
  RUN_TEST(test_schedule_millis_wrap);
  return UNITY_END();
}

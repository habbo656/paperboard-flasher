#include <unity.h>

#include "button_press.h"

using core::Press;

void setUp() {}
void tearDown() {}

struct Count {
  int none = 0, shortP = 0, longP = 0, reset = 0;
};

// Feeds `pressed` every 10 ms from `from` to `to` (ms) and counts the results.
static Count feed(core::ButtonPress& b, bool pressed, uint32_t from, uint32_t to) {
  Count c;
  for (uint32_t t = from; t <= to; t += 10) {
    switch (b.update(pressed, t)) {
      case Press::Short: c.shortP++; break;
      case Press::Long: c.longP++; break;
      case Press::Reset: c.reset++; break;
      default: c.none++;
    }
  }
  return c;
}

// A press from t0 to t0+len (edges), released afterwards for 500 ms; returns the sum of the results.
static Count press(core::ButtonPress& b, uint32_t t0, uint32_t len) {
  Count a = feed(b, true, t0, t0 + len - 10);
  Count r = feed(b, false, t0 + len, t0 + len + 500);
  a.shortP += r.shortP; a.longP += r.longP; a.reset += r.reset;
  return a;
}

static core::ButtonPress ready() {
  core::ButtonPress b;
  feed(b, false, 0, 1000);
  return b;
}

// ---- classification (FW-080) ----
void test_short_press() {
  auto b = ready();
  Count c = press(b, 1010, 200);
  TEST_ASSERT_EQUAL(1, c.shortP);
  TEST_ASSERT_EQUAL(0, c.longP + c.reset);
}

void test_short_reported_on_release_only() {
  auto b = ready();
  Count held = feed(b, true, 1010, 1300);
  TEST_ASSERT_EQUAL(0, held.shortP);
  TEST_ASSERT_EQUAL(1, feed(b, false, 1310, 1500).shortP);
}

void test_short_long_boundary() {
  auto b = ready();
  TEST_ASSERT_EQUAL(1, press(b, 1010, 990).shortP);
  auto b2 = ready();
  Count c = press(b2, 1010, 1000);
  TEST_ASSERT_EQUAL(1, c.longP);
  TEST_ASSERT_EQUAL(0, c.shortP);
}

void test_long_press() {
  auto b = ready();
  Count c = press(b, 1010, 2000);
  TEST_ASSERT_EQUAL(1, c.longP);
  TEST_ASSERT_EQUAL(0, c.shortP + c.reset);
}

void test_long_upper_boundary() {
  auto b = ready();
  TEST_ASSERT_EQUAL(1, press(b, 1010, 2990).longP);
}

void test_cancel_zone_gives_nothing() {
  auto b = ready();
  Count c = press(b, 1010, 3000);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
  auto b2 = ready();
  c = press(b2, 1010, 4990);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
}

// ---- reset (FW-102, existing LongPress cases) ----
void test_reset_once_while_held_and_nothing_on_release() {
  auto b = ready();
  Count h = feed(b, true, 1010, 15000);
  TEST_ASSERT_EQUAL(1, h.reset);
  TEST_ASSERT_EQUAL(0, h.shortP + h.longP);
  Count r = feed(b, false, 15010, 16000);
  TEST_ASSERT_EQUAL(0, r.shortP + r.longP + r.reset);
}

void test_reset_exactly_at_threshold() {
  auto b = ready();
  TEST_ASSERT_EQUAL(Press::None, b.update(true, 1010));  // edge
  TEST_ASSERT_EQUAL(Press::None, b.update(true, 1060));  // debounced
  TEST_ASSERT_EQUAL(Press::None, b.update(true, 6000));  // 4.99 s
  TEST_ASSERT_EQUAL(Press::Reset, b.update(true, 6010));
  TEST_ASSERT_EQUAL(Press::None, b.update(true, 6020));
}

void test_held_at_start_never_fires() {
  core::ButtonPress b;
  Count c = feed(b, true, 0, 20000);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
  c = feed(b, false, 20010, 21000);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
}

void test_short_hold_at_start_then_release_gives_nothing() {
  core::ButtonPress b;
  feed(b, true, 0, 300);
  TEST_ASSERT_EQUAL(0, feed(b, false, 310, 1000).shortP);
}

void test_press_after_boot_hold_works() {
  core::ButtonPress b;
  feed(b, true, 0, 3000);
  feed(b, false, 3010, 4000);
  TEST_ASSERT_EQUAL(1, feed(b, true, 4010, 10000).reset);
}

void test_reset_disabled_for_boot_button() {
  core::ButtonPress b(50, 1000, 3000, 5000, false);
  feed(b, false, 0, 1000);
  Count c = press(b, 1010, 8000);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
  Count s = press(b, 20000, 200);
  TEST_ASSERT_EQUAL(1, s.shortP);
}

// ---- bounce ----
void test_bounce_ignored() {
  auto b = ready();
  b.update(true, 1000);
  b.update(true, 1020);
  b.update(false, 1030);
  Count c = feed(b, false, 1040, 7000);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
}

void test_release_bounce_inside_press_ignored() {
  auto b = ready();
  feed(b, true, 1010, 3000);
  b.update(false, 3010);  // 10 ms glitch
  Count c = feed(b, true, 3020, 3500);
  TEST_ASSERT_EQUAL(0, c.shortP + c.longP + c.reset);
  TEST_ASSERT_EQUAL(1, feed(b, false, 3510, 4000).longP);  // still one press, 2.5 s
}

void test_press_bounce_then_short() {
  auto b = ready();
  b.update(true, 1010);
  b.update(false, 1020);
  b.update(true, 1030);
  Count c = feed(b, true, 1040, 1300);
  c.shortP += feed(b, false, 1310, 1500).shortP;
  TEST_ASSERT_EQUAL(1, c.shortP);
}

// ---- sampling gaps (blocking refresh) and wrap ----
void test_sparse_samples_classify_by_timestamps() {
  auto b = ready();
  TEST_ASSERT_EQUAL(Press::None, b.update(true, 2000));
  TEST_ASSERT_EQUAL(Press::None, b.update(true, 2060));
  TEST_ASSERT_EQUAL(Press::None, b.update(false, 2400));
  TEST_ASSERT_EQUAL(Press::Short, b.update(false, 5400));  // sampled 3 s later: still a 400 ms press
}

void test_second_press_works() {
  auto b = ready();
  TEST_ASSERT_EQUAL(1, press(b, 1010, 200).shortP);
  TEST_ASSERT_EQUAL(1, press(b, 3000, 1500).longP);
  TEST_ASSERT_EQUAL(1, press(b, 6000, 7000).reset);
}

void test_time_wraparound() {
  core::ButtonPress b;
  const uint32_t base = 0xFFFFFFFFu - 2000;
  feed(b, false, base, base + 500);
  int reset = 0;
  for (uint32_t i = 0; i <= 700; i++) reset += b.update(true, base + 600 + i * 10) == Press::Reset;
  TEST_ASSERT_EQUAL(1, reset);
  core::ButtonPress w;
  feed(w, false, base, base + 500);
  int longs = 0;
  for (uint32_t i = 0; i < 150; i++) longs += w.update(true, base + 600 + i * 10) == Press::Long;
  for (uint32_t i = 0; i < 20; i++) longs += w.update(false, base + 2100 + i * 10) == Press::Long;
  TEST_ASSERT_EQUAL(1, longs);
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_short_press);
  RUN_TEST(test_short_reported_on_release_only);
  RUN_TEST(test_short_long_boundary);
  RUN_TEST(test_long_press);
  RUN_TEST(test_long_upper_boundary);
  RUN_TEST(test_cancel_zone_gives_nothing);
  RUN_TEST(test_reset_once_while_held_and_nothing_on_release);
  RUN_TEST(test_reset_exactly_at_threshold);
  RUN_TEST(test_held_at_start_never_fires);
  RUN_TEST(test_short_hold_at_start_then_release_gives_nothing);
  RUN_TEST(test_press_after_boot_hold_works);
  RUN_TEST(test_reset_disabled_for_boot_button);
  RUN_TEST(test_bounce_ignored);
  RUN_TEST(test_release_bounce_inside_press_ignored);
  RUN_TEST(test_press_bounce_then_short);
  RUN_TEST(test_sparse_samples_classify_by_timestamps);
  RUN_TEST(test_second_press_works);
  RUN_TEST(test_time_wraparound);
  return UNITY_END();
}

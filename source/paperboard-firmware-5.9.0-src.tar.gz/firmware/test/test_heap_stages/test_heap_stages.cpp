#include <string.h>
#include <unity.h>

#include "heap_stages.h"

void setUp() {}
void tearDown() {}

void test_first_mark_wins() {
  core::HeapStages h;
  TEST_ASSERT_FALSE(h.has(core::HeapStage::Wifi));
  TEST_ASSERT_TRUE(h.mark(core::HeapStage::Wifi, 25000, 24000));
  TEST_ASSERT_FALSE(h.mark(core::HeapStage::Wifi, 100, 50));
  TEST_ASSERT_TRUE(h.has(core::HeapStage::Wifi));
  TEST_ASSERT_EQUAL_UINT32(25000, h.free(core::HeapStage::Wifi));
  TEST_ASSERT_EQUAL_UINT32(24000, h.maxBlock(core::HeapStage::Wifi));
}

void test_stages_independent_and_bounds() {
  core::HeapStages h;
  h.mark(core::HeapStage::Start, 1, 2);
  TEST_ASSERT_FALSE(h.has(core::HeapStage::Steady));
  TEST_ASSERT_FALSE(h.mark(core::HeapStage::Count, 1, 1));
  TEST_ASSERT_FALSE(h.has(core::HeapStage::Count));
}

void test_names() {
  TEST_ASSERT_EQUAL_STRING("start", core::HeapStages::name(core::HeapStage::Start));
  TEST_ASSERT_EQUAL_STRING("steady", core::HeapStages::name(core::HeapStage::Steady));
  TEST_ASSERT_EQUAL_STRING("?", core::HeapStages::name(core::HeapStage::Count));
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_first_mark_wins);
  RUN_TEST(test_stages_independent_and_bounds);
  RUN_TEST(test_names);
  return UNITY_END();
}

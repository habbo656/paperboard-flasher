#include <string.h>
#include <unity.h>

#include "setup_logic.h"

using namespace core;
using A = WifiLossPolicy::Action;

void setUp() {}
void tearDown() {}

static uint32_t counter = 0;
static uint32_t fakeRandom() { return counter++; }

void test_ap_name() {
  char buf[24];
  apName(buf, sizeof(buf), 0xa1b2c3);
  TEST_ASSERT_EQUAL_STRING("Paperboard-B2C3", buf);
  apName(buf, sizeof(buf), 0x00000a);
  TEST_ASSERT_EQUAL_STRING("Paperboard-000A", buf);
}

void test_password() {
  char pw[11];
  counter = 0;
  makePassword(pw, 10, fakeRandom);
  TEST_ASSERT_EQUAL_STRING("abcdefghij", pw);
  counter = 30;
  makePassword(pw, 4, fakeRandom);
  TEST_ASSERT_EQUAL_STRING("89ab", pw);  // wraps around the 32-char alphabet
  for (const char* p = pw; *p; p++) TEST_ASSERT_NULL(strchr("0O1lI", *p));
}

void test_qr_payload() {
  char buf[96];
  TEST_ASSERT_TRUE(wifiQrPayload(buf, sizeof(buf), "Paperboard-B2C3", "abcd2345"));
  TEST_ASSERT_EQUAL_STRING("WIFI:S:Paperboard-B2C3;T:WPA;P:abcd2345;;", buf);
  TEST_ASSERT_TRUE(wifiQrPayload(buf, sizeof(buf), "a;b", "p:w\\\""));
  TEST_ASSERT_EQUAL_STRING("WIFI:S:a\\;b;T:WPA;P:p\\:w\\\\\\\";;", buf);
  TEST_ASSERT_FALSE(wifiQrPayload(buf, 20, "Paperboard-B2C3", "abcd2345"));
  TEST_ASSERT_EQUAL_STRING("", buf);
}

void test_wifi_loss_policy() {
  WifiLossPolicy p(30, 10);  // ms for the test
  TEST_ASSERT_TRUE(p.update(true, 0) == A::None);
  TEST_ASSERT_TRUE(p.update(false, 100) == A::None);  // lost at 100
  TEST_ASSERT_TRUE(p.update(false, 129) == A::None);
  TEST_ASSERT_TRUE(p.update(false, 130) == A::OpenPortal);
  TEST_ASSERT_TRUE(p.portalOpen());
  TEST_ASSERT_TRUE(p.update(false, 139) == A::None);
  TEST_ASSERT_TRUE(p.update(false, 140) == A::ClosePortal);  // open for 10
  TEST_ASSERT_TRUE(p.update(false, 169) == A::None);
  TEST_ASSERT_TRUE(p.update(false, 170) == A::OpenPortal);  // again after 30
  TEST_ASSERT_TRUE(p.update(true, 172) == A::ClosePortal);  // reconnected
  TEST_ASSERT_TRUE(p.update(false, 200) == A::None);        // new loss starts counting from 200
  TEST_ASSERT_TRUE(p.update(false, 229) == A::None);
  TEST_ASSERT_TRUE(p.update(false, 230) == A::OpenPortal);
}

void test_wifi_loss_policy_millis_wraparound() {
  WifiLossPolicy p(30, 10);
  const uint32_t start = 0xFFFFFFF0u;
  p.update(false, start);
  TEST_ASSERT_TRUE(p.update(false, start + 29) == A::None);
  TEST_ASSERT_TRUE(p.update(false, start + 30) == A::OpenPortal);  // wraps past 0
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_ap_name);
  RUN_TEST(test_password);
  RUN_TEST(test_qr_payload);
  RUN_TEST(test_wifi_loss_policy);
  RUN_TEST(test_wifi_loss_policy_millis_wraparound);
  return UNITY_END();
}

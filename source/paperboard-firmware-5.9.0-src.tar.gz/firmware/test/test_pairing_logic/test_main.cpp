#include <unity.h>

#include "pairing_logic.h"

using namespace core;

void setUp() {}
void tearDown() {}

void test_token_validation() {
  TEST_ASSERT_TRUE(validToken("0123456789abcdef0123456789abcdef"));
  TEST_ASSERT_TRUE(validToken("AbC+/=_-0123456789"));
  TEST_ASSERT_FALSE(validToken(nullptr));
  TEST_ASSERT_FALSE(validToken("short"));
  TEST_ASSERT_FALSE(validToken("0123456789abcdef 0123"));  // space
  TEST_ASSERT_FALSE(validToken("0123456789abcdef\"0123"));
  TEST_ASSERT_FALSE(validToken("0123456789012345678901234567890123456789012345678901234567890123456789"));  // > 64
}

void test_url_validation() {
  TEST_ASSERT_TRUE(validHomeyUrl("http://192.168.1.10:8787/"));
  TEST_ASSERT_FALSE(validHomeyUrl("https://192.168.1.10:8787/"));
  TEST_ASSERT_FALSE(validHomeyUrl("http://192.168.1.10:8787"));  // no trailing slash
  TEST_ASSERT_FALSE(validHomeyUrl("http://a b/"));
  TEST_ASSERT_FALSE(validHomeyUrl(nullptr));
  TEST_ASSERT_FALSE(validHomeyUrl("http://"));
}

void test_frame_url() {
  char buf[64];
  TEST_ASSERT_TRUE(frameUrl(buf, sizeof(buf), "http://192.168.1.10:8787/"));
  TEST_ASSERT_EQUAL_STRING("http://192.168.1.10:8787/frame", buf);
  TEST_ASSERT_FALSE(frameUrl(buf, 10, "http://192.168.1.10:8787/"));
}

void test_event_url() {
  char buf[64];
  TEST_ASSERT_TRUE(eventUrl(buf, sizeof(buf), "http://192.168.1.10:8787/"));
  TEST_ASSERT_EQUAL_STRING("http://192.168.1.10:8787/event", buf);
  TEST_ASSERT_FALSE(eventUrl(buf, 10, "http://192.168.1.10:8787/"));
}

void test_bearer() {
  const char* token = "0123456789abcdef";
  TEST_ASSERT_TRUE(bearerMatches("Bearer 0123456789abcdef", token));
  TEST_ASSERT_FALSE(bearerMatches("Bearer 0123456789abcdeX", token));
  TEST_ASSERT_FALSE(bearerMatches("Bearer 0123456789abcdef0", token));
  TEST_ASSERT_FALSE(bearerMatches("Bearer 0123", token));
  TEST_ASSERT_FALSE(bearerMatches("0123456789abcdef", token));
  TEST_ASSERT_FALSE(bearerMatches(nullptr, token));
  TEST_ASSERT_FALSE(bearerMatches("Bearer ", ""));  // unpaired device has no token
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_token_validation);
  RUN_TEST(test_url_validation);
  RUN_TEST(test_frame_url);
  RUN_TEST(test_event_url);
  RUN_TEST(test_bearer);
  return UNITY_END();
}

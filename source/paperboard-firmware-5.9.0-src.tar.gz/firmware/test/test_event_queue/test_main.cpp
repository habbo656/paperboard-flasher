#include <unity.h>

#include "event_queue.h"

using namespace core;

void setUp() {}
void tearDown() {}

void test_push_and_due() {
  EventQueue q;
  q.seedSeq(17);
  TEST_ASSERT_TRUE(q.push((uint8_t)ButtonId::User, Press::Short, 1000));
  const ButtonEvent* e = q.due(1000);
  TEST_ASSERT_NOT_NULL(e);
  TEST_ASSERT_EQUAL(17, e->seq);
  TEST_ASSERT_EQUAL_STRING("user", buttonName(e->button));
  TEST_ASSERT_EQUAL_STRING("short", pressName(e->press));
  q.onSent(204, 1010);
  TEST_ASSERT_EQUAL(0, q.size());
  TEST_ASSERT_NULL(q.due(1010));
}

void test_only_short_long_accepted() {
  EventQueue q;
  TEST_ASSERT_FALSE(q.push(0, Press::None, 0));
  TEST_ASSERT_FALSE(q.push(0, Press::Reset, 0));
  TEST_ASSERT_TRUE(q.push(0, Press::Long, 0));
  TEST_ASSERT_NULL(pressName((uint8_t)Press::Reset));
  TEST_ASSERT_NULL(buttonName(7));
}

void test_full_queue_drops_new_event() {
  EventQueue q;
  q.seedSeq(1);
  for (int i = 0; i < 4; i++) TEST_ASSERT_TRUE(q.push(0, Press::Short, 100 + i));
  TEST_ASSERT_FALSE(q.push(0, Press::Long, 200));
  TEST_ASSERT_EQUAL(4, q.size());
  TEST_ASSERT_EQUAL(1, q.due(300)->seq);  // oldest first
  q.onSent(204, 300);
  TEST_ASSERT_EQUAL(2, q.due(300)->seq);
}

void test_expiry_30s() {
  EventQueue q;
  q.push(0, Press::Short, 1000);
  q.push(0, Press::Short, 20000);
  TEST_ASSERT_NOT_NULL(q.due(31000));  // exactly 30 s old: still sent
  TEST_ASSERT_EQUAL(2, q.size());
  const ButtonEvent* e = q.due(31001);
  TEST_ASSERT_NOT_NULL(e);
  TEST_ASSERT_EQUAL(1, q.size());
  TEST_ASSERT_EQUAL(1, e->seq);
  TEST_ASSERT_NULL(q.due(50001));
  TEST_ASSERT_EQUAL(0, q.size());
}

void test_retry_once_after_2s_with_same_seq() {
  EventQueue q;
  q.seedSeq(500);
  q.push(0, Press::Long, 1000);
  TEST_ASSERT_EQUAL(500, q.due(1000)->seq);
  q.onSent(-1, 1100);  // transport error
  TEST_ASSERT_EQUAL(1, q.size());
  TEST_ASSERT_NULL(q.due(3099));
  const ButtonEvent* e = q.due(3100);
  TEST_ASSERT_NOT_NULL(e);
  TEST_ASSERT_EQUAL(500, e->seq);
  q.onSent(503, 3200);  // second failure: dropped
  TEST_ASSERT_EQUAL(0, q.size());
}

void test_retry_then_success() {
  EventQueue q;
  q.push(0, Press::Short, 0);
  q.due(0);
  q.onSent(503, 10);
  q.due(2010);
  q.onSent(204, 2020);
  TEST_ASSERT_EQUAL(0, q.size());
}

void test_result_codes() {
  TEST_ASSERT_TRUE(eventResult(204) == EventResult::Done);
  static const int done[] = {400, 401, 404, 405, 429, 200, 302};
  for (int c : done) TEST_ASSERT_TRUE(eventResult(c) == EventResult::Done);
  static const int retry[] = {500, 502, 503, 599, -1, -11, 0};
  for (int c : retry) TEST_ASSERT_TRUE(eventResult(c) == EventResult::Retry);
}

void test_4xx_removes_without_retry() {
  EventQueue q;
  q.push(0, Press::Short, 0);
  q.due(0);
  q.onSent(429, 10);
  TEST_ASSERT_EQUAL(0, q.size());
}

void test_seq_wraps() {
  EventQueue q;
  q.seedSeq(65535);
  q.push(0, Press::Short, 0);
  q.push(0, Press::Short, 0);
  TEST_ASSERT_EQUAL(65535, q.due(0)->seq);
  q.onSent(204, 0);
  TEST_ASSERT_EQUAL(0, q.due(0)->seq);
}

void test_time_wraparound() {
  EventQueue q;
  const uint32_t t = 0xFFFFFFFFu - 500;
  q.push(0, Press::Short, t);
  TEST_ASSERT_NOT_NULL(q.due(t + 400));  // wrapped, 400 ms old
  q.onSent(-1, t + 400);
  TEST_ASSERT_NULL(q.due(t + 400 + 1999));
  TEST_ASSERT_NOT_NULL(q.due(t + 400 + 2000));
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_push_and_due);
  RUN_TEST(test_only_short_long_accepted);
  RUN_TEST(test_full_queue_drops_new_event);
  RUN_TEST(test_expiry_30s);
  RUN_TEST(test_retry_once_after_2s_with_same_seq);
  RUN_TEST(test_retry_then_success);
  RUN_TEST(test_result_codes);
  RUN_TEST(test_4xx_removes_without_retry);
  RUN_TEST(test_seq_wraps);
  RUN_TEST(test_time_wraparound);
  return UNITY_END();
}

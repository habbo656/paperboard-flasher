#pragma once
// Free heap per boot stage (#63, NFR-030): a tiny fixed table, filled once per stage, reported in /api/info
// ("bootHeap"). Pure data, unit-tested in test/test_heap_stages.

#include <stddef.h>
#include <stdint.h>

namespace core {

enum class HeapStage : uint8_t { Start, Display, Pairing, Wifi, Mdns, Api, Poll1, Steady, Count };

class HeapStages {
 public:
  static constexpr size_t COUNT = (size_t)HeapStage::Count;

  // Records the first sample of a stage; later calls for the same stage are ignored. Returns true if recorded.
  bool mark(HeapStage stage, uint32_t free, uint32_t maxBlock) {
    const size_t i = (size_t)stage;
    if (i >= COUNT || (set_ >> i) & 1u) return false;
    set_ |= (uint8_t)(1u << i);
    free_[i] = clamp(free);
    max_[i] = clamp(maxBlock);
    return true;
  }
  bool has(HeapStage stage) const { return (size_t)stage < COUNT && ((set_ >> (size_t)stage) & 1u); }
  uint32_t free(HeapStage stage) const { return free_[(size_t)stage]; }
  uint32_t maxBlock(HeapStage stage) const { return max_[(size_t)stage]; }
  static const char* name(HeapStage stage);

 private:
  static uint16_t clamp(uint32_t v) { return v > 0xFFFF ? 0xFFFF : (uint16_t)v; }  // heap < 64 KB: 33 B of bss
  uint8_t set_ = 0;
  uint16_t free_[COUNT] = {};
  uint16_t max_[COUNT] = {};
};

}  // namespace core

#pragma once
// Platform-independent OTA logic (FW-070, FW-074, NFR-026, IF-003, IF-005, ADR-18).
// Unit-tested in test/test_ota_logic.

#include <stddef.h>
#include <stdint.h>

namespace core {

constexpr size_t OTA_VERSION_MAX = 15;
constexpr uint32_t OTA_MIN_UPTIME_S = 60;                    // FW-074
constexpr uint32_t OTA_RETRY_HOLD_MS = 60UL * 60 * 1000;     // same version not retried within 1 h

// Heap guard before an update starts (FW-070, FW-055, #59).
constexpr uint32_t OTA_MIN_FREE_HEAP = 16384;
constexpr uint32_t OTA_MIN_MAX_BLOCK = 8192;
enum class OtaHeapAction { Proceed, Reboot, Refuse };
// Proceed: both values >= the thresholds. Reboot: below one and this boot was not a heap reboot for OTA.
// Refuse: still below after such a reboot (loop protection: at most one heap reboot per boot).
OtaHeapAction otaHeapAction(uint32_t freeHeap, uint32_t maxBlock, bool rebootedForOta);

struct OtaHint {
  char version[OTA_VERSION_MAX + 1];
  char md5[33];                     // lower-case hex
};

constexpr size_t OTA_BOARD_MAX = 16;  // board ID: [a-z0-9_]{1,16}

// X-Ota: "<version>;<path>;<md5>". Strict: invalid -> false, `out` unspecified.
// board == nullptr (API 2, D1 mini): path must be "/firmware/<version>.bin".
// board != nullptr (API 3): path must be "/firmware/<board>/<version>.bin" with exactly the device's own board
// segment (case-sensitive); the legacy path is rejected (ADR-20, IF-005, FW-070).
// The path is not stored: the device rebuilds it with otaUrl().
bool parseOtaHint(const char* header, OtaHint* out, const char* board);

// Compares "a.b.c" versions numerically: <0, 0, >0. Invalid input compares as 0.0.0.
int compareVersions(const char* a, const char* b);

// Test builds (tools/ota-test.sh) have PATCH >= OTA_TEST_PATCH (D-24, ADR-18). A device running one accepts any
// other version, so it returns to the bundled release without USB.
constexpr unsigned long OTA_TEST_PATCH = 900;
bool isTestVersion(const char* v);

// homey_url ("http://host:port/") + "firmware/<version>.bin" (board == nullptr) or
// "firmware/<board>/<version>.bin". Built from validated parts only (IF-005).
bool otaUrl(char* out, size_t cap, const char* homeyUrl, const char* version, const char* board);

// Header check of the first image bytes before anything is written to flash (NFR-012, ADR-18): needs n >= 24,
// magic 0xE9, and the ESP32 header chip_id (bytes 12..13 little-endian, ESP32-S3 = 9) must match the board.
// On an ESP8266 image those bytes are the low half of a 4-byte aligned segment size, never 9.
constexpr size_t OTA_HEADER_BYTES = 24;
bool otaImageMatches(const uint8_t* head, size_t n, bool esp32s3);

// "<version>;<reason>" (X-Ota-Result). Reason must match [a-z0-9-]{1,16}.
bool formatOtaResult(char* out, size_t cap, const char* version, const char* reason);

// Boot check after an OTA restart (FW-072, NFR-012): true when an attempt was recorded (`attempted`
// non-empty) and the running version is not the target, i.e. eboot did not install the new image.
bool otaBootFailed(const char* attempted, const char* running);

// Decides whether an offered update may start; remembers failures.
class OtaGuard {
 public:
  bool allowed(uint32_t nowMs, uint32_t uptimeS, const OtaHint& hint, const char* installed) const;
  void onFailure(uint32_t nowMs, const char* version);
  // Holds `version` until the next power cycle (no time limit); used after a failed boot (loop protection).
  void holdIndefinitely(const char* version);

 private:
  bool hasFailure_ = false;
  uint32_t failedAtMs_ = 0;
  char failedVersion_[OTA_VERSION_MAX + 1] = "";
  char heldVersion_[OTA_VERSION_MAX + 1] = "";
};

}  // namespace core

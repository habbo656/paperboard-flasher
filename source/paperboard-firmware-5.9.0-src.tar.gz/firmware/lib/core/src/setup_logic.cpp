#include "setup_logic.h"

#include <stdio.h>
#include <string.h>

namespace core {

void apName(char* out, size_t cap, uint32_t chipId) { snprintf(out, cap, "Paperboard-%04X", (unsigned)(chipId & 0xFFFF)); }

void makePassword(char* out, size_t length, uint32_t (*rnd)()) {
  static const char ALPHABET[] = "abcdefghijkmnpqrstuvwxyz23456789";  // 32 chars → no modulo bias
  for (size_t i = 0; i < length; i++) out[i] = ALPHABET[rnd() % (sizeof(ALPHABET) - 1)];
  out[length] = '\0';
}

static bool appendEscaped(char* out, size_t cap, size_t& pos, const char* s) {
  for (; *s; s++) {
    if (strchr("\\;,:\"", *s)) {
      if (pos + 1 >= cap) return false;
      out[pos++] = '\\';
    }
    if (pos + 1 >= cap) return false;
    out[pos++] = *s;
  }
  return true;
}

static bool appendRaw(char* out, size_t cap, size_t& pos, const char* s) {
  size_t n = strlen(s);
  if (pos + n >= cap) return false;
  memcpy(out + pos, s, n);
  pos += n;
  return true;
}

bool wifiQrPayload(char* out, size_t cap, const char* ssid, const char* password) {
  size_t pos = 0;
  bool ok = appendRaw(out, cap, pos, "WIFI:S:") && appendEscaped(out, cap, pos, ssid) &&
            appendRaw(out, cap, pos, ";T:WPA;P:") && appendEscaped(out, cap, pos, password) &&
            appendRaw(out, cap, pos, ";;");
  if (cap) out[ok ? pos : 0] = '\0';
  return ok;
}

WifiLossPolicy::Action WifiLossPolicy::update(bool connected, uint32_t nowMs) {
  if (connected) {
    waiting_ = false;
    if (portalOpen_) {
      portalOpen_ = false;
      return Action::ClosePortal;
    }
    return Action::None;
  }
  if (portalOpen_) {
    if (nowMs - since_ >= openFor_) {
      portalOpen_ = false;
      waiting_ = true;
      since_ = nowMs;
      return Action::ClosePortal;
    }
    return Action::None;
  }
  if (!waiting_) {
    waiting_ = true;
    since_ = nowMs;
  } else if (nowMs - since_ >= openAfter_) {
    portalOpen_ = true;
    since_ = nowMs;
    return Action::OpenPortal;
  }
  return Action::None;
}

}  // namespace core

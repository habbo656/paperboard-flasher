#pragma once
// Frame format negotiation and plane handling (IF-003, IF-021, FW-034, FW-101, ADR-20). Unit-tested in
// test/test_frame_format.

#include <stddef.h>
#include <stdint.h>

namespace core {

constexpr size_t PLANE_BYTES = 400 * 300 / 8;

// Number of planes of a response whose X-Frame-Format header is `hdr` (nullptr = header missing = "bw").
// Accepted: exactly "bw" (1 plane) and the board's own format `ownFmt` ("bw" or "bwr"; bwr = 2 planes).
// Anything else (case, whitespace, prefixes, empty, unknown) returns 0 = reject.
uint8_t framePlanes(const char* hdr, const char* ownFmt);

// Content-Length is exactly planes x PLANE_BYTES, fits the frame buffer, and is not chunked (-1).
bool frameLengthValid(long contentLength, uint8_t planes, size_t bufBytes);

// "Red wins" (ADR-20): where red ink is set (bit 0 in red), clear the black ink (set the bit to 1 = white).
void resolveRed(uint8_t* black, const uint8_t* red, size_t n);

}  // namespace core

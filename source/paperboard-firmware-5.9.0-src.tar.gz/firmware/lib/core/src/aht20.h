#pragma once
// AHT20 temperature/humidity sensor on the NM-EPD-420 (FW-081, FW-104, #80). Pure logic, no Arduino: frame
// decoding, CRC8, number formatting for the X-Temp/X-Hum headers (IF-003) and the read schedule.
// Unit-tested in test/test_aht20.

#include <stddef.h>
#include <stdint.h>

namespace core {

// CRC8 as in the AHT20 datasheet: polynomial 0x31, init 0xFF, no reflection, no final XOR.
uint8_t aht20Crc8(const uint8_t* data, size_t len);

// Decodes the 7-byte measurement frame (status, 5 data bytes, CRC). Accepts only a correct CRC, a clear busy bit
// (bit 7), a set calibrated bit (bit 3) and plausible values (-40.0..85.0 C, 0..100 %RH). Temperature in tenths of
// a degree, humidity in whole percent (rounded).
bool aht20Parse(const uint8_t f[7], int16_t* deciC, uint8_t* rhPct);

// Writes tenths of a degree as "21.4" / "-0.5" / "-40.0" (IF-003 X-Temp). Needs cap >= 7. False if it does not fit.
bool formatDeci(char* out, size_t cap, int16_t deciC);

// Read schedule (FW-081, FW-104): trigger a conversion every 60 s, read it >= 80 ms later, the last good reading
// counts as fresh for 180 s, a soft reset of the sensor is requested after 3 failed cycles in a row. All times are
// millis(); wrap-safe.
class ClimateSchedule {
 public:
  static constexpr uint32_t INTERVAL_MS = 60000;
  static constexpr uint32_t CONVERSION_MS = 80;
  static constexpr uint32_t STALE_MS = 180000;
  static constexpr uint8_t RESET_AFTER_FAILURES = 3;

  enum class Action : uint8_t { Idle, Trigger, Read };

  // What to do now. The first trigger is due immediately.
  Action next(uint32_t now) const;
  void triggered(uint32_t now);       // the trigger command was sent; a read is due after CONVERSION_MS
  void readOk(uint32_t now);          // a good frame was decoded
  void failed(uint32_t now);          // trigger, read or decode failed: ends the cycle
  bool takeSoftReset();               // true once after RESET_AFTER_FAILURES failures in a row
  bool fresh(uint32_t now) const;     // last good reading is not older than STALE_MS

 private:
  bool started_ = false;
  bool waiting_ = false;
  bool hasGood_ = false;
  bool resetPending_ = false;
  uint8_t failures_ = 0;
  uint32_t lastTrigger_ = 0;
  uint32_t lastGood_ = 0;
};

}  // namespace core

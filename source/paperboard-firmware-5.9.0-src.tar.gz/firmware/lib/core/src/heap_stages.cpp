#include "heap_stages.h"

namespace core {

const char* HeapStages::name(HeapStage stage) {
  static const char* const NAMES[] = {"start", "display", "pairing", "wifi", "mdns", "api", "poll1", "steady"};
  return (size_t)stage < COUNT ? NAMES[(size_t)stage] : "?";
}

}  // namespace core

#include "poll_logic.h"

#include <stdlib.h>

namespace core {

uint32_t clampPollSeconds(const char* header) {
  if (!header || !*header) return POLL_DEFAULT_S;
  char* end = nullptr;
  long v = strtol(header, &end, 10);
  if (end == header || *end != '\0' || v <= 0) return POLL_DEFAULT_S;
  if ((unsigned long)v < POLL_MIN_S) return POLL_MIN_S;
  if ((unsigned long)v > POLL_MAX_S) return POLL_MAX_S;
  return (uint32_t)v;
}

uint32_t backoffSeconds(uint32_t consecutiveFailures) {
  if (consecutiveFailures <= 1) return 15;
  if (consecutiveFailures == 2) return 30;
  return 60;
}

Rect parseStatusArea(const char* header, int16_t panelW, int16_t panelH) {
  Rect r;
  if (!header) return r;
  long v[4];
  const char* p = header;
  for (int i = 0; i < 4; i++) {
    char* end = nullptr;
    v[i] = strtol(p, &end, 10);
    if (end == p) return Rect();
    if (i < 3) {
      if (*end != ',') return Rect();
      p = end + 1;
    } else if (*end != '\0') {
      return Rect();
    }
  }
  if (v[0] < 0 || v[1] < 0 || v[2] <= 0 || v[3] <= 0 || v[0] + v[2] > panelW || v[1] + v[3] > panelH) return Rect();
  r.x = (int16_t)v[0];
  r.y = (int16_t)v[1];
  r.w = (int16_t)v[2];
  r.h = (int16_t)v[3];
  return r;
}

}  // namespace core

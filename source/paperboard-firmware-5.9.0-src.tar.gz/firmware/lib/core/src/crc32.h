#pragma once
// CRC-32 (IEEE 802.3, same as zlib) for frame integrity checks (FW-034).
// Incremental: crc = crc32Update(crc, chunk, len) starting with crc = 0.

#include <stddef.h>
#include <stdint.h>

uint32_t crc32Update(uint32_t crc, const uint8_t* data, size_t len);

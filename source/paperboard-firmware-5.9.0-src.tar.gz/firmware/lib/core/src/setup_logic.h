#pragma once
// Wi-Fi setup helpers (FW-001, FW-002, FW-005, FW-007). Unit-tested in test/test_setup_logic.

#include <stddef.h>
#include <stdint.h>

namespace core {

// "Paperboard-XXXX" with the last 4 hex digits of the chip ID (upper case).
void apName(char* out, size_t cap, uint32_t chipId);

// Random setup AP password of `length` characters from an unambiguous alphabet (no 0/O, 1/l/I).
// rnd() must return uniformly distributed 32-bit values (ESP8266 hardware RNG). out needs length+1 bytes.
void makePassword(char* out, size_t length, uint32_t (*rnd)());

// Wi-Fi QR payload "WIFI:S:<ssid>;T:WPA;P:<password>;;" with \ ; , : " escaped.
// Returns false if it does not fit into cap.
bool wifiQrPayload(char* out, size_t cap, const char* ssid, const char* password);

// When to open/close the setup portal after Wi-Fi loss (FW-007): open after `openAfterMs` without
// connection, keep it open for `openForMs` (or until connected), then wait `openAfterMs` again.
class WifiLossPolicy {
 public:
  enum class Action { None, OpenPortal, ClosePortal };
  WifiLossPolicy(uint32_t openAfterMs = 30UL * 60 * 1000, uint32_t openForMs = 10UL * 60 * 1000)
      : openAfter_(openAfterMs), openFor_(openForMs) {}
  Action update(bool connected, uint32_t nowMs);
  bool portalOpen() const { return portalOpen_; }

 private:
  uint32_t openAfter_, openFor_;
  bool portalOpen_ = false;
  bool waiting_ = false;    // disconnected, counting towards the next portal
  uint32_t since_ = 0;      // start of the current waiting or portal period
};

}  // namespace core

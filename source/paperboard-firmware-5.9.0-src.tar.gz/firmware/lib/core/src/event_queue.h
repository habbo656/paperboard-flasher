#pragma once
// Button event queue and retry policy for IF-004 (FW-080). Pure, unit-tested in test/test_event_queue.
// 4 slots (a full queue drops the NEW event), events older than 30 s are dropped, one retry after 2 s on a
// transport error or 5xx (same seq), any other status removes the event.

#include <stddef.h>
#include <stdint.h>

#include "button_press.h"

namespace core {

enum class ButtonId : uint8_t { User = 0, Boot = 1 };

constexpr size_t EVENT_QUEUE_SLOTS = 4;
constexpr uint32_t EVENT_EXPIRY_MS = 30000;
constexpr uint32_t EVENT_RETRY_MS = 2000;

struct ButtonEvent {
  uint8_t button;     // ButtonId
  uint8_t press;      // Press::Short | Press::Long
  uint16_t seq;
  uint8_t tries;      // requests already made
  uint32_t tMs;       // time of the press
  uint32_t retryAtMs; // earliest time of the next request
};

enum class EventResult : uint8_t { Done, Retry };
// 204, 4xx and anything unexpected -> Done (drop); transport error (code <= 0) and 5xx -> Retry.
EventResult eventResult(int httpCode);

// Literals for the headers X-Button / X-Press; nullptr for values that must not be sent.
const char* buttonName(uint8_t button);
const char* pressName(uint8_t press);

class EventQueue {
 public:
  // Adds an event with the next sequence number; false (and nothing stored) if the queue is full.
  bool push(uint8_t button, Press press, uint32_t nowMs);
  void expire(uint32_t nowMs);
  // The oldest event if it may be sent now (after expire), else nullptr.
  const ButtonEvent* due(uint32_t nowMs);
  // Reports the outcome of sending the event returned by due().
  void onSent(int httpCode, uint32_t nowMs);
  size_t size() const { return count_; }
  void seedSeq(uint16_t seq) { seq_ = seq; }

 private:
  ButtonEvent slots_[EVENT_QUEUE_SLOTS];
  size_t count_ = 0;
  uint16_t seq_ = 0;
  void popFront();
};

}  // namespace core

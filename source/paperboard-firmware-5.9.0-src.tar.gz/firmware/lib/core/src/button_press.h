#pragma once
// Button press classifier for the NM-EPD-420 USER button (FW-080, FW-102). Pure state machine, unit-tested in
// test/test_button_press. The active level of the button is a board constant: callers pass `pressed`.
//
// Debounced press length -> result:
//   < debounce          ignored (bounce)
//   debounce .. < long  Short, on release
//   long .. < cancel    Long, on release
//   cancel .. < reset   nothing (the user aimed for the reset and let go)
//   >= reset            Reset once, while still held; the release afterwards gives nothing
// Long comes only on release, so a reset press can never also send a long press.

#include <stdint.h>

namespace core {

enum class Press : uint8_t { None, Short, Long, Reset };

class ButtonPress {
 public:
  explicit ButtonPress(uint32_t debounceMs = 50, uint32_t longMs = 1000, uint32_t cancelMs = 3000,
                       uint32_t resetMs = 5000, bool resetEnabled = true)
      : debounceMs_(debounceMs), longMs_(longMs), cancelMs_(cancelMs), resetMs_(resetMs), resetEnabled_(resetEnabled) {}

  // Feed the (raw) button state with the current time; gaps between calls are fine (timestamps decide, wrap-safe).
  // A button already pressed at the first call (e.g. held at boot, GPIO45 is a strapping pin) never produces a
  // result: the machine arms only after a released state has been seen.
  Press update(bool pressed, uint32_t nowMs);

 private:
  uint32_t debounceMs_, longMs_, cancelMs_, resetMs_;
  bool resetEnabled_;
  bool started_ = false;
  bool raw_ = false;         // last raw sample
  bool stable_ = false;      // debounced state
  bool armed_ = false;       // current press began after a released state was seen
  bool fired_ = false;       // Reset already sent for the current press
  uint32_t rawSince_ = 0;    // time of the last raw change
  uint32_t pressStart_ = 0;  // time the current debounced press began
};

}  // namespace core

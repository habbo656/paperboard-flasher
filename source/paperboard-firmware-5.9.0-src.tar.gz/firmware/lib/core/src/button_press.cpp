#include "button_press.h"

namespace core {

Press ButtonPress::update(bool pressed, uint32_t nowMs) {
  if (!started_) {
    started_ = true;
    raw_ = stable_ = pressed;
    rawSince_ = pressStart_ = nowMs;
    armed_ = false;  // a button held at boot is never a press
    return Press::None;
  }
  if (pressed != raw_) {
    raw_ = pressed;
    rawSince_ = nowMs;
  }
  Press result = Press::None;
  if (raw_ != stable_ && nowMs - rawSince_ >= debounceMs_) {
    stable_ = raw_;
    if (stable_) {
      pressStart_ = rawSince_;
      fired_ = false;
      armed_ = true;
    } else {
      const uint32_t held = rawSince_ - pressStart_;  // release edge - press edge
      if (armed_ && !fired_) {
        if (held >= longMs_ && held < cancelMs_) result = Press::Long;
        else if (held < longMs_) result = Press::Short;
      }
      armed_ = false;
    }
  }
  if (stable_ && raw_ && armed_ && !fired_ && resetEnabled_ && nowMs - pressStart_ >= resetMs_) {
    fired_ = true;
    result = Press::Reset;
  }
  return result;
}

}  // namespace core

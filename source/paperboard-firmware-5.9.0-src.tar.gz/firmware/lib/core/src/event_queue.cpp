#include "event_queue.h"

namespace core {

EventResult eventResult(int httpCode) {
  if (httpCode <= 0 || (httpCode >= 500 && httpCode <= 599)) return EventResult::Retry;
  return EventResult::Done;
}

const char* buttonName(uint8_t button) {
  switch (button) {
    case (uint8_t)ButtonId::User: return "user";
    case (uint8_t)ButtonId::Boot: return "boot";
    default: return nullptr;
  }
}

const char* pressName(uint8_t press) {
  switch (press) {
    case (uint8_t)Press::Short: return "short";
    case (uint8_t)Press::Long: return "long";
    default: return nullptr;
  }
}

bool EventQueue::push(uint8_t button, Press press, uint32_t nowMs) {
  if (count_ >= EVENT_QUEUE_SLOTS || (press != Press::Short && press != Press::Long)) return false;
  slots_[count_++] = ButtonEvent{button, (uint8_t)press, seq_++, 0, nowMs, nowMs};
  return true;
}

void EventQueue::popFront() {
  for (size_t i = 1; i < count_; i++) slots_[i - 1] = slots_[i];
  if (count_) count_--;
}

void EventQueue::expire(uint32_t nowMs) {
  while (count_ && nowMs - slots_[0].tMs > EVENT_EXPIRY_MS) popFront();
}

const ButtonEvent* EventQueue::due(uint32_t nowMs) {
  expire(nowMs);
  if (!count_ || (int32_t)(nowMs - slots_[0].retryAtMs) < 0) return nullptr;
  return &slots_[0];
}

void EventQueue::onSent(int httpCode, uint32_t nowMs) {
  if (!count_) return;
  slots_[0].tries++;
  if (eventResult(httpCode) == EventResult::Done || slots_[0].tries >= 2) {
    popFront();
  } else {
    slots_[0].retryAtMs = nowMs + EVENT_RETRY_MS;
  }
}

}  // namespace core

#include "aht20.h"

namespace core {

uint8_t aht20Crc8(const uint8_t* data, size_t len) {
  uint8_t crc = 0xFF;
  for (size_t i = 0; i < len; i++) {
    crc ^= data[i];
    for (int b = 0; b < 8; b++) crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0x31) : (uint8_t)(crc << 1);
  }
  return crc;
}

bool aht20Parse(const uint8_t f[7], int16_t* deciC, uint8_t* rhPct) {
  if (f[0] & 0x80) return false;     // busy
  if (!(f[0] & 0x08)) return false;  // not calibrated
  if (aht20Crc8(f, 6) != f[6]) return false;
  const uint32_t rawH = ((uint32_t)f[1] << 12) | ((uint32_t)f[2] << 4) | (f[3] >> 4);
  const uint32_t rawT = ((uint32_t)(f[3] & 0x0F) << 16) | ((uint32_t)f[4] << 8) | f[5];
  // RH = raw / 2^20 * 100; T = raw / 2^20 * 200 - 50 (in tenths: raw * 2000 / 2^20 - 500), rounded
  const uint32_t rh = (uint32_t)(((uint64_t)rawH * 100 + (1u << 19)) >> 20);
  const int32_t dc = (int32_t)(((uint64_t)rawT * 2000 + (1u << 19)) >> 20) - 500;
  if (rh > 100 || dc < -400 || dc > 850) return false;
  *rhPct = (uint8_t)rh;
  *deciC = (int16_t)dc;
  return true;
}

bool formatDeci(char* out, size_t cap, int16_t deciC) {
  if (cap < 7) return false;
  size_t n = 0;
  int32_t v = deciC;
  if (v < 0) {
    out[n++] = '-';
    v = -v;
  }
  const int32_t whole = v / 10;
  if (whole >= 100) return false;
  if (whole >= 10) out[n++] = (char)('0' + whole / 10);
  out[n++] = (char)('0' + whole % 10);
  out[n++] = '.';
  out[n++] = (char)('0' + v % 10);
  out[n] = 0;
  return true;
}

ClimateSchedule::Action ClimateSchedule::next(uint32_t now) const {
  if (waiting_) return (uint32_t)(now - lastTrigger_) >= CONVERSION_MS ? Action::Read : Action::Idle;
  if (!started_ || (uint32_t)(now - lastTrigger_) >= INTERVAL_MS) return Action::Trigger;
  return Action::Idle;
}

void ClimateSchedule::triggered(uint32_t now) {
  started_ = true;
  waiting_ = true;
  lastTrigger_ = now;
}

void ClimateSchedule::readOk(uint32_t now) {
  waiting_ = false;
  hasGood_ = true;
  lastGood_ = now;
  failures_ = 0;
}

void ClimateSchedule::failed(uint32_t now) {
  if (!waiting_) {  // the trigger itself failed: the next try is due after a full interval
    started_ = true;
    lastTrigger_ = now;
  }
  waiting_ = false;
  if (!fresh(now)) hasGood_ = false;  // keeps a very old reading from looking fresh after a millis() wrap
  if (++failures_ >= RESET_AFTER_FAILURES) {
    failures_ = 0;
    resetPending_ = true;
  }
}

bool ClimateSchedule::takeSoftReset() {
  const bool r = resetPending_;
  resetPending_ = false;
  return r;
}

bool ClimateSchedule::fresh(uint32_t now) const { return hasGood_ && (uint32_t)(now - lastGood_) <= STALE_MS; }

}  // namespace core

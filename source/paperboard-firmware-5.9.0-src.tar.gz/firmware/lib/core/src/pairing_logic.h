#pragma once
// Pairing helpers (ADR-5, IF-011, IF-012, NFR-021, NFR-027). Unit-tested in test/test_pairing_logic.

#include <stddef.h>

namespace core {

constexpr size_t PAIR_TOKEN_MAX = 64;
constexpr size_t PAIR_URL_MAX = 128;
constexpr size_t PAIR_NAME_MAX = 32;

// Token: 16…64 chars of [A-Za-z0-9_-+/=] (hex or base64); URL: "http://…" ending with '/', ≤ 128 chars.
bool validToken(const char* token);
bool validHomeyUrl(const char* url);

// "<homey_url>frame" into out; false if it does not fit.
bool frameUrl(char* out, size_t cap, const char* homeyUrl);

// "<homey_url>event" into out (IF-004); false if it does not fit.
bool eventUrl(char* out, size_t cap, const char* homeyUrl);

// Checks "Bearer <token>" against the stored token in constant time (no early exit on mismatch).
bool bearerMatches(const char* authorizationHeader, const char* token);

}  // namespace core

#include "crc32.h"

// Bitwise implementation: no 1 KB lookup table in RAM; ~0.2 s for a 15 000-byte frame is acceptable.
uint32_t crc32Update(uint32_t crc, const uint8_t* data, size_t len) {
  crc = ~crc;
  while (len--) {
    crc ^= *data++;
    for (int k = 0; k < 8; k++) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
  }
  return ~crc;
}

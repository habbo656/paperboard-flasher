#include "ota_logic.h"

#include <stdio.h>
#include <string.h>

namespace core {

static bool isDigit(char c) { return c >= '0' && c <= '9'; }

static bool validVersion(const char* v, size_t n) {
  if (n == 0 || n > OTA_VERSION_MAX) return false;
  int dots = 0;
  bool digitSeen = false;
  for (size_t i = 0; i < n; i++) {
    if (isDigit(v[i])) {
      digitSeen = true;
    } else if (v[i] == '.' && digitSeen && dots < 2) {
      dots++;
      digitSeen = false;
    } else {
      return false;
    }
  }
  return dots == 2 && digitSeen;
}

static bool validBoard(const char* b) {
  if (!b) return false;
  const size_t n = strlen(b);
  if (n < 1 || n > OTA_BOARD_MAX) return false;
  for (size_t i = 0; i < n; i++) {
    const char c = b[i];
    if (!((c >= 'a' && c <= 'z') || isDigit(c) || c == '_')) return false;
  }
  return true;
}

static int otaPath(char* out, size_t cap, const char* version, int vn, const char* board) {
  if (board) return snprintf(out, cap, "/firmware/%s/%.*s.bin", board, vn, version);
  return snprintf(out, cap, "/firmware/%.*s.bin", vn, version);
}

bool parseOtaHint(const char* header, OtaHint* out, const char* board) {
  if (!header || !out) return false;
  if (board && !validBoard(board)) return false;
  const char* semi1 = strchr(header, ';');
  if (!semi1) return false;
  const size_t vn = (size_t)(semi1 - header);
  if (!validVersion(header, vn)) return false;
  const char* pathStart = semi1 + 1;
  const char* semi2 = strchr(pathStart, ';');
  if (!semi2) return false;
  char expected[OTA_BOARD_MAX + OTA_VERSION_MAX + 16];
  const int en = otaPath(expected, sizeof(expected), header, (int)vn, board);
  if (en <= 0 || (size_t)en >= sizeof(expected) || (size_t)(semi2 - pathStart) != (size_t)en ||
      strncmp(pathStart, expected, (size_t)en) != 0)
    return false;
  const char* md5 = semi2 + 1;
  if (strlen(md5) != 32) return false;
  for (int i = 0; i < 32; i++) {
    const char c = md5[i];
    const bool hex = isDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    if (!hex) return false;
    out->md5[i] = (c >= 'A' && c <= 'F') ? (char)(c - 'A' + 'a') : c;
  }
  out->md5[32] = 0;
  memcpy(out->version, header, vn);
  out->version[vn] = 0;
  return true;
}

static void parseVersion(const char* v, unsigned long parts[3]) {
  parts[0] = parts[1] = parts[2] = 0;
  if (!v || !validVersion(v, strlen(v))) return;
  sscanf(v, "%lu.%lu.%lu", &parts[0], &parts[1], &parts[2]);
}

int compareVersions(const char* a, const char* b) {
  unsigned long pa[3], pb[3];
  parseVersion(a, pa);
  parseVersion(b, pb);
  for (int i = 0; i < 3; i++) {
    if (pa[i] != pb[i]) return pa[i] < pb[i] ? -1 : 1;
  }
  return 0;
}

bool isTestVersion(const char* v) {
  unsigned long p[3];
  parseVersion(v, p);
  return p[2] >= OTA_TEST_PATCH;
}

bool otaUrl(char* out, size_t cap, const char* homeyUrl, const char* version, const char* board) {
  if (!homeyUrl || !version || !validVersion(version, strlen(version))) return false;
  if (board && !validBoard(board)) return false;
  char path[OTA_BOARD_MAX + OTA_VERSION_MAX + 16];
  const int pn = otaPath(path, sizeof(path), version, (int)strlen(version), board);
  if (pn <= 0 || (size_t)pn >= sizeof(path)) return false;
  const int n = snprintf(out, cap, "%s%s", homeyUrl, path + 1);  // homey_url ends with '/'
  return n > 0 && (size_t)n < cap;
}

bool otaImageMatches(const uint8_t* head, size_t n, bool esp32s3) {
  if (!head || n < OTA_HEADER_BYTES || head[0] != 0xE9) return false;
  const unsigned chipId = (unsigned)head[12] | ((unsigned)head[13] << 8);
  return (chipId == 9) == esp32s3;
}

bool formatOtaResult(char* out, size_t cap, const char* version, const char* reason) {
  if (!version || !reason || !validVersion(version, strlen(version))) return false;
  const size_t rn = strlen(reason);
  if (rn < 1 || rn > 16) return false;
  for (size_t i = 0; i < rn; i++) {
    const char c = reason[i];
    if (!((c >= 'a' && c <= 'z') || isDigit(c) || c == '-')) return false;
  }
  const int n = snprintf(out, cap, "%s;%s", version, reason);
  return n > 0 && (size_t)n < cap;
}

OtaHeapAction otaHeapAction(uint32_t freeHeap, uint32_t maxBlock, bool rebootedForOta) {
  if (freeHeap >= OTA_MIN_FREE_HEAP && maxBlock >= OTA_MIN_MAX_BLOCK) return OtaHeapAction::Proceed;
  return rebootedForOta ? OtaHeapAction::Refuse : OtaHeapAction::Reboot;
}

bool OtaGuard::allowed(uint32_t nowMs, uint32_t uptimeS, const OtaHint& hint, const char* installed) const {
  if (uptimeS < OTA_MIN_UPTIME_S) return false;
  const int cmp = compareVersions(hint.version, installed);
  if (cmp == 0 || (cmp < 0 && !isTestVersion(installed))) return false;  // no downgrade, except off a test build
  if (heldVersion_[0] && strcmp(heldVersion_, hint.version) == 0) return false;
  if (hasFailure_ && strcmp(failedVersion_, hint.version) == 0 && (uint32_t)(nowMs - failedAtMs_) < OTA_RETRY_HOLD_MS)
    return false;
  return true;
}

void OtaGuard::holdIndefinitely(const char* version) {
  strncpy(heldVersion_, version, sizeof(heldVersion_) - 1);
  heldVersion_[sizeof(heldVersion_) - 1] = 0;
}

bool otaBootFailed(const char* attempted, const char* running) {
  return attempted && attempted[0] && strcmp(attempted, running ? running : "") != 0;
}

void OtaGuard::onFailure(uint32_t nowMs, const char* version) {
  hasFailure_ = true;
  failedAtMs_ = nowMs;
  strncpy(failedVersion_, version, sizeof(failedVersion_) - 1);
  failedVersion_[sizeof(failedVersion_) - 1] = 0;
}

}  // namespace core

// Board layer for the WeMos D1 mini (ESP8266), see board.h. Behaviour identical to the pre-ADR-19 code.
#include "board.h"

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>
#include <LittleFS.h>
#include <user_interface.h>

namespace board {

const char* const ID = "d1_mini";
const char* const FRAME_FORMAT = "bw";
const char* const PANEL = "GxEPD2_420";
const char* const RESET_HINT = "press RESET twice";

void begin() {}

uint32_t chipId() { return ESP.getChipId(); }

const char* resetReason() {
  switch (ESP.getResetInfoPtr()->reason) {
    case REASON_DEFAULT_RST: return "power-on";
    case REASON_WDT_RST: return "hw-watchdog";
    case REASON_EXCEPTION_RST: return "exception";
    case REASON_SOFT_WDT_RST: return "sw-watchdog";
    case REASON_SOFT_RESTART: return "restart";
    case REASON_DEEP_SLEEP_AWAKE: return "deep-sleep";
    case REASON_EXT_SYS_RST: return "reset-button";
    default: return "unknown";
  }
}

uint32_t freeHeap() { return ESP.getFreeHeap(); }
uint32_t maxBlock() { return ESP.getMaxFreeBlockSize(); }
void restart() {
  ESP.restart();
  for (;;) {}
}
void hardReset() {
  ESP.reset();
  for (;;) {}
}
uint32_t hwRandom() { return os_random(); }
void otaConfirm() {}

// RTC user memory, blocks of 4 B. 64..95 are the eboot command (never use, see firmware/CLAUDE.md).
static uint32_t rtcBlock(Rtc slot) {
  switch (slot) {
    case Rtc::Health: return 96;       // 96–97
    case Rtc::Ota: return 98;          // 98–106
    default: return 110;               // 110–111 double reset
  }
}
void rtcRead(Rtc slot, void* data, size_t bytes) { system_rtc_mem_read(rtcBlock(slot), data, bytes); }
void rtcWrite(Rtc slot, const void* data, size_t bytes) {
  system_rtc_mem_write(rtcBlock(slot), const_cast<void*>(data), bytes);
}

void wifiDrop() { wifi_station_disconnect(); }
bool wifiCredentialsSaved() {  // same check as WiFiManager::getWiFiIsSaved() (unchanged behaviour)
  station_config conf;
  wifi_station_get_config_default(&conf);
  return conf.ssid[0] != 0;
}
void wifiModemSleep() { WiFi.setSleepMode(WIFI_MODEM_SLEEP); }

bool fsBegin() { return LittleFS.begin(); }

static MDNSResponder::hMDNSService service = nullptr;
bool mdnsBegin(const char* host) { return MDNS.begin(host); }
void mdnsAddService(const char* name, uint16_t port) { service = MDNS.addService(nullptr, name, "tcp", port); }
void mdnsTxt(const char* key, const char* value) {
  if (service) MDNS.addServiceTxt(service, key, value);
}
void mdnsTxtReplace(const char* key, const char* value) {
  if (!service) return;
  MDNS.removeServiceTxt(service, key);
  MDNS.addServiceTxt(service, key, value);
}
void mdnsAnnounce() {
  if (service) MDNS.announce();
}
void mdnsUpdate() { MDNS.update(); }
void mdnsEnd() {
  MDNS.end();
  service = nullptr;
}

// Double reset detection (FW-008): a flag in RTC memory is armed at boot and cleared after 3 s.
// A reset while it is armed (RESET pressed twice within 3 s) triggers the factory reset.
static constexpr uint32_t DRD_MAGIC = 0x44524431;  // "DRD1"
static constexpr uint32_t DRD_TIMEOUT_MS = 3000;
static bool drdArmed = false;

static void drdWrite(uint32_t value) {
  uint32_t data[2] = {DRD_MAGIC, value};
  rtcWrite(Rtc::DoubleReset, data, sizeof(data));
}

bool factoryResetAtBoot() {
  uint32_t data[2] = {0, 0};
  rtcRead(Rtc::DoubleReset, data, sizeof(data));
  const bool detected = data[0] == DRD_MAGIC && data[1] == 1;
  drdWrite(1);  // arm for this boot
  drdArmed = true;
  return detected;
}

void loop() {
  if (drdArmed && millis() > DRD_TIMEOUT_MS) {
    drdWrite(0);
    drdArmed = false;
  }
}

bool factoryResetRequested() { return false; }

}  // namespace board

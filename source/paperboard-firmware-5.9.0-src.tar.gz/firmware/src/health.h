#pragma once
// Robustness: loop watchdog, heap guard and reset reason (FW-054, FW-055, FW-060, FW-062).

#include <stdint.h>

#include "heap_stages.h"

namespace health {

// Call once in setup(): arms the loop watchdog and determines the reset reason.
void begin();

// Call regularly from loop(); if not called for 60 s the device restarts (FW-054).
void feed();

// Checks free heap / largest block; restarts in a controlled way when too low (FW-055).
void checkHeap();

// Restarts into the freshly flashed image; the next boot reports reset reason "ota" (FW-072).
void restartForOta();

// Controlled restart because an update is waiting but heap is below the OTA guard (#59); reported as "heap".
void restartForOtaHeap();

// True only for the boot right after restartForOtaHeap() (loop protection: one heap reboot per boot).
bool rebootedForOtaHeap();

// Reason of the last reboot, e.g. "power-on", "exception", "watchdog", "heap" (X-Reset-Reason).
const char* resetReason();

// "free/largestBlock" in bytes (X-Free-Heap).
const char* heapReport();

// Records free heap / largest block for a boot stage, first call per stage wins; logs "[heap] <stage> <free>/<max>" (#63).
void heapMark(core::HeapStage stage);

// Table of the recorded stages for /api/info ("bootHeap", IF-010).
const core::HeapStages& bootHeap();

}  // namespace health

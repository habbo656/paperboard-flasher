#pragma once
// Network library aliases per board (ADR-19): shared modules include this instead of ESP8266_/ESP32 headers.

#if defined(PB_BOARD_D1_MINI)
#include <ESP8266HTTPClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <Updater.h>
using HttpServer = ESP8266WebServer;
inline void httpConnectTimeout(HTTPClient&, int32_t) {}  // ESP8266: connect uses setTimeout()
#else
#include <HTTPClient.h>
#include <WebServer.h>
#include <WiFi.h>
#include <Update.h>
using HttpServer = WebServer;
inline void httpConnectTimeout(HTTPClient& http, int32_t ms) { http.setConnectTimeout(ms); }  // default 5 s
#endif

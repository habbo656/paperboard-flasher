#pragma once
// Wi-Fi provisioning and connection handling (FW-001…008, ADR-9): WiFiManager captive portal with a
// password-protected AP, setup screen with QR code, setup portal after Wi-Fi loss, double-reset factory reset.

#include <stdint.h>

namespace connectivity {

// Call once in setup() after display::begin(): handles a double reset, starts setup mode when no
// Wi-Fi is stored, otherwise connects with the stored credentials.
void begin();

// Call from loop(): runs the portal and the Wi-Fi loss policy.
void loop();

// Station connected to the home Wi-Fi (polling allowed).
bool online();

// A setup portal is open (initial setup or after Wi-Fi loss); it uses port 80.
bool portalActive();

#ifdef PB_DEBUG
// Drops the Wi-Fi connection and shortens the loss policy to 30 s / 60 s (tests FW-007).
void debugSimulateWifiLoss();
// Drops Wi-Fi for `ms` without touching the loss policy, then reconnects (like a router outage).
void debugDropWifi(uint32_t ms);
#endif

}  // namespace connectivity

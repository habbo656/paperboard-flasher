// Paperboard firmware – entry point. Modules are added per milestone (docs/implementation-plan.md).

#include <Arduino.h>
#include "board.h"
#include "connectivity.h"
#include "device_api.h"
#include "display.h"
#include "events.h"
#include "health.h"
#include "ota.h"
#include "pairing.h"
#include "poller.h"
#include "screens.h"
#include "version.h"

#ifdef PB_DEBUG
// Debug commands over serial (development builds only): h = hang the loop (tests the loop watchdog,
// FW-054), m = eat heap (tests the heap guard, FW-055), o = show offline icon (FW-051),
// u = age last success by 30 min (FW-052), w = simulate Wi-Fi loss (FW-007),
// d = drop Wi-Fi for 6 min (router outage, FW-051), r = print heap,
// p = test pattern black/red/both on a bwr board (FW-101), x = corrupt the MD5 of the next OTA (FW-072),
// b / B = inject a short / long USER press event (FW-080, IF-004),
// l = allocate 512 B blocks until free heap < 14 000 B (between FW-055 and OTA thresholds, #59).
static void debugCommands() {
  static void* eaten[64];
  static size_t n = 0;
  while (Serial.available()) {
    const int c = Serial.read();
    switch (c) {
      case 'h':
        Serial.println(F("[debug] hanging the loop"));
        for (;;) delay(100);  // yields, so only our loop watchdog can catch it
      case 'm':
        while (n < 64 && (eaten[n] = malloc(2048)) != nullptr) n++;
        Serial.printf_P(PSTR("[debug] allocated %u x 2 KB, free heap %u\n"), n, (unsigned)board::freeHeap());
        break;
      case 'l':
        while (n < 64 && board::freeHeap() >= 14000 && (eaten[n] = malloc(512)) != nullptr) n++;
        Serial.printf_P(PSTR("[debug] %u blocks held, heap %s\n"), (unsigned)n, health::heapReport());
        break;
      case 'b':
      case 'B':
        events::debugInject(c == 'B');
        break;
      case 'o':
        poller::debugShowOffline();
        break;
      case 'u':
        poller::debugAgeLastSuccess();
        break;
      case 'w':
        connectivity::debugSimulateWifiLoss();
        break;
      case 'd':
        connectivity::debugDropWifi(6UL * 60 * 1000);
        break;
      case 'p':
        poller::debugTestPattern();
        break;
      case 'x':
        ota::debugCorruptNextMd5();
        break;
      case 't':
        board::debugClimateFail();
        Serial.println(F("[debug] AHT20 reads suppressed for 5 min"));
        break;
      case 'r':
        Serial.printf_P(PSTR("[debug] heap %s, reset reason %s\n"), health::heapReport(), health::resetReason());
        if (board::HAS_CLIMATE) {
          int16_t t = 0;
          uint8_t h = 0;
          const bool ok = board::climate(&t, &h);
          Serial.printf_P(PSTR("[debug] sensor %s, last reading %s %d.%d C %u %%\n"), board::climateState(),
                          ok ? "fresh" : "stale/none", t / 10, abs(t % 10), (unsigned)h);
        }
        break;
    }
  }
}
#endif

void setup() {
  Serial.begin(115200);
  board::begin();
  health::heapMark(core::HeapStage::Start);
  delay(100);
  health::begin();
  ota::begin();
  Serial.printf_P(PSTR("\n[main] Paperboard firmware %s, chip %06x, reset: %s\n"), FW_VERSION, (unsigned)board::chipId(),
                health::resetReason());
  display::begin();
  health::heapMark(core::HeapStage::Display);
  pairing::begin();
  health::heapMark(core::HeapStage::Pairing);
  connectivity::begin();
  poller::begin();
}

void loop() {
  health::feed();
#ifdef PB_DEBUG
  debugCommands();
#endif
  connectivity::loop();
  if (connectivity::online()) health::heapMark(core::HeapStage::Wifi);
  device_api::loop();
  board::climateLoop();  // FW-081: non-blocking, no-op on the D1 mini
  if (millis() >= 300000UL) health::heapMark(core::HeapStage::Steady);  // 5 min uptime (#63)
  if (!connectivity::portalActive()) {
    // Poll also without Wi-Fi: failures must be counted for the offline icon (FW-051)
    if (pairing::isPaired()) {
      events::loop(connectivity::online());  // FW-080: button events, outside the poll
      poller::loop();
    }
    else if (connectivity::online() && !screens::addToHomeyShown()) screens::showAddToHomey();  // FW-006
  }
  delay(20);
}

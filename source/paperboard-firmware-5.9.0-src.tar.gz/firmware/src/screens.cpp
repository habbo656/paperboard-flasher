#include "screens.h"

#include "board.h"
#include "board_net.h"
#include "display.h"
#include "pairing.h"
#include "poller.h"
#include "setup_logic.h"

namespace screens {

static constexpr int SCREEN_ADD = 1;

void showAddToHomey() {
  static char apLine[40], wifiLine[48], ipLine[40];
  char ap[24];
  core::apName(ap, sizeof(ap), board::chipId());
  snprintf_P(apLine, sizeof(apLine), PSTR("3. Select %s"), ap);
  snprintf_P(wifiLine, sizeof(wifiLine), PSTR("Wi-Fi: %s"), WiFi.SSID().c_str());
  snprintf_P(ipLine, sizeof(ipLine), PSTR("IP: %s"), WiFi.localIP().toString().c_str());
  const char* lines[] = {PSTR("1. Open the Homey app"), PSTR("2. Devices > + > Paperboard"), apLine, PSTR("Known? Homey: device > Repair"), wifiLine, ipLine};
  poller::invalidateFrame();
  display::showMessage(PSTR("Add Paperboard in Homey"), lines, 6, SCREEN_ADD);
}

bool addToHomeyShown() { return display::lastScreen() == SCREEN_ADD; }

void showPaired() {
  static char nameLine[48];
  snprintf_P(nameLine, sizeof(nameLine), PSTR("Name: %s"), *pairing::name() ? pairing::name() : "-");
  const char* lines[] = {nameLine, nullptr, PSTR("Loading the dashboard...")};
  poller::invalidateFrame();
  display::showMessage(PSTR("Paired with Homey"), lines, 3);
}

}  // namespace screens

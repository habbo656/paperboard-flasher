#include "health.h"

#include <Arduino.h>
#include <Ticker.h>

#include "board.h"

namespace health {

static constexpr uint32_t LOOP_TIMEOUT_MS = 60000;
static constexpr uint32_t MIN_FREE_HEAP = 12000;
static constexpr uint32_t MIN_MAX_BLOCK = 6000;

// Reason for our own software restarts, kept in RTC memory across the reboot.
// Storage: board::Rtc::Health (D1: RTC blocks 96–97; 64..95 are the eboot command, see firmware/CLAUDE.md).
static constexpr uint32_t MAGIC = 0x50425244;  // "PBRD"
enum Custom : uint32_t { NONE = 0, LOOP_WATCHDOG = 1, LOW_HEAP = 2, OTA = 3, OTA_HEAP = 4 };
struct RtcReason {
  uint32_t magic;
  uint32_t reason;
};

static Ticker ticker;
static volatile uint32_t lastFeed = 0;
static volatile bool watchdogFired = false;
static const char* reason = "unknown";
static bool otaHeapReboot = false;
static char heapBuf[24];
static core::HeapStages stages;

static void restartWith(Custom r) {
  RtcReason data{MAGIC, r};
  board::rtcWrite(board::Rtc::Health, &data, sizeof(data));
  board::restart();
}

static void onTick() {
  // Ticker callbacks run in the system context: only set a flag here, but if the loop is stuck the
  // flag is never handled → hard restart after a grace period.
  if (millis() - lastFeed > LOOP_TIMEOUT_MS) {
    if (!watchdogFired) {
      watchdogFired = true;
      RtcReason data{MAGIC, LOOP_WATCHDOG};
      board::rtcWrite(board::Rtc::Health, &data, sizeof(data));
    } else {
      board::hardReset();
    }
  }
}

void begin() {
  RtcReason data{};
  board::rtcRead(board::Rtc::Health, &data, sizeof(data));
  if (data.magic == MAGIC && data.reason == LOOP_WATCHDOG) reason = "watchdog";
  else if (data.magic == MAGIC && data.reason == LOW_HEAP) reason = "heap";
  else if (data.magic == MAGIC && data.reason == OTA_HEAP) {
    reason = "heap";
    otaHeapReboot = true;
  } else if (data.magic == MAGIC && data.reason == OTA) reason = "ota";  // FW-072
  else reason = board::resetReason();
  RtcReason clear{MAGIC, NONE};
  board::rtcWrite(board::Rtc::Health, &clear, sizeof(clear));
  lastFeed = millis();
  ticker.attach_ms(5000, onTick);
}

void feed() {
  lastFeed = millis();
  if (watchdogFired) restartWith(LOOP_WATCHDOG);  // loop came back after the timeout: restart cleanly
}

// The FW-055 thresholds (12 000 / 6 000) are deliberately below the OTA guard (16 384 / 8 192): a reboot costs a
// full panel refresh, so it is only taken when an update is actually waiting (#59, see restartForOtaHeap()).
void checkHeap() {
  if (board::freeHeap() < MIN_FREE_HEAP || board::maxBlock() < MIN_MAX_BLOCK) {
    Serial.printf_P(PSTR("[health] low heap: free %u, max block %u -> restart\n"), board::freeHeap(), board::maxBlock());
    restartWith(LOW_HEAP);
  }
}

void restartForOta() {
  Serial.flush();
  restartWith(OTA);
}

void restartForOtaHeap() {
  Serial.flush();
  restartWith(OTA_HEAP);
}

bool rebootedForOtaHeap() { return otaHeapReboot; }

const char* resetReason() { return reason; }

const char* heapReport() {
  snprintf_P(heapBuf, sizeof(heapBuf), PSTR("%u/%u"), board::freeHeap(), board::maxBlock());
  return heapBuf;
}

void heapMark(core::HeapStage stage) {
  const uint32_t f = board::freeHeap(), m = board::maxBlock();
  if (stages.mark(stage, f, m)) Serial.printf_P(PSTR("[heap] %s %u/%u\n"), core::HeapStages::name(stage), f, m);
}

const core::HeapStages& bootHeap() { return stages; }

}  // namespace health

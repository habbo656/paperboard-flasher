#pragma once
// Pairing state persisted in LittleFS (/pairing.json): token, Homey base URL, device name (FW-022, ADR-5).

namespace pairing {

// Mounts LittleFS (formats it on first use) and loads the pairing.
void begin();

bool isPaired();
const char* token();     // "" when unpaired
const char* homeyUrl();  // e.g. "http://192.168.1.10:8787/"
const char* name();      // name given in Homey, may be ""

// Stores a new pairing (IF-011). Returns false if storing failed.
bool pair(const char* token, const char* homeyUrl, const char* name);

// Updates the Homey base URL (IF-012).
bool setHomeyUrl(const char* homeyUrl);

// Removes the pairing (factory reset, device deleted in Homey – FW-023).
void clear();

}  // namespace pairing

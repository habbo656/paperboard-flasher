#pragma once
// Poll loop (FW-030…036, FW-050, FW-051, FW-060, IF-003): fetches the frame from the Homey app,
// updates the panel when it changed, handles errors with backoff and shows the offline state.

namespace poller {

void begin();

// Call from loop(); polls when due (blocking for the duration of one HTTP request).
void loop();

// Poll as soon as possible (pairing, config change, kick endpoint IF-013).
void kick();

// A local screen replaced the frame: the next poll fetches the frame again (no If-None-Match).
void invalidateFrame();

#ifdef PB_DEBUG
// Shows the offline icon immediately (tests its removal on the next successful poll).
void debugShowOffline();
// Pretends the last successful poll was 30 min ago (tests the "Homey not reachable" screen).
void debugAgeLastSuccess();
// Draws black / red / both-inked squares and a border through the normal frame path (bwr boards only).
void debugTestPattern();
#endif

}  // namespace poller

#pragma once
// Local screens around pairing (FW-006, FW-022, FW-023). Each screen replaces the frame on the panel,
// so the poller is told to fetch the frame again afterwards.

namespace screens {

// "Add Paperboard in the Homey app" with device name and IP – shown while connected but unpaired.
void showAddToHomey();
bool addToHomeyShown();

// "Paired with Homey" right after pairing (the first frame follows within seconds).
void showPaired();

}  // namespace screens

#pragma once
// OTA firmware update (FW-070…072, FW-074, NFR-012, NFR-026, IF-005, ADR-18): streams the image offered by
// the Homey app into the free flash slot, checks the MD5 from the authenticated poll response and reboots.

#include "ota_logic.h"

namespace ota {

// Call once at boot (after health::begin): detects a failed OTA boot, restores the hold from RTC.
void begin();

// Called by the poller after the poll's HTTP client is closed. Starts the update when the guard allows it
// (newer version, uptime >= 60 s, no recent failure). Returns only if no update was applied.
// Returns true when an update was attempted and failed (a local screen replaced the frame).
bool offer(const core::OtaHint& hint);

// Confirms the running image (board::otaConfirm) once per boot, on the first answered poll (NFR-012).
void confirmBoot();

#ifdef PB_DEBUG
// Debug 'x': flips one hex digit of the MD5 of the next accepted hint (tests the wrong-MD5 failure, FW-072).
void debugCorruptNextMd5();
#endif

// "<version>;<reason>" of a failed attempt not yet reported (X-Ota-Result), or "" (IF-003).
const char* pendingResult();
void clearPendingResult();

}  // namespace ota

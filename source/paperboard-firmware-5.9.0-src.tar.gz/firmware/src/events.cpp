#include "events.h"

#include <Arduino.h>

#include "board.h"
#include "board_net.h"
#include "event_queue.h"
#include "pairing.h"
#include "pairing_logic.h"

namespace events {

static constexpr uint32_t EVENT_TIMEOUT_MS = 2000;  // not the 10 s poll timeout: must never stall the loop for long

static core::EventQueue queue;
static bool seeded = false;

static int post(const core::ButtonEvent& e) {
  if (WiFi.status() != WL_CONNECTED) return -1;
  char url[core::PAIR_URL_MAX + 8];
  char value[8];
  const char* button = core::buttonName(e.button);
  const char* press = core::pressName(e.press);
  if (!button || !press || !core::eventUrl(url, sizeof(url), pairing::homeyUrl())) return 400;  // not retryable
  WiFiClient client;
  HTTPClient http;
  http.setTimeout(EVENT_TIMEOUT_MS);
  httpConnectTimeout(http, EVENT_TIMEOUT_MS);
  if (!http.begin(client, url)) return 400;
  http.addHeader(F("Authorization"), String("Bearer ") + pairing::token());
  http.addHeader(F("X-Api-Version"), String(board::API_VERSION));
  http.addHeader(F("X-Board"), board::ID);
  http.addHeader(F("X-Button"), button);
  http.addHeader(F("X-Press"), press);
  snprintf_P(value, sizeof(value), PSTR("%u"), (unsigned)e.seq);
  http.addHeader(F("X-Event-Seq"), value);
  const int code = http.POST((uint8_t*)nullptr, 0);  // no body, Content-Length: 0
  http.end();
  Serial.printf_P(PSTR("[btn] %s %s seq %u -> %d\n"), button, press, (unsigned)e.seq, code);  // never token or URL
  return code;
}

void loop(bool online) {
  if (!board::HAS_BUTTONS) return;
  if (!seeded) {
    seeded = true;
    queue.seedSeq((uint16_t)board::hwRandom());
  }
  uint8_t button, press;
  while (board::popButtonEvent(&button, &press)) {
    if (!queue.push(button, (core::Press)press, millis())) Serial.println(F("[btn] queue full, press dropped"));
  }
  if (!online) {
    queue.expire(millis());
    return;
  }
  const core::ButtonEvent* e = queue.due(millis());
  if (e) queue.onSent(post(*e), millis());
}

#ifdef PB_DEBUG
void debugInject(bool isLong) {
  if (!board::HAS_BUTTONS) return;
  queue.push((uint8_t)core::ButtonId::User, isLong ? core::Press::Long : core::Press::Short, millis());
}
#endif

}  // namespace events

#include "ota.h"

#include "board.h"
#include "board_net.h"
#include "display.h"
#include "health.h"
#include "pairing.h"
#include "pairing_logic.h"
#include "version.h"

namespace ota {

static constexpr uint32_t READ_TIMEOUT_MS = 10000;
static constexpr uint32_t TOTAL_TIMEOUT_MS = 120000;

static core::OtaGuard guard;
static char pending[32] = "";
static bool confirmed = false;
#ifdef PB_DEBUG
static bool corruptMd5 = false;
void debugCorruptNextMd5() {
  corruptMd5 = true;
  Serial.println(F("[debug] next OTA MD5 will be corrupted"));
}
#endif
static uint8_t chunk[1024];  // static: no heap during the update

// Boot state in RTC (survives restarts, not power loss): board::Rtc::Ota (D1: blocks 98..106).
static constexpr uint32_t RTC_MAGIC = 0x4F544131;  // "OTA1"
struct RtcState {
  uint32_t magic;
  char attempted[core::OTA_VERSION_MAX + 1];  // target of an update that ended in a restart
  char held[core::OTA_VERSION_MAX + 1];       // version that failed to boot: not offered again
};
static_assert(sizeof(RtcState) % 4 == 0 && sizeof(RtcState) <= 36, "RTC writes need whole blocks, slot is 9 blocks");

static void saveState(const char* attempted, const char* held) {
  RtcState s{};
  s.magic = RTC_MAGIC;
  strncpy(s.attempted, attempted, sizeof(s.attempted) - 1);
  strncpy(s.held, held, sizeof(s.held) - 1);
  board::rtcWrite(board::Rtc::Ota, &s, sizeof(s));
}

// FW-072, NFR-012: eboot did not install the image -> report "<target>;boot" and hold the version.
void begin() {
  RtcState s{};
  board::rtcRead(board::Rtc::Ota, &s, sizeof(s));
  if (s.magic != RTC_MAGIC) {
    memset(&s, 0, sizeof(s));
  }
  s.attempted[core::OTA_VERSION_MAX] = 0;
  s.held[core::OTA_VERSION_MAX] = 0;
  if (core::otaBootFailed(s.attempted, FW_VERSION)) {
    Serial.printf_P(PSTR("[ota] %s did not boot (running %s)\n"), s.attempted, FW_VERSION);
    strncpy(s.held, s.attempted, sizeof(s.held) - 1);
    core::formatOtaResult(pending, sizeof(pending), s.held, "boot");
  }
  if (s.held[0]) guard.holdIndefinitely(s.held);
  saveState("", s.held);
}

const char* pendingResult() { return pending; }
void clearPendingResult() { pending[0] = 0; }

void confirmBoot() {
  if (confirmed) return;
#ifdef PB_OTA_NO_CONFIRM  // test builds: simulate an image that cannot poll (rollback test, NFR-012)
  if (millis() > 30000) board::restart();  // software reset: the RTC OTA state survives
  return;
#else
  confirmed = true;
  board::otaConfirm();
#endif
}

// Returns nullptr on success, else the short reason (matches [a-z0-9-]{1,16}).
static const char* download(const core::OtaHint& hint, char* reasonBuf, size_t reasonCap) {
  if (board::freeHeap() < core::OTA_MIN_FREE_HEAP || board::maxBlock() < core::OTA_MIN_MAX_BLOCK) return "heap";
  static char url[core::PAIR_URL_MAX + 52];
  const char* boardSeg = board::API_VERSION >= 3 ? board::ID : nullptr;
  if (!core::otaUrl(url, sizeof(url), pairing::homeyUrl(), hint.version, boardSeg)) return "download";

  WiFiClient client;
  HTTPClient http;
  http.setTimeout(READ_TIMEOUT_MS);
  if (!http.begin(client, url)) return "download";
  http.addHeader(F("Authorization"), String("Bearer ") + pairing::token());
  http.addHeader(F("X-Api-Version"), String(board::API_VERSION));
  const int code = http.GET();
  if (code != HTTP_CODE_OK) {
    snprintf(reasonBuf, reasonCap, code > 0 ? "http-%d" : "download", code);
    http.end();
    return reasonBuf;
  }
  const int size = http.getSize();
  if (size <= 0 || (uint32_t)size > board::OTA_MAX_BYTES || (uint32_t)size > ESP.getFreeSketchSpace()) {
    http.end();
    return size > 0 ? "size" : "download";
  }
  if (!Update.begin((size_t)size)) {
    http.end();
    Update.end(true);
    return "space";
  }
  char md5[sizeof(hint.md5)];
  memcpy(md5, hint.md5, sizeof(md5));
#ifdef PB_DEBUG
  if (corruptMd5) {
    corruptMd5 = false;
    md5[0] = md5[0] == '0' ? '1' : '0';
  }
#endif
  Update.setMD5(md5);  // from the authenticated poll response, not from the download
  bool headChecked = false;
  size_t headFill = 0;

  WiFiClient* stream = http.getStreamPtr();
  size_t done = 0;
  const uint32_t start = millis();
  uint32_t lastData = start;
  while (done < (size_t)size) {
    const uint32_t now = millis();
    if (now - start > TOTAL_TIMEOUT_MS || now - lastData > READ_TIMEOUT_MS) break;
    health::feed();
    const size_t avail = stream->available();
    if (!avail) {
      if (!stream->connected()) break;
      delay(1);
      continue;
    }
    size_t want = size - done;
    if (want > sizeof(chunk)) want = sizeof(chunk);
    if (want > avail) want = avail;
    const size_t n = stream->readBytes(chunk, want);
    if (!n) continue;
    lastData = millis();
    if (!headChecked) {
      // NFR-012: the image header must be this chip's, checked before the first byte is written. `chunk` is
      // filled to >= 24 B first (reads may return fewer bytes at a time).
      headFill = n;
      while (headFill < core::OTA_HEADER_BYTES && done + headFill < (size_t)size) {
        if (millis() - lastData > READ_TIMEOUT_MS) break;
        health::feed();
        const size_t more = stream->readBytes(chunk + headFill, core::OTA_HEADER_BYTES - headFill);
        headFill += more;
        if (!more) delay(1);
      }
      if (!core::otaImageMatches(chunk, headFill, board::IMAGE_ESP32S3)) {
        http.end();
        Update.end(true);
        return "board";
      }
      headChecked = true;
      if (Update.write(chunk, headFill) != headFill) {
        http.end();
        Update.end(true);
        return "flash";
      }
      done += headFill;
      continue;
    }
    if (Update.write(chunk, n) != n) {
      http.end();
      Update.end(true);
      return "flash";
    }
    done += n;
  }
  http.end();
  if (done != (size_t)size) {
    Update.end(true);
    return "download";
  }
  if (!Update.end()) {  // verifies the MD5 (NFR-012); the old firmware stays active on failure
    return Update.getError() == UPDATE_ERROR_MD5 ? "md5" : "flash";
  }
  return nullptr;
}

bool offer(const core::OtaHint& hint) {
  if (!guard.allowed(millis(), millis() / 1000, hint, FW_VERSION)) return false;

  // #59: heap below the OTA guard -> one controlled reboot first, the update is taken after it (FW-074).
  const uint32_t freeHeap = board::freeHeap(), maxBlock = board::maxBlock();
  const core::OtaHeapAction action = core::otaHeapAction(freeHeap, maxBlock, health::rebootedForOtaHeap());
  if (action == core::OtaHeapAction::Reboot) {
    Serial.printf_P(PSTR("[ota] low heap %u/%u -> restart before update to %s\n"), (unsigned)freeHeap, (unsigned)maxBlock,
                  hint.version);
    health::restartForOtaHeap();  // does not return
    return false;
  }
  if (action == core::OtaHeapAction::Refuse) {
    Serial.printf_P(PSTR("[ota] heap %u/%u still low after restart, refused\n"), (unsigned)freeHeap, (unsigned)maxBlock);
    guard.onFailure(millis(), hint.version);
    core::formatOtaResult(pending, sizeof(pending), hint.version, "heap");
    return false;  // no screen, frame unchanged: the update never started
  }

  Serial.printf_P(PSTR("[ota] updating %s -> %s \n"), FW_VERSION, hint.version);  // never log the token
  static char versionLine[40];
  snprintf_P(versionLine, sizeof(versionLine), PSTR("Version %s -> %s"), FW_VERSION, hint.version);
  const char* lines[] = {versionLine, PSTR("Do not unplug the power."), PSTR("The display restarts when done.")};
  display::showMessage(PSTR("Updating firmware..."), lines, 3);  // FW-071 (one full refresh)
  health::feed();

  char reasonBuf[17] = "";
  const char* reason = download(hint, reasonBuf, sizeof(reasonBuf));
  if (!reason) {
    Serial.println(F("[ota] image verified, restarting"));
    saveState(hint.version, "");  // checked at the next boot
    health::restartForOta();  // does not return
    return false;
  }
  Serial.printf_P(PSTR("[ota] failed: %s\n"), reason);
  guard.onFailure(millis(), hint.version);
  core::formatOtaResult(pending, sizeof(pending), hint.version, reason);
  static char reasonLine[48];
  snprintf_P(reasonLine, sizeof(reasonLine), PSTR("Reason: %s"), reason);
  const char* fail[] = {reasonLine, PSTR("The old firmware keeps running.")};
  display::showMessage(PSTR("Firmware update failed"), fail, 2);
  return true;
}

}  // namespace ota

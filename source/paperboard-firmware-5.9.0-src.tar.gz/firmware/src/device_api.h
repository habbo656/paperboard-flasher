#pragma once
// Device side of discovery and pairing (FW-020…022, IF-010…013, IF-020): mDNS announcement
// `_paperboard._tcp` and a small HTTP server on port 80. Runs only while connected to the home Wi-Fi
// and no setup portal is open (the portal uses port 80 as well).

namespace device_api {

// Call from loop(): starts/stops server and mDNS as needed and handles requests.
void loop();

// Updates the "paired" TXT record after pairing or unpairing.
void announcePaired(bool paired);

}  // namespace device_api

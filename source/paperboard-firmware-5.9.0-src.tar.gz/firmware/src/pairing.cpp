#include "pairing.h"

#include <ArduinoJson.h>
#include <LittleFS.h>

#include "board.h"
#include "pairing_logic.h"

namespace pairing {

static const char* FILE_PATH = "/pairing.json";
static char tokenBuf[core::PAIR_TOKEN_MAX + 1] = "";
static char urlBuf[core::PAIR_URL_MAX + 1] = "";
static char nameBuf[core::PAIR_NAME_MAX + 1] = "";

static bool save() {
  File f = LittleFS.open(FILE_PATH, "w");
  if (!f) return false;
  JsonDocument doc;
  doc["token"] = tokenBuf;
  doc["homey_url"] = urlBuf;
  doc["name"] = nameBuf;
  const bool ok = serializeJson(doc, f) > 0;
  f.close();
  return ok;
}

void begin() {
  if (!board::fsBegin()) {
    Serial.println(F("[pair] LittleFS mount failed"));
    return;
  }
  File f = LittleFS.open(FILE_PATH, "r");
  if (!f) {
    Serial.println(F("[pair] not paired"));
    return;
  }
  JsonDocument doc;
  const DeserializationError err = deserializeJson(doc, f);
  f.close();
  const char* t = doc["token"] | "";
  const char* u = doc["homey_url"] | "";
  if (err || !core::validToken(t) || !core::validHomeyUrl(u)) {
    Serial.println(F("[pair] stored pairing invalid -> ignored"));
    return;
  }
  strlcpy(tokenBuf, t, sizeof(tokenBuf));
  strlcpy(urlBuf, u, sizeof(urlBuf));
  strlcpy(nameBuf, doc["name"] | "", sizeof(nameBuf));
  Serial.printf_P(PSTR("[pair] paired with %s as '%s'\n"), urlBuf, nameBuf);
}

bool isPaired() { return tokenBuf[0] != '\0'; }
const char* token() { return tokenBuf; }
const char* homeyUrl() { return urlBuf; }
const char* name() { return nameBuf; }

bool pair(const char* t, const char* u, const char* n) {
  strlcpy(tokenBuf, t, sizeof(tokenBuf));
  strlcpy(urlBuf, u, sizeof(urlBuf));
  strlcpy(nameBuf, n ? n : "", sizeof(nameBuf));
  return save();
}

bool setHomeyUrl(const char* u) {
  strlcpy(urlBuf, u, sizeof(urlBuf));
  return save();
}

void clear() {
  tokenBuf[0] = urlBuf[0] = nameBuf[0] = '\0';
  LittleFS.remove(FILE_PATH);
  Serial.println(F("[pair] pairing cleared"));
}

}  // namespace pairing

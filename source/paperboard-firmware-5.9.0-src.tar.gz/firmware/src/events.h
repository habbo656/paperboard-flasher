#pragma once
// Button events (FW-080, IF-004): classified USER presses are queued and sent at once as `POST <homey_url>event`,
// outside the poll. NM-EPD-420 only; on the D1 mini everything here compiles to nothing (board::HAS_BUTTONS).

namespace events {

// Call from loop() when paired: moves new presses into the queue and, when online, sends at most one request
// (2 s timeout, one retry after 2 s on a transport error or 5xx, events expire after 30 s).
void loop(bool online);

#ifdef PB_DEBUG
// Queues a synthetic short / long USER press (debug command b / B).
void debugInject(bool isLong);
#endif

}  // namespace events

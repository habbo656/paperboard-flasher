#include "sound.h"

#include <string.h>

namespace core {

namespace {

const char* const NAMES[CHIME_COUNT] = {"ding", "dingdong", "triple", "alert"};

struct Note {
  uint16_t freq;      // Hz, 0 = rest
  uint16_t ms;
  bool flat;          // true: constant level with a 10 ms release (alert), false: decaying bell
};

// Peak amplitude 0.7 of full scale: the loud level of the owner's listening test (N-14).
constexpr int32_t PEAK = 22937;

const Note DING[] = {{1319, 1200, false}};
const Note DINGDONG[] = {{988, 500, false}, {784, 900, false}};
const Note TRIPLE[] = {{1047, 220, false}, {0, 30, false}, {1319, 220, false}, {0, 30, false}, {1568, 400, false}};
const Note ALERT[] = {{880, 150, true}, {0, 100, false}, {660, 150, true}, {0, 100, false},
                      {880, 150, true}, {0, 100, false}, {660, 150, true}};

struct Chime {
  const Note* notes;
  uint8_t count;
};
const Chime CHIMES[CHIME_COUNT] = {
    {DING, sizeof DING / sizeof DING[0]},
    {DINGDONG, sizeof DINGDONG / sizeof DINGDONG[0]},
    {TRIPLE, sizeof TRIPLE / sizeof TRIPLE[0]},
    {ALERT, sizeof ALERT / sizeof ALERT[0]},
};

// Quarter wave of a sine, 0..pi/2 in 65 steps (full scale 32767); the other quadrants by symmetry.
const int16_t QUARTER[65] = {
    0, 804, 1608, 2410, 3212, 4011, 4808, 5602, 6393, 7179, 7962, 8739, 9512,
    10278, 11039, 11793, 12539, 13279, 14010, 14732, 15446, 16151, 16846, 17530, 18204, 18868,
    19519, 20159, 20787, 21403, 22005, 22594, 23170, 23731, 24279, 24811, 25329, 25832, 26319,
    26790, 27245, 27683, 28105, 28510, 28898, 29268, 29621, 29956, 30273, 30571, 30852, 31113,
    31356, 31580, 31785, 31971, 32137, 32285, 32412, 32521, 32609, 32678, 32728, 32757, 32767};

int32_t sine(uint32_t phase) {
  const uint32_t idx = phase >> 24;  // 0..255
  const uint32_t q = idx >> 6, p = idx & 63;
  switch (q) {
    case 0: return QUARTER[p];
    case 1: return QUARTER[64 - p];
    case 2: return -QUARTER[p];
    default: return -QUARTER[64 - p];
  }
}

uint32_t noteSamples(const Note& n) { return (uint32_t)n.ms * (SOUND_RATE_HZ / 1000); }

}  // namespace

bool parseSound(const char* v, uint8_t* chime, uint8_t* volume) {
  if (!v) return false;
  const char* semi = strchr(v, ';');
  if (!semi) return false;
  const size_t nameLen = (size_t)(semi - v);
  int found = -1;
  for (uint8_t i = 0; i < CHIME_COUNT; i++)
    if (strlen(NAMES[i]) == nameLen && memcmp(NAMES[i], v, nameLen) == 0) found = i;
  if (found < 0) return false;
  const char* d = semi + 1;
  size_t digits = 0;
  uint32_t vol = 0;
  while (d[digits] >= '0' && d[digits] <= '9' && digits < 4) vol = vol * 10 + (uint32_t)(d[digits++] - '0');
  if (digits < 1 || digits > 3 || d[digits] != 0 || vol < 1 || vol > 100) return false;
  *chime = (uint8_t)found;
  *volume = (uint8_t)vol;
  return true;
}

uint8_t volumeToDac(uint8_t volume) {
  if (volume == 0) return DAC_VOL_MUTE;
  if (volume > 100) volume = 100;
  return (uint8_t)(DAC_VOL_MIN + ((uint32_t)(volume - 1) * (DAC_VOL_MAX - DAC_VOL_MIN) + 49) / 99);
}

const char* chimeName(uint8_t chime) { return chime < CHIME_COUNT ? NAMES[chime] : "?"; }

uint32_t ChimeSynth::totalSamples(uint8_t chime) {
  if (chime >= CHIME_COUNT) return 0;
  uint32_t t = 0;
  for (uint8_t i = 0; i < CHIMES[chime].count; i++) t += noteSamples(CHIMES[chime].notes[i]);
  return t;
}

bool ChimeSynth::start(uint8_t chime) {
  if (chime >= CHIME_COUNT) return false;
  chime_ = chime;
  note_ = 0;
  pos_ = 0;
  phase_ = 0;
  active_ = true;
  return true;
}

size_t ChimeSynth::render(int16_t* out, size_t maxSamples) {
  size_t n = 0;
  while (active_ && n < maxSamples) {
    const Chime& c = CHIMES[chime_];
    if (note_ >= c.count) {
      active_ = false;
      break;
    }
    const Note& note = c.notes[note_];
    const uint32_t len = noteSamples(note);
    if (pos_ >= len) {  // next note; the phase restarts at 0 so every note begins at a zero crossing
      note_++;
      pos_ = 0;
      phase_ = 0;
      continue;
    }
    int32_t s = 0;
    if (note.freq) {
      const uint32_t left = len - 1 - pos_;  // 0 at the last sample of the note -> exactly 0 there
      int64_t env;                           // 0..65536
      if (note.flat) {
        const uint32_t rel = 10 * (SOUND_RATE_HZ / 1000), att = rel;
        env = 65536;
        if (left < rel) env = (int64_t)65536 * left / rel;
        if (pos_ < att) env = env * pos_ / att;
      } else {
        const uint32_t att = 4 * (SOUND_RATE_HZ / 1000);  // 4 ms attack, then a quadratic decay to 0
        const int64_t d = (int64_t)65536 * left / len;
        env = d * d / 65536;
        if (pos_ < att) env = env * pos_ / att;
      }
      s = (int32_t)((int64_t)sine(phase_) * PEAK / 32767 * env / 65536);
      phase_ += (uint32_t)(((uint64_t)note.freq << 32) / SOUND_RATE_HZ);
    }
    out[n++] = (int16_t)s;
    pos_++;
  }
  if (active_ && note_ >= CHIMES[chime_].count) active_ = false;
  return n;
}

}  // namespace core

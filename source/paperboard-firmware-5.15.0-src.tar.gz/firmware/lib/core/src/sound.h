#pragma once
// Built-in chimes for the NM-EPD-420 speaker (FW-106, IF-003 X-Sound, #83). Platform-independent: header parser,
// volume map and a tiny synthesizer (sine table + note table + decay envelope), unit-tested in test/test_sound.
// The board layer feeds the samples to the ES8311 over I2S (board_nm_epd_420.cpp). No Arduino dependencies.

#include <stddef.h>
#include <stdint.h>

namespace core {

constexpr uint8_t CHIME_COUNT = 4;                 // ding, dingdong, triple, alert (index 0..3, IF-003 order)
constexpr uint32_t SOUND_RATE_HZ = 16000;
constexpr uint32_t CHIME_MAX_MS = 1500;
constexpr uint8_t DAC_VOL_MUTE = 0x00;             // ES8311 reg 0x32: 0x00 = mute, 0xBF = 0 dB, 0.5 dB per step
constexpr uint8_t DAC_VOL_MIN = 0x5F;              // volume 1   (-48 dB)
constexpr uint8_t DAC_VOL_MAX = 0xBF;              // volume 100 (0 dB, the loud level of the N-14 listening test)

// "<chime>;<volume>": chime one of ding|dingdong|triple|alert (exact), volume 1..3 digits, 1..100. Anything else
// (null, empty, spaces, sign, unknown name, volume 0 or > 100, trailing text) -> false and outputs untouched.
bool parseSound(const char* v, uint8_t* chime, uint8_t* volume);

// 1..100 -> ES8311 DAC volume register, linear in dB (logarithmic in amplitude), monotonic; 0 -> mute.
uint8_t volumeToDac(uint8_t volume);

const char* chimeName(uint8_t chime);              // for logs ("?" if out of range)

// Renders one chime as mono int16 samples at SOUND_RATE_HZ, block by block. Every note decays (or is flat with a
// short release) and ends exactly at 0, so there is no click at the end.
class ChimeSynth {
 public:
  bool start(uint8_t chime);                       // false for an unknown chime
  size_t render(int16_t* out, size_t maxSamples);  // returns samples written, 0 when finished
  bool done() const { return !active_; }
  static uint32_t totalSamples(uint8_t chime);     // length of a chime

 private:
  uint8_t chime_ = 0;
  uint8_t note_ = 0;
  uint32_t pos_ = 0;       // sample position inside the current note
  uint32_t phase_ = 0;     // 32 bit phase accumulator
  bool active_ = false;
};

}  // namespace core

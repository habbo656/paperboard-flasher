// FW-106, IF-003: X-Sound parser, volume map, synthesizer.
#include <stdlib.h>
#include <unity.h>

#include "sound.h"

void setUp() {}
void tearDown() {}

static void ok(const char* s, uint8_t chime, uint8_t vol) {
  uint8_t c = 99, v = 99;
  TEST_ASSERT_TRUE_MESSAGE(core::parseSound(s, &c, &v), s);
  TEST_ASSERT_EQUAL_UINT8(chime, c);
  TEST_ASSERT_EQUAL_UINT8(vol, v);
}
static void bad(const char* s) {
  uint8_t c = 77, v = 77;
  TEST_ASSERT_FALSE_MESSAGE(core::parseSound(s, &c, &v), s ? s : "(null)");
  TEST_ASSERT_EQUAL_UINT8(77, c);
  TEST_ASSERT_EQUAL_UINT8(77, v);
}

void test_parse_valid() {
  ok("ding;50", 0, 50);
  ok("dingdong;1", 1, 1);
  ok("triple;100", 2, 100);
  ok("alert;007", 3, 7);
}

void test_parse_invalid() {
  bad(nullptr);
  bad("");
  bad("ding");
  bad("ding;");
  bad("ding;0");
  bad("ding;101");
  bad("ding;1000");
  bad("ding;-5");
  bad("ding;+5");
  bad("ding; 5");
  bad("ding;5 ");
  bad("ding;5x");
  bad("Ding;50");
  bad("dingdon;50");
  bad("ding2;50");
  bad("beep;50");
  bad(";50");
  bad("ding;50;60");
}

void test_volume_map() {
  TEST_ASSERT_EQUAL_UINT8(core::DAC_VOL_MUTE, core::volumeToDac(0));
  TEST_ASSERT_EQUAL_UINT8(core::DAC_VOL_MIN, core::volumeToDac(1));
  TEST_ASSERT_EQUAL_UINT8(core::DAC_VOL_MAX, core::volumeToDac(100));
  TEST_ASSERT_EQUAL_UINT8(core::DAC_VOL_MAX, core::volumeToDac(200));
  for (int v = 2; v <= 100; v++) TEST_ASSERT_TRUE(core::volumeToDac((uint8_t)v) >= core::volumeToDac((uint8_t)(v - 1)));
  TEST_ASSERT_TRUE(core::volumeToDac(100) > core::volumeToDac(50));
  TEST_ASSERT_TRUE(core::volumeToDac(50) > core::volumeToDac(1));
}

// Renders a chime in odd-sized blocks (block boundaries must not matter).
static size_t renderAll(uint8_t chime, int16_t* buf, size_t cap, size_t block) {
  core::ChimeSynth s;
  TEST_ASSERT_TRUE(s.start(chime));
  size_t n = 0;
  while (!s.done()) {
    const size_t got = s.render(buf + n, n + block > cap ? cap - n : block);
    TEST_ASSERT_TRUE(n + got <= cap);
    n += got;
    if (!got && !s.done()) TEST_FAIL_MESSAGE("render stalled");
  }
  TEST_ASSERT_EQUAL_UINT32(0, s.render(buf, 8));
  return n;
}

void test_synth_length_peak_and_end() {
  static int16_t a[core::SOUND_RATE_HZ * 2], b[core::SOUND_RATE_HZ * 2];
  for (uint8_t c = 0; c < core::CHIME_COUNT; c++) {
    const size_t n = renderAll(c, a, sizeof a / 2, 128);
    TEST_ASSERT_EQUAL_UINT32(core::ChimeSynth::totalSamples(c), n);
    TEST_ASSERT_TRUE(n > 0 && n <= core::SOUND_RATE_HZ * core::CHIME_MAX_MS / 1000);
    int peak = 0;
    for (size_t i = 0; i < n; i++) peak = abs(a[i]) > peak ? abs(a[i]) : peak;
    TEST_ASSERT_TRUE(peak > 10000 && peak <= 32767);
    TEST_ASSERT_TRUE_MESSAGE(abs(a[n - 2]) < 1500, "chime must ramp down to 0 (no click)");
    TEST_ASSERT_EQUAL_INT16(0, a[n - 1]);
    // deterministic and independent of the block size
    TEST_ASSERT_EQUAL_UINT32(n, renderAll(c, b, sizeof b / 2, 37));
    for (size_t i = 0; i < n; i++) TEST_ASSERT_EQUAL_INT16(a[i], b[i]);
  }
}

void test_synth_unknown_chime() {
  core::ChimeSynth s;
  TEST_ASSERT_FALSE(s.start(core::CHIME_COUNT));
  TEST_ASSERT_TRUE(s.done());
  TEST_ASSERT_EQUAL_STRING("?", core::chimeName(9));
  TEST_ASSERT_EQUAL_STRING("alert", core::chimeName(3));
}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_parse_valid);
  RUN_TEST(test_parse_invalid);
  RUN_TEST(test_volume_map);
  RUN_TEST(test_synth_length_peak_and_end);
  RUN_TEST(test_synth_unknown_chime);
  return UNITY_END();
}
